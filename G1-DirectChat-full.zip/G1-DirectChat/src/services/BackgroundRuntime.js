import {
  addSignalingDisconnectObserver,
  addSignalingMessageObserver,
} from '../webrtc/signaling';
import {
  onIncomingDone,
  onIncomingStart,
} from '../media/FileShare';
import { saveMessage, savePeer } from './Persistence';
import { showMessageNotification } from './Background';
import { sendSignalingMessage } from '../webrtc/signaling';
import { startRingtone, stopRingtone } from '../media/AudioClip';
import {
  clearCallRuntime,
  finalizeCall,
  getActiveCall,
  handleIncomingCallRequest,
  handleRemoteCallSignal,
  setCallUiAttached,
} from './CallRuntime';

const BACKGROUND_RING_TIMEOUT_MS = 45000;
let backgroundRingTimer = null;

function stopBackgroundRinging() {
  if (backgroundRingTimer) { clearTimeout(backgroundRingTimer); backgroundRingTimer = null; }
  stopRingtone().catch(() => {});
}

const MAX_PENDING_WITHOUT_IDENTITY = 50;

let uiAttached = true;
let currentPeer = null;
let pendingWithoutIdentity = [];
const incomingTransfers = new Map();
let initialized = false;
let subscriptions = [];

function peerLabel() {
  return currentPeer?.deviceName || currentPeer?.name || 'G1 DirectChat';
}

function enqueueUntilIdentity(entry) {
  pendingWithoutIdentity.push(entry);
  if (pendingWithoutIdentity.length > MAX_PENDING_WITHOUT_IDENTITY) {
    pendingWithoutIdentity = pendingWithoutIdentity.slice(-MAX_PENDING_WITHOUT_IDENTITY);
  }
}

async function persistIncomingMessage(message, notificationBody) {
  const peerId = currentPeer?.deviceId;
  if (!peerId) {
    enqueueUntilIdentity({ message, notificationBody });
    return false;
  }

  await saveMessage(peerId, message);
  await savePeer(peerId, peerLabel(), notificationBody || message.text || 'رسالة جديدة');
  if (notificationBody) {
    await showMessageNotification(peerLabel(), notificationBody);
  }
  return true;
}

async function flushPendingAfterIdentity() {
  if (uiAttached || !currentPeer?.deviceId || !pendingWithoutIdentity.length) return;
  const pending = pendingWithoutIdentity;
  pendingWithoutIdentity = [];
  for (const entry of pending) {
    await persistIncomingMessage(entry.message, entry.notificationBody);
  }
}

function rememberIdentity(msg) {
  if (!msg?.deviceId) return;
  currentPeer = {
    deviceId: msg.deviceId,
    deviceName: msg.deviceName || currentPeer?.deviceName || 'G1 Device',
  };
  flushPendingAfterIdentity().catch(() => {});
}

function handleBackgroundSignal(msg) {
  if (!msg || typeof msg !== 'object') return;

  if (msg.type === 'identity' || msg.type === 'handshake-hello' || msg.type === 'handshake-welcome') {
    rememberIdentity(msg);
    return;
  }

  if (msg.type === 'call-request') {
    const result = handleIncomingCallRequest(msg, currentPeer || {});
    // الواجهة مفتوحة → App.js هو المالك (يرنّ ويرد). هنا فقط عندما تكون مقفولة.
    if (uiAttached) return;
    if (!result.accepted) {
      sendSignalingMessage({ type: 'call-busy', callId: msg.callId });
      return;
    }
    // قبل هيك: بالخلفية كان يظهر الإشعار فقط — بلا رنين، بلا "call-ringing"
    // للمتصل، وبلا مهلة، فيبقى المتصل معلّقاً 45 ثانية ويبقى الإشعار للأبد.
    sendSignalingMessage({ type: 'call-ringing', callId: msg.callId });
    startRingtone().catch(() => {});
    if (backgroundRingTimer) clearTimeout(backgroundRingTimer);
    backgroundRingTimer = setTimeout(() => {
      backgroundRingTimer = null;
      const call = getActiveCall();
      if (!call || call.direction !== 'incoming' || call.finalState !== 'ringing') return;
      stopRingtone().catch(() => {});
      sendSignalingMessage({ type: 'call-missed', callId: call.callId });
      finalizeCall(call.callId, 'missed', 'timeout');
      persistIncomingMessage({
        sender: 'remote', type: 'call',
        callKind: call.video ? 'video' : 'voice',
        callResult: 'missed', time: Date.now(),
      }, call.video ? 'مكالمة فيديو فائتة' : 'مكالمة فائتة').catch(() => {});
    }, BACKGROUND_RING_TIMEOUT_MS);
    return;
  }

  if (
    msg.type === 'call-ringing' ||
    msg.type === 'call-accept' ||
    msg.type === 'call-reject' ||
    msg.type === 'call-busy' ||
    msg.type === 'call-missed' ||
    msg.type === 'call-cancel' ||
    msg.type === 'call-end'
  ) {
    const before = getActiveCall();
    handleRemoteCallSignal(msg);
    if (!uiAttached && before?.direction === 'incoming' && (msg.type === 'call-cancel' || msg.type === 'call-end')) {
      stopBackgroundRinging();
      persistIncomingMessage({
        sender: 'remote', type: 'call',
        callKind: before.video ? 'video' : 'voice',
        callResult: 'missed', time: Date.now(),
      }, before.video ? 'مكالمة فيديو فائتة' : 'مكالمة فائتة').catch(() => {});
    }
  }

  if (uiAttached) return;

  if (msg.type === 'chat') {
    const message = {
      sender: 'remote',
      type: 'text',
      text: msg.text || '',
      status: 'delivered',
      time: Date.now(),
    };
    persistIncomingMessage(message, message.text || 'رسالة جديدة').catch(() => {});
  }
}

function handleIncomingStart({ id, fileName, mimeType, kind, size }) {
  if (!id) return;
  incomingTransfers.set(id, {
    id,
    fileName,
    mimeType,
    kind,
    size,
    startedAt: Date.now(),
  });
}

function handleIncomingDone({ id, path, size, fileName, mimeType, kind }) {
  if (!id) return;
  const start = incomingTransfers.get(id) || {};
  incomingTransfers.delete(id);
  if (uiAttached) return;

  const resolvedKind = kind || start.kind || 'file';
  const resolvedName = fileName || start.fileName || 'file';
  const resolvedMime = mimeType || start.mimeType || 'application/octet-stream';
  const localUri = path
    ? (path.startsWith('content://') || path.startsWith('file://') ? path : `file://${path}`)
    : null;
  const type = resolvedKind === 'voice' ? 'voice' : resolvedKind === 'image' ? 'image' : 'file';
  const message = {
    sender: 'remote',
    type,
    fileName: resolvedName,
    mimeType: resolvedMime,
    path,
    localUri,
    size: size || start.size || 0,
    status: 'delivered',
    time: Date.now(),
  };
  const notificationBody =
    resolvedKind === 'voice' ? 'رسالة صوتية' :
    resolvedKind === 'image' ? 'صورة' :
    `ملف: ${resolvedName}`;
  persistIncomingMessage(message, notificationBody).catch(() => {});
}

function handleSignalingDisconnected() {
  // Keep identity briefly in memory for a transient recovery; a replacement
  // identity message will overwrite it. Transfer metadata is session-specific.
  incomingTransfers.clear();
  if (!uiAttached) stopBackgroundRinging();
}

export function setUiAttached(attached) {
  uiAttached = !!attached;
  setCallUiAttached(uiAttached);
  if (!uiAttached) {
    flushPendingAfterIdentity().catch(() => {});
  } else {
    // الواجهة رجعت: مهلة الخلفية تنتهي، App.js يستلم الرنين إذا المكالمة لسا قائمة
    if (backgroundRingTimer) { clearTimeout(backgroundRingTimer); backgroundRingTimer = null; }
  }
}

export function isUiAttached() {
  return uiAttached;
}

export function getBackgroundPeer() {
  return currentPeer ? { ...currentPeer } : null;
}

export function getPendingIncomingCall() {
  const call = getActiveCall();
  return call?.direction === 'incoming' && !['ended', 'missed', 'declined', 'rejected', 'cancelled'].includes(call.finalState)
    ? call
    : null;
}

export function clearPendingIncomingCall() {
  const call = getActiveCall();
  if (call?.direction === 'incoming') clearCallRuntime(call.callId);
}

export function initializeBackgroundRuntime() {
  if (initialized) return;
  initialized = true;
  subscriptions = [
    addSignalingMessageObserver(handleBackgroundSignal),
    addSignalingDisconnectObserver(handleSignalingDisconnected),
    onIncomingStart(handleIncomingStart),
    onIncomingDone(handleIncomingDone),
  ];
}

export function shutdownBackgroundRuntimeForTests() {
  subscriptions.forEach(subscription => {
    try { subscription?.remove?.(); } catch (e) {}
  });
  subscriptions = [];
  initialized = false;
  uiAttached = true;
  setCallUiAttached(true);
  currentPeer = null;
  pendingWithoutIdentity = [];
  incomingTransfers.clear();
  if (backgroundRingTimer) { clearTimeout(backgroundRingTimer); backgroundRingTimer = null; }
}

initializeBackgroundRuntime();
