/**
 * G1 DirectChat - Entry Point
 */
import React, { useEffect } from 'react';
import { AppRegistry } from 'react-native';
import App from './src/App';
import { setUiAttached } from './src/services/BackgroundRuntime';
import { connectionCoordinator } from './src/network/ConnectionCoordinator';
import { lanPassiveAdmissionHandler } from './src/network/LanPassiveAdmission';
import { wifiDirectTransportAdapter } from './src/network/WifiDirectTransportAdapter';
import { setPassiveInboundAdmissionHandler } from './src/webrtc/signaling';
import { signalingOwner } from './src/webrtc/signalingOwner';
import { bluetoothTransport } from './src/bluetooth/BluetoothManager';
import { installIdentityVerifier } from './src/services/IdentityVerifier';
import { lanHandoverAdapter } from './src/network/LanHandoverAdapter';
import { TRANSPORTS } from './src/network/PeerRegistry';
import { linkManager } from './src/network/LinkManager';

connectionCoordinator.setSignalingOwner(signalingOwner);
connectionCoordinator.setP2pAdapter(wifiDirectTransportAdapter);
connectionCoordinator.setBluetoothAdapter(bluetoothTransport);
// فاحص «المجموعة بجلسة حية»: يمنع مؤقّت مهلة Wi-Fi Direct من هدم مجموعة
// قامت فوقها جلسة فعلاً (جذر عطل «ينقطع بعد 30 ث» الموثّق ميدانياً).
wifiDirectTransportAdapter.setRouteInUseChecker(peer => {
  try {
    const pid = peer?.deviceId;
    if (pid && linkManager.getTransports(pid).includes(TRANSPORTS.P2P)) return true;
    const status = connectionCoordinator.getCoordinatorStatus();
    return (
      status?.state === 'CONNECTED' &&
      status?.transport === TRANSPORTS.P2P &&
      (!pid || status?.peer?.deviceId === pid)
    );
  } catch (e) {
    return false;
  }
});
// الترحيل بلا انقطاع إلى الشبكة المحلية (make-before-break)
try { connectionCoordinator.setTransportHandoverAdapter(TRANSPORTS.LAN, lanHandoverAdapter); } catch (e) {}
wifiDirectTransportAdapter.startObserving();
bluetoothTransport.startObserving();
setPassiveInboundAdmissionHandler(lanPassiveAdmissionHandler);
// الهوية التشفيرية: تعمل قبل الواجهة وبعدها (مراقب على قناة الإشارات)
installIdentityVerifier();

function G1Root() {
  useEffect(() => {
    setUiAttached(true);
    return () => setUiAttached(false);
  }, []);

  return React.createElement(App);
}

AppRegistry.registerComponent('DirectChat', () => G1Root);
AppRegistry.registerComponent('M200', () => G1Root);
AppRegistry.registerComponent('G1', () => G1Root);
