/**
 * هجرة الجلسة بلا انقطاع (make-before-break) — مبنية على تقرير التصميم:
 * QUIC RFC 9000 §9 (path validation) + Briar (اتصال واحد لكل ناقل، إغلاق المكرر)
 * + Nearby (ترقية شفافة) + قاعدة المُبادِر-فقط.
 *
 * هذا الملف منطق نقي (بلا sockets) حتى يُختبر بـ jest؛ signaling.js يستخدمه.
 *
 * البروتوكول على المسار الجديد:
 *   A→B  session-attach   { sid, deviceId, lastSeq, nonce }
 *   B→A  attach-challenge { nonce: nB }
 *   A→B  attach-proof     { sig: Sign_A(nB), pubKey }
 *   B→A  attach-ack       { lastSeq: <آخر seq استقبله B> , echo: nonce }   ← يُعدّ PATH_RESPONSE
 *   (commit) A→B path-switch على المسارين، B يقلب مُرسِله، نافذة تصريف 5 ث ثم إغلاق القديم.
 *
 * التسلسل: كل رسالة تطبيق تحمل seq تصاعدياً لكل جلسة؛ المستقبِل يتجاهل seq ≤ lastSeq.
 * إعادة الإرسال بعد الهجرة: من ack.lastSeq+1 من الـ replay buffer.
 */

export const MIGRATION = Object.freeze({
  attachTimeoutMs: 5000,
  drainWindowMs: 5000,
  replayBufferSize: 256,
});

/** المُبادِر الحتمي: صاحب المعرّف الأصغر معجمياً. */
export function isMigrationInitiator(myDeviceId, peerDeviceId) {
  if (!myDeviceId || !peerDeviceId) return true;
  return String(myDeviceId) < String(peerDeviceId);
}

/** معرّف جلسة حتمي لكل زوج — يعرفه الطرفان بلا تفاوض. */
export function sessionIdFor(a, b) {
  return [String(a || ''), String(b || '')].sort().join('|');
}

/**
 * إطارات مستوى النقل: لا تُرقَّم ولا تُمنع كمكرر.
 * `identity` و`my-ip` تُعاد تلقائياً على كل socket جديد من طبقة الإشارات
 * نفسها، فترقيمها يجعل النسخة المُعادة تحمل رقماً قديماً ويكسر مطابقتها.
 */
const CONTROL_FRAMES = new Set([
  'ping', 'pong', 'identity', 'my-ip',
  'session-attach', 'attach-challenge', 'attach-proof', 'attach-ack', 'attach-reject',
  'path-switch', 'disconnect-request', 'disconnect-ack',
]);

export function isControlFrame(msg) {
  return CONTROL_FRAMES.has(msg?.type);
}

export function createSequencer() {
  return {
    nextOut: 1,
    lastIn: 0,
    replay: [],            // [{ seq, msg }]
    stamp(msg) {
      if (!msg || typeof msg !== 'object') return msg;
      if (isControlFrame(msg)) return msg;
      const seq = this.nextOut++;
      const stamped = { ...msg, seq };
      this.replay.push({ seq, msg: stamped });
      if (this.replay.length > MIGRATION.replayBufferSize) this.replay.shift();
      return stamped;
    },
    /** @returns {'accept'|'duplicate'} */
    accept(msg) {
      const seq = Number(msg?.seq);
      if (!Number.isFinite(seq)) return 'accept';        // رسالة من نسخة قديمة بلا seq
      if (seq <= this.lastIn) return 'duplicate';
      this.lastIn = seq;
      return 'accept';
    },
    /** ما يجب إعادة إرساله بعد أن أخبرنا الطرف الآخر بآخر seq استقبله. */
    pendingAfter(peerLastSeq) {
      const n = Number(peerLastSeq) || 0;
      return this.replay.filter(r => r.seq > n).map(r => r.msg);
    },
    ackedUpTo(peerLastSeq) {
      const n = Number(peerLastSeq) || 0;
      this.replay = this.replay.filter(r => r.seq > n);
    },
  };
}

/**
 * آلة حالة الطرف المُبادِر على المسار الجديد.
 * @returns {{ onMessage(msg): 'challenge'|'ack'|'ignore', state }}
 */
export function createAttachClient({ sid, deviceId, lastSeq, nonce }) {
  const state = { phase: 'sent', peerLastSeq: null };
  return {
    state,
    hello() { return { type: 'session-attach', sid, deviceId, lastSeq, nonce }; },
    onMessage(msg) {
      if (!msg) return 'ignore';
      if (msg.type === 'attach-challenge' && state.phase === 'sent') { state.phase = 'challenged'; return 'challenge'; }
      if (msg.type === 'attach-ack' && msg.echo === nonce && (state.phase === 'challenged' || state.phase === 'sent')) {
        state.phase = 'validated'; state.peerLastSeq = Number(msg.lastSeq) || 0; return 'ack';
      }
      if (msg.type === 'attach-reject') { state.phase = 'rejected'; return 'reject'; }
      return 'ignore';
    },
  };
}

/**
 * آلة حالة الطرف المستقبِل: يتحقق أن sid يخص الجلسة النشطة وأن deviceId
 * هو نفس الطرف، ثم يتحدّى ويتحقق من التوقيع (عبر verify المحقونة).
 */
export function createAttachServer({ expectedSid, expectedDeviceId, myLastSeq, makeNonce, verify }) {
  const state = { phase: 'idle', nonce: null, hello: null };
  return {
    state,
    async onMessage(msg) {
      if (!msg) return null;
      if (msg.type === 'session-attach') {
        if (msg.sid !== expectedSid || msg.deviceId !== expectedDeviceId) {
          state.phase = 'rejected';
          return { type: 'attach-reject', reason: 'unknown-session' };
        }
        state.hello = msg;
        state.nonce = makeNonce();
        state.phase = 'challenged';
        return { type: 'attach-challenge', nonce: state.nonce };
      }
      if (msg.type === 'attach-proof' && state.phase === 'challenged') {
        const ok = await verify(expectedDeviceId, msg.pubKey, state.nonce, msg.sig);
        if (!ok) { state.phase = 'rejected'; return { type: 'attach-reject', reason: 'bad-proof' }; }
        state.phase = 'validated';
        return { type: 'attach-ack', lastSeq: myLastSeq(), echo: state.hello.nonce };
      }
      return null;
    },
  };
}
