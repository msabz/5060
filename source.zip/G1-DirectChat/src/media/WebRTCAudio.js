import {
  RTCPeerConnection,
  RTCSessionDescription,
  RTCIceCandidate,
  MediaStream,
  mediaDevices,
} from 'react-native-webrtc';
import { decideRecovery, createRecoveryState } from './rtcRecoveryPolicy';

let pc = null;
let localStream = null;
let remoteStream = null;
let sendSignal = null;
let onStateChange = null;
let onDiag = null;
let connectTimer = null;
let settled = false;
let pendingCandidates = [];
let remoteDescSet = false;
let isCaller = false;
let restartTried = false;
let generation = 0;
let sawP2pCandidate = false;
let deferredCandidates = [];
let deferTimer = null;
let onStreamsChanged = null;
let onLost = null;
let onRemoteMediaState = null;
let recovery = createRecoveryState();
let recoveryTimer = null;
let remoteVideoEnabled = true;

const CONNECT_TIMEOUT_MS = 12000;

const RTC_CONFIG = {
  iceServers: [],
  iceCandidatePoolSize: 0,
  bundlePolicy: 'max-bundle',
  rtcpMuxPolicy: 'require',
  // ظهور واجهة جديدة (p2p0 ↔ wlan0) يولّد مرشحين جدداً بلا جولة تفاوض كاملة
  continualGatheringPolicy: 'gather_continually',
};

const AUDIO = {
  echoCancellation: true,
  noiseSuppression: true,
  autoGainControl: true,
  googEchoCancellation: true,
  googAutoGainControl: true,
  googNoiseSuppression: true,
  googHighpassFilter: true,
};

function wantsVideo() {
  return global.__MUSABCHAT_WEBRTC_VIDEO__ === true;
}

function mediaConstraints() {
  return {
    audio: AUDIO,
    video: wantsVideo()
      ? {
          facingMode: 'user',
          width: { ideal: 640 },
          height: { ideal: 480 },
          frameRate: { ideal: 24, max: 30 },
        }
      : false,
  };
}

export function isWebRTCAvailable() {
  try {
    return !!(RTCPeerConnection && mediaDevices && mediaDevices.getUserMedia);
  } catch (e) {
    return false;
  }
}

function diag(msg) {
  console.log('[RTC]', msg);
  if (onDiag) onDiag(msg);
}

function cleanup() {
  generation++;
  if (connectTimer) { clearTimeout(connectTimer); connectTimer = null; }
  if (deferTimer) { clearTimeout(deferTimer); deferTimer = null; }
  if (recoveryTimer) { clearTimeout(recoveryTimer); recoveryTimer = null; }
  recovery = createRecoveryState();
  remoteVideoEnabled = true;

  try {
    if (localStream) {
      localStream.getTracks().forEach(t => {
        try { t.enabled = false; } catch (e) {}
        try { t.stop(); } catch (e) {}
      });
      localStream.release && localStream.release();
    }
  } catch (e) {}

  try {
    if (pc && pc.getSenders) {
      pc.getSenders().forEach(sender => {
        try { if (sender.track) sender.track.stop(); } catch (e) {}
      });
    }
  } catch (e) {}

  try { if (pc) pc.close(); } catch (e) {}

  pc = null;
  localStream = null;
  remoteStream = null;
  settled = false;
  pendingCandidates = [];
  remoteDescSet = false;
  sawP2pCandidate = false;
  deferredCandidates = [];
  notifyStreams();
}

function notifyStreams() {
  if (!onStreamsChanged) return;
  try { onStreamsChanged({ local: getLocalStreamURL(), remote: getRemoteStreamURL() }); } catch (e) {}
}

function markConnected() {
  if (settled) return;
  settled = true;
  if (connectTimer) { clearTimeout(connectTimer); connectTimer = null; }
  diag('connected');
  if (onStateChange) onStateChange('connected');
}

async function flushPendingCandidates() {
  if (!pc || !remoteDescSet) return;
  const queued = pendingCandidates;
  pendingCandidates = [];
  for (const c of queued) {
    try {
      await pc.addIceCandidate(new RTCIceCandidate(c));
    } catch (e) {
      diag('candidate rejected: ' + (e?.message || ''));
    }
  }
  if (queued.length) diag(`flushed ${queued.length} candidates`);
}

function extractCandidateAddress(candidateStr) {
  const parts = (candidateStr || '').split(' ');
  return parts.length > 4 ? parts[4] : '';
}

function isP2pAddress(addr) {
  return addr.startsWith('192.168.49.');
}

function shouldSendCandidate(candidateStr) {
  const addr = extractCandidateAddress(candidateStr);
  if (!addr) return false;
  if (addr.endsWith('.local')) return false;
  return true;
}

function queueCandidate(c, send) {
  const addr = extractCandidateAddress(c.candidate);
  if (isP2pAddress(addr)) {
    sawP2pCandidate = true;
    deferredCandidates = [];
    if (deferTimer) { clearTimeout(deferTimer); deferTimer = null; }
    send(c);
    return;
  }

  if (sawP2pCandidate) return;
  deferredCandidates.push(c);
  if (!deferTimer) {
    deferTimer = setTimeout(() => {
      deferTimer = null;
      if (sawP2pCandidate) { deferredCandidates = []; return; }
      diag(`no p2p candidate, falling back to ${deferredCandidates.length} others`);
      deferredCandidates.forEach(send);
      deferredCandidates = [];
    }, 1500);
  }
}

function captureRemoteStream(event) {
  try {
    const stream = event?.streams?.[0];
    const track = event?.track;
    if (!stream && !track) return;
    // مسار الفيديو قد يصل بعد الصوت بجزء من الثانية. إعادة استخدام كائن
    // Stream نفسه تُبقي toURL كما هو فلا يُعيد RTCView تهيئة نفسه أبداً —
    // وهذا مصدر «الإطار الشفاف». نبني MediaStream جديداً بكل المسارات
    // الحيّة فيتغيّر المعرف وتُعاد تهيئة العرض مع كل مسار واصل.
    const next = new MediaStream();
    const seen = new Set();
    const addTracks = src => {
      try {
        src?.getTracks?.().forEach(t => {
          if (!t || seen.has(t.id) || t.readyState === 'ended') return;
          seen.add(t.id);
          next.addTrack(t);
        });
      } catch (e) {}
    };
    addTracks(remoteStream);
    addTracks(stream);
    if (track && !seen.has(track.id) && track.readyState !== 'ended') {
      try { next.addTrack(track); } catch (e) {}
    }
    if (next.getTracks().length === 0) return;
    remoteStream = next;
    const kinds = next.getTracks().map(t => t.kind).join(',');
    diag(`remote stream: ${kinds || 'unknown'}`);
    notifyStreams();
  } catch (e) {
    diag('remote stream error: ' + (e?.message || ''));
  }
}

function buildPeer(onFailure) {
  const peer = new RTCPeerConnection(RTC_CONFIG);

  peer.addEventListener('icecandidate', event => {
    if (!event.candidate) {
      diag('gathering complete');
      return;
    }
    if (!sendSignal) return;
    const c = event.candidate.toJSON ? event.candidate.toJSON() : event.candidate;
    if (!shouldSendCandidate(c.candidate)) return;

    const parts = (c.candidate || '').split(' ');
    const addr = parts[4] || '?';
    const typ = parts.indexOf('typ') >= 0 ? parts[parts.indexOf('typ') + 1] : '?';
    diag(`out ${typ} ${addr}`);
    queueCandidate(c, cand => sendSignal({ type: 'rtc-ice', candidate: cand }));
  });

  peer.addEventListener('iceconnectionstatechange', () => {
    if (peer !== pc) return; // اتصال قديم — تجاهله
    const st = peer.iceConnectionState;
    diag('ice: ' + st);
    if (st === 'connected' || st === 'completed') markConnected();
    if (st === 'failed' && !settled) {
      if (!restartTried && isCaller) {
        restartTried = true;
        diag('ice restart');
        restartIce(onFailure);
        return;
      }
      if (onFailure) onFailure('فشل ICE');
      return;
    }
    applyRecovery(st, onFailure);
  });

  peer.addEventListener('connectionstatechange', () => {
    if (peer !== pc) return;
    const st = peer.connectionState;
    diag('pc: ' + st);
    if (st === 'connected') markConnected();
    if ((st === 'failed' || st === 'closed') && !settled && onFailure) {
      onFailure('فشل اتصال WebRTC');
      return;
    }
    // بعد الاتصال: pc.failed بدون ice.failed بيصير مع DTLS — نعامله كفشل ICE
    if (settled && (st === 'failed' || st === 'closed')) applyRecovery(st === 'closed' ? 'closed' : 'failed', onFailure);
  });

  peer.addEventListener('track', event => {
    captureRemoteStream(event);
    diag('remote track received: ' + (event?.track?.kind || '?'));
  });

  return peer;
}

/**
 * تعافي المسار بعد الاتصال. قبل هالتعديل كانت disconnected/failed بعد
 * الاتصال تُتجاهل فيجمد الفيديو وينقطع الصوت والشاشة تبقى مفتوحة.
 */
function applyRecovery(iceState, onFailure) {
  const decision = decideRecovery({ iceState, settled, isCaller, state: recovery });
  if (recoveryTimer && (decision.action !== 'none')) { clearTimeout(recoveryTimer); recoveryTimer = null; }

  switch (decision.action) {
    case 'recovered':
      diag('route recovered');
      if (onStateChange) onStateChange('recovered');
      return;
    case 'wait':
      diag(`ice disconnected — waiting ${decision.delayMs}ms`);
      if (onStateChange) onStateChange('unstable');
      recoveryTimer = setTimeout(() => {
        recoveryTimer = null;
        if (!pc) return;
        const st = pc.iceConnectionState;
        if (st === 'connected' || st === 'completed') { applyRecovery(st, onFailure); return; }
        applyRecovery('grace-expired', onFailure);
      }, decision.delayMs);
      return;
    case 'restart':
      diag(`ice restart #${recovery.restarts}`);
      if (onStateChange) onStateChange('unstable');
      restartIce(onFailure);
      armRestartTimeout(decision.delayMs, onFailure);
      return;
    case 'request-restart':
      diag(`asking caller to restart ice #${recovery.restarts}`);
      if (onStateChange) onStateChange('unstable');
      if (sendSignal) sendSignal({ type: 'rtc-restart-request' });
      armRestartTimeout(decision.delayMs, onFailure);
      return;
    case 'give-up':
      diag('route lost — giving up');
      if (onLost) onLost('انقطع مسار الاتصال بين الجهازين');
      return;
    default:
      return;
  }
}

function armRestartTimeout(delayMs, onFailure) {
  recoveryTimer = setTimeout(() => {
    recoveryTimer = null;
    if (!pc) return;
    const st = pc.iceConnectionState;
    if (st === 'connected' || st === 'completed') { applyRecovery(st, onFailure); return; }
    applyRecovery('failed', onFailure);
  }, delayMs);
}

/** بعد هجرة مسار الإشارات (LAN ↔ P2P): المتصل يعيد ICE فوراً، المستقبِل يطلب ذلك. */
export function onSignalingPathChanged() {
  if (!pc || !settled) return false;
  if (isCaller) { applyRecovery('failed', null); return true; }
  if (sendSignal) sendSignal({ type: 'rtc-restart-request' });
  return true;
}

/** الطرف المتصل يستقبل طلب إعادة تشغيل من الطرف الآخر. */
export function handleRestartRequest() {
  if (!pc || !isCaller) return false;
  applyRecovery('failed', null);
  return true;
}

async function restartIce(onFailure) {
  try {
    if (!pc) return;
    if (pc.signalingState !== 'stable') {
      diag('restart skipped: signaling ' + pc.signalingState);
      return;
    }
    const offer = await pc.createOffer({ iceRestart: true });
    await pc.setLocalDescription(offer);
    if (sendSignal) {
      sendSignal({ type: 'rtc-offer', sdp: pc.localDescription.sdp, restart: true });
    }
  } catch (e) {
    if (onFailure) onFailure('تعذّرت إعادة تشغيل ICE');
  }
}

function closeAbortedStream(stream) {
  try {
    stream.getTracks().forEach(t => {
      t.enabled = false;
      t.stop();
    });
  } catch (e) {}
}

function configureCommon({ signalSender, onFailure, onState, onDiagnostic, onStreams, onRouteLost, onRemoteMedia }) {
  sendSignal = signalSender;
  onStateChange = onState;
  onDiag = onDiagnostic;
  onStreamsChanged = onStreams || null;
  onLost = onRouteLost || null;
  onRemoteMediaState = onRemoteMedia || null;
  return onFailure;
}

export async function startAsCaller({ signalSender, onFailure, onState, onDiagnostic, onStreams, onRouteLost, onRemoteMedia }) {
  cleanup();
  isCaller = true;
  restartTried = false;
  configureCommon({ signalSender, onFailure, onState, onDiagnostic, onStreams, onRouteLost, onRemoteMedia });

  const myGen = generation;
  diag(`caller: requesting ${wantsVideo() ? 'audio+video' : 'audio'}`);
  const stream = await mediaDevices.getUserMedia(mediaConstraints());
  if (myGen !== generation) {
    closeAbortedStream(stream);
    diag('caller: aborted, call ended');
    return;
  }

  localStream = stream;
  pc = buildPeer(onFailure);
  localStream.getTracks().forEach(track => pc.addTrack(track, localStream));
  notifyStreams();

  const offer = await pc.createOffer({
    offerToReceiveAudio: true,
    offerToReceiveVideo: wantsVideo(),
  });
  await pc.setLocalDescription(offer);
  sendSignal({ type: 'rtc-offer', sdp: pc.localDescription.sdp });
  diag('caller: offer sent');
  connectTimer = setTimeout(() => checkBeforeGivingUp(onFailure), CONNECT_TIMEOUT_MS);
}

function checkBeforeGivingUp(onFailure) {
  if (settled) return;
  try {
    const ice = pc && pc.iceConnectionState;
    const conn = pc && pc.connectionState;
    diag(`timeout check — ice:${ice} pc:${conn}`);
    if (ice === 'connected' || ice === 'completed' || conn === 'connected') {
      markConnected();
      return;
    }
    if (ice === 'checking' || ice === 'new') {
      diag('still checking, extending');
      connectTimer = setTimeout(() => {
        if (settled) return;
        const st = pc && pc.iceConnectionState;
        if (st === 'connected' || st === 'completed') {
          markConnected();
          return;
        }
        if (onFailure) onFailure('تعذّر إيجاد مسار بين الجهازين');
      }, 8000);
      return;
    }
  } catch (e) {}
  if (onFailure) onFailure('انتهت مهلة اتصال WebRTC');
}

export async function startAsCallee({ offerSdp, signalSender, onFailure, onState, onDiagnostic, onStreams, onRouteLost, onRemoteMedia }) {
  const carried = pendingCandidates;
  cleanup();
  pendingCandidates = carried;
  isCaller = false;
  restartTried = false;
  configureCommon({ signalSender, onFailure, onState, onDiagnostic, onStreams, onRouteLost, onRemoteMedia });

  const myGen = generation;
  diag(`callee: requesting ${wantsVideo() ? 'audio+video' : 'audio'}`);
  const stream = await mediaDevices.getUserMedia(mediaConstraints());
  if (myGen !== generation) {
    closeAbortedStream(stream);
    diag('callee: aborted, call ended');
    return;
  }

  localStream = stream;
  pc = buildPeer(onFailure);
  localStream.getTracks().forEach(track => pc.addTrack(track, localStream));
  notifyStreams();

  await pc.setRemoteDescription(new RTCSessionDescription({ type: 'offer', sdp: offerSdp }));
  remoteDescSet = true;
  await flushPendingCandidates();

  const answer = await pc.createAnswer();
  await pc.setLocalDescription(answer);
  sendSignal({ type: 'rtc-answer', sdp: pc.localDescription.sdp });
  diag('callee: answer sent');
  connectTimer = setTimeout(() => checkBeforeGivingUp(onFailure), CONNECT_TIMEOUT_MS);
}

export async function handleRestartOffer(offerSdp) {
  if (!pc) return false;
  try {
    if (pc.signalingState === 'have-local-offer' && !isCaller) {
      // تصادم عروض: الطرف المستقبِل بيتراجع عن عرضه ويقبل عرض المتصل
      try { await pc.setLocalDescription({ type: 'rollback' }); } catch (e) {}
    }
    await pc.setRemoteDescription(new RTCSessionDescription({ type: 'offer', sdp: offerSdp }));
    remoteDescSet = true;
    const answer = await pc.createAnswer();
    await pc.setLocalDescription(answer);
    if (sendSignal) sendSignal({ type: 'rtc-answer', sdp: pc.localDescription.sdp });
    diag('callee: restart answer sent');
    await flushPendingCandidates();
    return true;
  } catch (e) {
    diag('restart offer failed: ' + (e?.message || ''));
    return false;
  }
}

export function hasActivePeer() {
  return !!pc;
}

export async function acceptAnswer(sdp) {
  if (!pc) return;
  await pc.setRemoteDescription(new RTCSessionDescription({ type: 'answer', sdp }));
  remoteDescSet = true;
  diag('caller: answer accepted');
  await flushPendingCandidates();
}

export async function addRemoteCandidate(candidate) {
  if (!candidate) return;
  if (candidate.candidate && !shouldSendCandidate(candidate.candidate)) return;
  const rp = (candidate.candidate || '').split(' ');
  diag(`in ${rp[7] || '?'} ${rp[4] || '?'}`);

  if (!pc || !remoteDescSet) {
    pendingCandidates.push(candidate);
    return;
  }
  try {
    await pc.addIceCandidate(new RTCIceCandidate(candidate));
  } catch (e) {
    diag('candidate error: ' + (e?.message || ''));
  }
}

export function setMicMuted(muted) {
  if (!localStream) return;
  localStream.getAudioTracks().forEach(t => { t.enabled = !muted; });
}

export function hasVideoTrack() {
  try {
    return !!localStream && localStream.getVideoTracks().length > 0;
  } catch (e) {
    return false;
  }
}

export function setCameraEnabled(enabled) {
  try {
    if (!localStream) return false;
    const tracks = localStream.getVideoTracks();
    tracks.forEach(t => { t.enabled = !!enabled; });
    // نبلّغ الطرف الآخر حتى ما يشوف آخر إطار مجمّداً ويظن إن الفيديو علّق
    if (sendSignal && tracks.length > 0) sendSignal({ type: 'rtc-media', video: !!enabled });
    return tracks.length > 0;
  } catch (e) {
    return false;
  }
}

export async function switchCamera() {
  try {
    const track = localStream?.getVideoTracks?.()[0];
    if (!track) return false;
    if (typeof track._switchCamera === 'function') {
      track._switchCamera();
      return true;
    }
    return false;
  } catch (e) {
    diag('switch camera failed: ' + (e?.message || ''));
    return false;
  }
}

/** الطرف الآخر أطفأ/شغّل كاميرته. */
export function handleRemoteMediaState(msg) {
  if (!msg) return;
  if (typeof msg.video === 'boolean') {
    remoteVideoEnabled = msg.video;
    diag(`remote video ${msg.video ? 'on' : 'off'}`);
    if (onRemoteMediaState) onRemoteMediaState({ video: remoteVideoEnabled });
  }
}

export function isRemoteVideoEnabled() {
  return remoteVideoEnabled;
}

export function getLocalStreamURL() {
  try {
    return localStream && typeof localStream.toURL === 'function' ? localStream.toURL() : null;
  } catch (e) {
    return null;
  }
}

export function getRemoteStreamURL() {
  try {
    return remoteStream && typeof remoteStream.toURL === 'function' ? remoteStream.toURL() : null;
  } catch (e) {
    return null;
  }
}

export function stop() {
  cleanup();
  sendSignal = null;
  onStateChange = null;
  onDiag = null;
  onStreamsChanged = null;
  onLost = null;
  onRemoteMediaState = null;
}

export function hasLiveAudio() {
  try {
    if (!localStream) return false;
    return localStream.getAudioTracks().some(t => t.readyState === 'live' && t.enabled);
  } catch (e) {
    return false;
  }
}

export function isActive() {
  return !!pc && settled;
}
