import { NativeModules, NativeEventEmitter } from 'react-native';
import { getActivePeerAddress } from '../webrtc/signaling';
import { presenceP2pHost } from '../network/PresenceBeacon';

const { FilePickerModule, FileTransferModule } = NativeModules;
const ftEmitter = new NativeEventEmitter(FileTransferModule);
let transferServerPromise = null;

/**
 * ذاكرة سرعة المسارات (EWMA): قياسات averageMbps الحقيقية من كل نقل مكتمل،
 * لكل عائلة مسار. مستوى البيانات يفضّل Wi-Fi Direct — المستخدم قيّمه أسرع
 * بكثير من الشبكة المحلية (حلقة الراوتر) — إلا إذا أثبتت القياسات عكس ذلك
 * بهامش ≥ 1.3× (مانع رفرفة).
 */
const routeStats = { lan: null, p2p: null }; // { mbps, samples }
const ROUTE_EWMA_ALPHA = 0.5;
const LAN_ADVANTAGE_THRESHOLD = 1.3;

export function recordRouteMeasurement(routeFamily, mbps) {
  if (!routeFamily || !(mbps > 0)) return;
  const prev = routeStats[routeFamily];
  routeStats[routeFamily] = {
    mbps: prev ? prev.mbps * (1 - ROUTE_EWMA_ALPHA) + mbps * ROUTE_EWMA_ALPHA : mbps,
    samples: (prev?.samples || 0) + 1,
  };
}

export function routeStatsSnapshot() {
  return JSON.parse(JSON.stringify(routeStats));
}

/** للاختبارات فقط */
export function resetRouteStats() {
  routeStats.lan = null;
  routeStats.p2p = null;
}

export function routeFamilyOf(address) {
  return typeof address === 'string' && address.startsWith('192.168.49.') ? 'p2p' : 'lan';
}

/**
 * قرار مسار البيانات: P2P أولاً إن توفر عنوان حي عليه، إلا إذا كانت قياسات
 * LAN أسرع بـ 1.3× على الأقل. بلا قياسات → P2P يفوز (تفضيل المصنع).
 */
export function pickFileRouteFamily({ p2pAvailable, stats = routeStats }) {
  if (!p2pAvailable) return 'lan';
  const lan = stats.lan?.mbps;
  const p2p = stats.p2p?.mbps;
  if (lan && p2p && lan >= p2p * LAN_ADVANTAGE_THRESHOLD) return 'lan';
  return 'p2p';
}

function normalizePeerAddress(value) {
  if (!value || typeof value !== 'string') return null;
  let address = value.trim();
  if (!address) return null;
  if (address.startsWith('::ffff:')) address = address.slice(7);
  if (address.startsWith('[') && address.endsWith(']')) address = address.slice(1, -1);
  return address || null;
}

export function resolveFileTransferTarget(peerIp, { peerDeviceId = null } = {}) {
  const sessionAddress = normalizePeerAddress(getActivePeerAddress());
  const explicit = normalizePeerAddress(peerIp);

  // مسار Wi-Fi Direct المباشر: عنوان القرين على رابط P2P من بث الحضور
  // (يعمل حتى عندما نكون مالك المجموعة)، أو عنوان مالك المجموعة إن كنا عملاء.
  let p2pAddress = null;
  if (peerDeviceId) {
    try { p2pAddress = presenceP2pHost(peerDeviceId); } catch (e) {}
  }

  const family = pickFileRouteFamily({ p2pAvailable: !!p2pAddress });
  if (family === 'p2p' && p2pAddress) {
    return {
      target: p2pAddress,
      source: 'p2p-presence-route',
      sessionAddress,
      explicit,
      routeFamily: 'p2p',
    };
  }

  return {
    target: sessionAddress || explicit,
    source: sessionAddress ? 'active-session' : explicit ? 'cached-fallback' : 'none',
    sessionAddress,
    explicit,
    routeFamily: routeFamilyOf(sessionAddress || explicit),
  };
}

function ensureTransferServer() {
  if (!FileTransferModule?.startServer) {
    return Promise.reject(new Error('خدمة نقل الملفات غير متاحة'));
  }
  if (!transferServerPromise) {
    transferServerPromise = FileTransferModule.startServer().catch(error => {
      transferServerPromise = null;
      throw error;
    });
  }
  return transferServerPromise;
}

// Keep the data-plane listener available independently from the UI lifecycle.
ensureTransferServer().catch(() => {});

export function pickFile() { return FilePickerModule.pickFile(); }
export function captureImage() { return FilePickerModule.captureImage(); }
export function listInstalledApps() { return FilePickerModule.listInstalledApps(); }
export function packageAppForSending(packageName) { return FilePickerModule.packageAppForSending(packageName); }
export function openReceivedFile(pathOrUri, mimeType) { return FilePickerModule.openReceivedFile(pathOrUri, mimeType || '*/*'); }
export function startTransferServer() { return ensureTransferServer(); }
export function stopTransferServer() {
  transferServerPromise = null;
  return FileTransferModule.stopServer();
}
export function cancelTransfer(transferId) {
  if (transferId && FileTransferModule.cancelTransferById) {
    return FileTransferModule.cancelTransferById(transferId);
  }
  return FileTransferModule.cancelTransfer();
}

/**
 * Send raw file data on TCP 8090. The live signaling socket is the route source
 * of truth. peerIp is only a compatibility fallback and may be null.
 */
export async function sendFileNative(peerIp, uri, transferId, kind = 'file', { peerDeviceId = null } = {}) {
  const route = resolveFileTransferTarget(peerIp, { peerDeviceId });
  if (!route.target) {
    throw new Error('لم يتم تحديد مسار الجهاز الآخر من جلسة الاتصال الحالية');
  }

  await ensureTransferServer();
  console.log(
    `[G1/FILE] SEND_START peer=${route.target} source=${route.source} family=${route.routeFamily || 'unknown'} kind=${kind} id=${transferId}`
  );
  const result = await FileTransferModule.sendFile(route.target, uri, transferId, kind);
  // قياس حقيقي يغذّي ذاكرة المسارات — القرارات القادمة تتعلم منه
  const mbps = Number(result?.averageMbps);
  if (mbps > 0 && route.routeFamily) recordRouteMeasurement(route.routeFamily, mbps);
  return result;
}

export function onTransferProgress(cb) { return ftEmitter.addListener('FT_PROGRESS', cb); }
export function onIncomingStart(cb) { return ftEmitter.addListener('FT_INCOMING_START', cb); }
export function onIncomingDone(cb) { return ftEmitter.addListener('FT_INCOMING_DONE', cb); }
export function onSentDone(cb) { return ftEmitter.addListener('FT_SENT_DONE', cb); }
export function onTransferError(cb) { return ftEmitter.addListener('FT_ERROR', cb); }
