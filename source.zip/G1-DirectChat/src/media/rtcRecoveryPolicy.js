/**
 * سياسة التعافي لمسار WebRTC بعد ما تصير المكالمة متصلة.
 *
 * منطق نقي بدون أي اعتماد على react-native-webrtc حتى يكون قابلاً للاختبار.
 * WebRTCAudio.js بيستدعيه على كل تغيّر بحالة ICE/PC ويطبّق القرار.
 *
 * المشكلة اللي بتحلّها: قبل هيك كانت حالة ICE بعد الاتصال (disconnected /
 * failed) تُتجاهل نهائياً، فالفيديو بيجمد والصوت بينقطع وبتضل الشاشة
 * مفتوحة بدون أي محاولة إصلاح ولا إنهاء واضح.
 */

export const RECOVERY_DEFAULTS = Object.freeze({
  // مهلة نعطيها لـ ICE ليرجع لحاله قبل ما نبدأ إعادة تشغيل صريحة
  disconnectedGraceMs: 4000,
  // أقصى عدد محاولات إعادة تشغيل ICE بعد الاتصال
  maxRestarts: 3,
  // مهلة كل محاولة إعادة تشغيل قبل اعتبارها فاشلة
  restartTimeoutMs: 8000,
});

export function createRecoveryState() {
  return { restarts: 0, phase: 'stable' };
}

/**
 * @param {object} args
 * @param {string} args.iceState       الحالة الجديدة لـ iceConnectionState
 * @param {boolean} args.settled       هل سبق وصارت المكالمة متصلة
 * @param {boolean} args.isCaller      هل هذا الطرف هو المتصل (المالك لإعادة التشغيل)
 * @param {object} args.state          حالة التعافي الحالية (mutable)
 * @param {object} [args.opts]         تجاوزات RECOVERY_DEFAULTS
 * @returns {{ action: string, delayMs?: number }}
 *   actions: 'none' | 'recovered' | 'wait' | 'restart' | 'request-restart' | 'give-up'
 */
export function decideRecovery({ iceState, settled, isCaller, state, opts = {} }) {
  const cfg = { ...RECOVERY_DEFAULTS, ...opts };

  if (iceState === 'connected' || iceState === 'completed') {
    const wasRecovering = state.phase !== 'stable';
    state.phase = 'stable';
    // كل تعافٍ ناجح يعيد العدّاد: مكالمة طويلة بتصمد لأكثر من انقطاع عابر
    state.restarts = 0;
    return { action: wasRecovering ? 'recovered' : 'none' };
  }

  // قبل الاتصال الأول: المنطق القديم (مهلة الاتصال) هو المسؤول
  if (!settled) return { action: 'none' };

  if (iceState === 'disconnected') {
    if (state.phase === 'stable') {
      state.phase = 'grace';
      return { action: 'wait', delayMs: cfg.disconnectedGraceMs };
    }
    return { action: 'none' };
  }

  if (iceState === 'failed' || iceState === 'grace-expired') {
    if (state.restarts >= cfg.maxRestarts) {
      state.phase = 'dead';
      return { action: 'give-up' };
    }
    state.restarts += 1;
    state.phase = 'restarting';
    return {
      action: isCaller ? 'restart' : 'request-restart',
      delayMs: cfg.restartTimeoutMs,
    };
  }

  if (iceState === 'closed') {
    state.phase = 'dead';
    return { action: 'give-up' };
  }

  return { action: 'none' };
}
