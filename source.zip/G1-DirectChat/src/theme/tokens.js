/** رموز التصميم: شبكة 4pt، أنصاف أقطار، مقياس طباعة، ظلال موحّدة. */
export const spacing = {
  xs: 4, sm: 8, md: 12, lg: 16, xl: 20, xxl: 28, xxxl: 40,
};

export const radius = {
  sm: 10, md: 14, lg: 18, xl: 24, xxl: 30, pill: 999,
};

export const type = {
  hero: { fontSize: 30, fontWeight: '800', letterSpacing: 0.2 },
  title: { fontSize: 20, fontWeight: '700' },
  subtitle: { fontSize: 15, fontWeight: '600' },
  body: { fontSize: 15, fontWeight: '400', lineHeight: 22 },
  caption: { fontSize: 12.5, fontWeight: '500' },
  micro: { fontSize: 11, fontWeight: '600', letterSpacing: 0.3 },
};

export const shadow = (color = '#000', opacity = 0.18, elevation = 6, radiusPx = 12, height = 4) => ({
  shadowColor: color,
  shadowOpacity: opacity,
  shadowRadius: radiusPx,
  shadowOffset: { width: 0, height },
  elevation,
});

/** لوحة الأفاتار: ثنائيات لونية حتمية من الاسم (بلا صور خارجية). */
export const AVATAR_PALETTES = [
  ['#6C5CE7', '#00D4C8'],
  ['#F368E0', '#FF9F43'],
  ['#00D2D3', '#54A0FF'],
  ['#FF6B81', '#FFC048'],
  ['#1DD1A1', '#5F27CD'],
  ['#FF9F43', '#EE5253'],
  ['#48DBFB', '#0ABDE3'],
  ['#A29BFE', '#FD79A8'],
];

export function avatarPalette(name = '') {
  let hash = 0;
  for (let i = 0; i < name.length; i++) hash = (hash * 31 + name.charCodeAt(i)) >>> 0;
  return AVATAR_PALETTES[hash % AVATAR_PALETTES.length];
}
