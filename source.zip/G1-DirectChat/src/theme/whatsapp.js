/**
 * لوحة واتساب الداكنة الرسمية (مرجع التصميم: WhatsApp Android dark theme).
 * ثوابت مركزية حتى تبقى كل الشاشات متطابقة حرفياً.
 */
export const W = Object.freeze({
  bg: '#0B141A',            // خلفية المحادثات والقوائم
  header: '#1F2C34',        // شريط علوي
  surface: '#1F2C34',       // بطاقات
  incoming: '#1F2C34',      // فقاعة الوارد
  outgoing: '#005C4B',      // فقاعة الصادر
  accent: '#00A884',        // الأخضر الرئيسي (أزرار، أشرطة)
  fab: '#00A884',
  badge: '#25D366',         // شارة غير المقروء
  badgeText: '#0B141A',
  tick: '#53BDEB',          // صحّين المقروء الزرقاوين
  text: '#E9EDEF',
  textMuted: '#8696A0',
  divider: '#222D34',
  danger: '#F15C6D',
  tabInactive: '#8696A0',
  inputPill: '#1F2C34',
  online: '#25D366',
});

/** تنسيق وقت قائمة الدردشات بأسلوب واتساب: الساعة اليوم، "أمس"، ثم التاريخ. */
export function waListTime(ts) {
  if (!ts) return '';
  const d = new Date(Number(ts));
  const now = new Date();
  const sameDay = d.toDateString() === now.toDateString();
  const yesterday = new Date(now); yesterday.setDate(now.getDate() - 1);
  if (sameDay) {
    let h = d.getHours();
    const m = d.getMinutes().toString().padStart(2, '0');
    const ampm = h >= 12 ? 'م' : 'ص';
    h = h % 12 || 12;
    return `${h}:${m} ${ampm}`;
  }
  if (d.toDateString() === yesterday.toDateString()) return 'أمس';
  return `${d.getDate()}/${d.getMonth() + 1}/${d.getFullYear()}`;
}
