/**
 * مشرف المسار (Link Supervisor) — المحفّز التلقائي للهجرة بلا انقطاع.
 *
 * منطق نقي بلا sockets ولا RN: يأخذ لقطة لحالة الشبكة ويقرر متى وإلى أين
 * نهاجر (ترقية إلى LAN، أو هبوط إلى Wi-Fi Direct عند الابتعاد عن الشبكة).
 * App.js يزوّده باللقطات وينفّذ قراراته عبر ConnectionCoordinator.handoverPeer.
 *
 * القواعد (من تقرير التصميم + دراسة المراجع):
 * - المُبادِر-فقط: صاحب deviceId الأصغر معجمياً يقود؛ الآخر يستقبل session-attach.
 * - أولوية رقمية بنمط Syncthing: LAN(10) < P2P(20) < BLUETOOTH(30).
 * - الترقية للأفضل المتاح من أي ناقل (BT→P2P→LAN كلها مشمولة — درس KDE/Briar:
 *   البلوتوث مواطن أول يُرقَّى ويُهبَط إليه، لا مسار جانبي).
 * - الهبوط عند فقدان المسار الحالي أو مرضه: LAN→P2P→BT بالتسلسل المتاح.
 * - لا هجرة أثناء مكالمة أو نقل ملفات إلا إذا كان المسار الحالي مريضاً.
 * - backoff أسّي بعد كل فشل (1,2,4,8 ث حتى 30 ث)، وتهدئة بعد كل نجاح.
 */

import { isMigrationInitiator } from '../webrtc/sessionMigration';

export const LINK_PRIORITY = Object.freeze({
  LAN: 10,
  P2P: 20,
  BLUETOOTH: 30,
});

export const LINK_SUPERVISOR_DEFAULTS = Object.freeze({
  /** تأخير أولي قبل الترقية — يمنع الرفرفة عند ظهور LAN لحظياً. */
  upgradeStableMs: 4000,
  /** كم ننتظر غياب LAN قبل الهبوط — أقل من مهلة انقطاع الإشارات (18 ث). */
  downgradeGraceMs: 9000,
  /** تهدئة بعد هجرة ناجحة قبل أي قرار جديد. */
  cooldownAfterSuccessMs: 30000,
  /** تراجع أسّي بعد الفشل. */
  failureBackoffMs: Object.freeze([1000, 2000, 4000, 8000, 30000]),
  /** سقف المحاولات الفاشلة المتتالية قبل السكوت الطويل (5 دقائق). */
  maxConsecutiveFailures: 5,
  longSleepMs: 5 * 60 * 1000,
});

function betterThan(candidate, current) {
  const a = LINK_PRIORITY[candidate];
  const b = LINK_PRIORITY[current];
  return Number.isFinite(a) && Number.isFinite(b) && a < b;
}

export function createLinkSupervisor(options = {}) {
  const cfg = { ...LINK_SUPERVISOR_DEFAULTS, ...options };
  const now = typeof options.now === 'function' ? options.now : () => Date.now();

  let lanFirstSeenAt = null;      // متى صار LAN مرئياً باستمرار
  let lanLostAt = null;           // متى فقدنا LAN
  let cooldownUntil = 0;
  let failures = 0;
  let nextAttemptAt = 0;
  let pending = false;            // هجرة جارية الآن
  let lastDecision = null;

  const listeners = new Set();
  const emit = decision => {
    lastDecision = decision;
    listeners.forEach(fn => { try { fn(decision); } catch (e) {} });
  };

  function blockedUntil() {
    const t = now();
    if (pending) return { blocked: true, reason: 'migration-in-flight' };
    if (t < cooldownUntil) return { blocked: true, reason: 'cooldown', retryAfterMs: cooldownUntil - t };
    if (t < nextAttemptAt) return { blocked: true, reason: 'backoff', retryAfterMs: nextAttemptAt - t };
    return { blocked: false };
  }

  /**
   * @param snapshot {{
   *   myDeviceId: string, peerId: string,
   *   currentTransport: 'LAN'|'P2P'|'BLUETOOTH',
   *   pathHealthy: boolean,
   *   lanReachable?: boolean, lanHost?: string, lanPort?: number,
   *   p2pReachable?: boolean, p2pHost?: string, p2pPort?: number,
   *   btReachable?: boolean,
   *   inCall?: boolean, transferActive?: boolean,
   * }}
   */
  function evaluate(snapshot) {
    const t = now();
    const none = reason => ({ action: 'none', reason });

    if (!snapshot || !snapshot.peerId || !snapshot.currentTransport) return none('no-session');
    if (!isMigrationInitiator(snapshot.myDeviceId, snapshot.peerId)) return none('not-initiator');

    // تتبع استقرار/غياب LAN عبر اللقطات المتتالية
    if (snapshot.lanReachable) { if (lanFirstSeenAt === null) lanFirstSeenAt = t; lanLostAt = null; }
    else { lanFirstSeenAt = null; if (lanLostAt === null) lanLostAt = t; }

    const gate = blockedUntil();
    if (gate.blocked) return { action: 'none', reason: gate.reason, retryAfterMs: gate.retryAfterMs || 0 };

    const busy = (snapshot.inCall === true || snapshot.transferActive === true);
    const current = snapshot.currentTransport;

    // 1) ترقية إلى LAN: متاح ومستقر — من أي ناقل أدنى (P2P أو Bluetooth)
    if (current !== 'LAN' && snapshot.lanReachable && snapshot.lanHost) {
      const stableFor = t - (lanFirstSeenAt ?? t);
      if (busy && snapshot.pathHealthy !== false) return none('busy-protected');
      if (stableFor < cfg.upgradeStableMs) {
        return { action: 'none', reason: 'awaiting-lan-stability', retryAfterMs: cfg.upgradeStableMs - stableFor };
      }
      return {
        action: 'migrate',
        target: 'LAN',
        host: snapshot.lanHost,
        port: snapshot.lanPort,
        reason: 'upgrade-to-lan',
      };
    }

    // 1ب) ترقية من Bluetooth إلى Wi-Fi Direct: أصبح العنوان معروفاً
    // (نتعلمه داخل القناة عبر p2p-address) — درس Bada: الترقية تُبنى وتُتحقق
    // قبل إحالة القناة الأدنى، والمجموعة الواحدة device-wide تُحترم.
    if (current === 'BLUETOOTH' && snapshot.p2pReachable) {
      if (busy && snapshot.pathHealthy !== false) return none('busy-protected');
      return {
        action: 'migrate',
        target: 'P2P',
        host: snapshot.p2pHost || null,
        port: snapshot.p2pPort,
        reason: 'upgrade-bt-to-p2p',
      };
    }

    // 2) هبوط: نحن على LAN واختفى أو مرض المسار
    if (current === 'LAN') {
      const lanGoneFor = snapshot.lanReachable ? 0 : t - (lanLostAt ?? t);
      const pathSick = snapshot.pathHealthy === false;
      if (!pathSick && lanGoneFor < cfg.downgradeGraceMs) return none('lan-holding');
      if (snapshot.p2pReachable && snapshot.p2pHost) {
        return {
          action: 'migrate',
          target: 'P2P',
          host: snapshot.p2pHost,
          port: snapshot.p2pPort,
          reason: pathSick ? 'lan-path-sick' : 'lan-lost',
        };
      }
      // LAN مات ولا مجموعة P2P: بلوتوث هو الهبوط الأخير إن كان العنوان معروفاً
      if (snapshot.btReachable && snapshot.btAddress) {
        return {
          action: 'migrate',
          target: 'BLUETOOTH',
          address: snapshot.btAddress,
          reason: pathSick ? 'lan-path-sick' : 'lan-lost',
        };
      }
      return none('no-seamless-target');
    }

    // 3) هبوط: نحن على P2P والمسار مريض/ميّت وبلوتوث متاح
    if (current === 'P2P' && snapshot.pathHealthy === false && snapshot.btReachable && snapshot.btAddress) {
      return {
        action: 'migrate',
        target: 'BLUETOOTH',
        address: snapshot.btAddress,
        reason: 'p2p-path-sick',
      };
    }

    return none('hold');
  }

  return {
    evaluate,
    /** استدعِها عند بدء تنفيذ قرار migrate. */
    markPending() { pending = true; },
    recordSuccess() {
      pending = false;
      failures = 0;
      nextAttemptAt = 0;
      cooldownUntil = now() + cfg.cooldownAfterSuccessMs;
      lanFirstSeenAt = null;
    },
    recordFailure() {
      pending = false;
      failures += 1;
      const idx = Math.min(failures - 1, cfg.failureBackoffMs.length - 1);
      const wait = failures >= cfg.maxConsecutiveFailures
        ? cfg.longSleepMs
        : cfg.failureBackoffMs[idx];
      nextAttemptAt = now() + wait;
    },
    /** يُلغي الترحّم المؤقت عند تغيّر الجلسة أو القطع الكامل. */
    reset() {
      lanFirstSeenAt = null; lanLostAt = null;
      cooldownUntil = 0; failures = 0; nextAttemptAt = 0; pending = false;
    },
    subscribe(fn) { listeners.add(fn); return () => listeners.delete(fn); },
    getState() {
      return { pending, failures, cooldownUntil, nextAttemptAt, lastDecision };
    },
  };
}

export default createLinkSupervisor;
