/**
 * مهيّئ الترحيل إلى LAN/Wi-Fi Direct للمنسّق (make-before-break):
 * prepareConnection → prepareMigration (socket جديد + إثبات هوية + تحقق مسار)
 * commitConnection  → commitMigration  (قلب المُرسِل + path-switch + تصريف 5 ث)
 * discardConnection → discardMigration
 * الجلسة المنطقية (المعرّف، التسلسل، الرسائل) لا تتغير — يتغير المسار فقط.
 */
import {
  prepareMigration, commitMigration, discardMigration, sendSignalingMessage,
  addSignalingDisconnectObserver, getActiveSession, closeSignaling,
} from '../webrtc/signaling';
import { TRANSPORTS } from './PeerRegistry';

function resolveEndpoint(peer, options, transport) {
  const ep = options?.host
    ? { host: options.host, port: options.port }
    : peer?.transports?.[transport] || peer?.transports?.LAN || null;
  if (!ep?.host) throw new Error('لا يوجد عنوان معروف لهذا الناقل');
  return { host: ep.host, port: ep.port || 8089 };
}

export function createLanHandoverAdapter(transport = TRANSPORTS.LAN) {
  return {
    transport,
    async prepareConnection(peer, options = {}) {
      const { host, port } = resolveEndpoint(peer, options, transport);
      const candidate = await prepareMigration({ host, port, timeoutMs: options.timeoutMs || 5000 });
      return { session: candidate, isConnected: true, host, port };
    },
    async commitConnection(candidate) {
      const session = await commitMigration(candidate.session);
      return { session, isConnected: true, sendMessage: msg => sendSignalingMessage(msg) };
    },
    async discardConnection(candidate) {
      return discardMigration(candidate?.session);
    },
    cancelPrepare() { return Promise.resolve(); },
    sendMessage(message) { return sendSignalingMessage(message); },
    getActiveSession() { return getActiveSession(); },
    disconnect() { closeSignaling(); return Promise.resolve(); },
    subscribeDisconnect(observer) {
      return addSignalingDisconnectObserver(observer);
    },
  };
}

export const lanHandoverAdapter = createLanHandoverAdapter(TRANSPORTS.LAN);
export const p2pHandoverAdapter = createLanHandoverAdapter(TRANSPORTS.P2P);
