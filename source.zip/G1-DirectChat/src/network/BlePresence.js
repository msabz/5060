/**
 * حضور BLE: إعلان بصمة مفتاحي (8 بايت) ومسح بصمات أصدقائي.
 * يحوّل "بصمة مرئية" إلى "جهة اتصال متصلة عبر Bluetooth" في سجل الأقران.
 */
import { NativeModules, NativeEventEmitter, PermissionsAndroid, Platform } from 'react-native';

const Native = (NativeModules && NativeModules.BlePresenceModule) || null;
const Keys = (NativeModules && NativeModules.IdentityKeysModule) || null;
const emitter = Native ? new NativeEventEmitter(Native) : null;

export const BLE_PRESENCE = Object.freeze({ onlineWindowMs: 45000, reapEveryMs: 15000 });

let sub = null;
let reaper = null;
let hashToPeer = {};
const lastSeen = new Map(); // peerId -> { at, address, rssi }

export async function refreshPinnedHashes() {
  if (!Keys) return;
  try { hashToPeer = (await Keys.listPinnedKeyHashes()) || {}; } catch (e) {}
}

async function hasPerms() {
  if (Platform.OS !== 'android') return false;
  const perms = Platform.Version >= 31
    ? [PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN, PermissionsAndroid.PERMISSIONS.BLUETOOTH_ADVERTISE, PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT]
    : [PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION];
  const r = await Promise.all(perms.map(p => PermissionsAndroid.check(p).catch(() => false)));
  return r.every(Boolean);
}

export async function startBlePresence({ keyHash, onPeer, onLost }) {
  if (!Native || !emitter || !keyHash) return false;
  if (!(await hasPerms())) return false;
  await refreshPinnedHashes();
  if (!sub) {
    sub = emitter.addListener('BLE_PRESENCE', evt => {
      const peerId = hashToPeer[evt.keyHash];
      if (!peerId) return; // ليس جهة اتصال مثبّتة — نتجاهل (خصوصية)
      const prev = lastSeen.get(peerId);
      const fresh = !prev || (evt.receivedAt - prev.at) > BLE_PRESENCE.onlineWindowMs;
      lastSeen.set(peerId, { at: evt.receivedAt || Date.now(), address: evt.address, rssi: evt.rssi });
      try { onPeer?.({ peerId, address: evt.address, rssi: evt.rssi, fresh }); } catch (e) {}
    });
  }
  if (!reaper) {
    reaper = setInterval(() => {
      const now = Date.now();
      for (const [peerId, rec] of lastSeen.entries()) {
        if (now - rec.at > BLE_PRESENCE.onlineWindowMs) { lastSeen.delete(peerId); try { onLost?.({ peerId }); } catch (e) {} }
      }
    }, BLE_PRESENCE.reapEveryMs);
  }
  return Native.start(keyHash).catch(() => false);
}

export function blePresenceSnapshot() {
  return Array.from(lastSeen.entries()).map(([peerId, r]) => ({ peerId, ...r }));
}

export function stopBlePresence() {
  if (sub) { sub.remove(); sub = null; }
  if (reaper) { clearInterval(reaper); reaper = null; }
  lastSeen.clear();
  return Native ? Native.stop().catch(() => false) : Promise.resolve(false);
}
