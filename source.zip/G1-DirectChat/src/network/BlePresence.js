/**
 * حضور BLE: إعلان بصمة مفتاحي (8 بايت) ومسح بصمات أصدقائي.
 * يحوّل "بصمة مرئية" إلى "جهة اتصال متصلة عبر Bluetooth" في سجل الأقران.
 */
import { NativeModules, NativeEventEmitter, PermissionsAndroid, Platform } from 'react-native';

const Native = (NativeModules && NativeModules.BlePresenceModule) || null;
const Keys = (NativeModules && NativeModules.IdentityKeysModule) || null;
const emitter = Native ? new NativeEventEmitter(Native) : null;

export const BLE_PRESENCE = Object.freeze({
  onlineWindowMs: 45000,
  reapEveryMs: 15000,
  pubHashBucketMs: 15 * 60 * 1000, // تدوير بصمة الرقم كل 15 دقيقة
});

let sub = null;
let reaper = null;
let hashToPeer = {};
const lastSeen = new Map(); // peerId -> { at, address, rssi }
const strangerSeen = new Map(); // address -> { at, rssi, pubHash } — أجهزة MusabX غرباء قريبة
let myNumber = '';           // رقمي المطبعي (12+ رقماً) — لبصمة الغرباء
let strangerListener = null; // (evt { pubHash, address, rssi }) => void — للأرقام غير المعروفة
let rotator = null;

function currentBucket(now = Date.now()) {
  return Math.floor(now / BLE_PRESENCE.pubHashBucketMs);
}

/** بصمتي العامة الحالية (للغرباء الباحثين عن رقمي). */
export async function myPublicHash(now = Date.now()) {
  if (!Keys || !myNumber || typeof Keys.pubHashFor !== 'function') return '';
  try { return (await Keys.pubHashFor(myNumber, currentBucket(now))) || ''; } catch (e) { return ''; }
}

/** بصمة رقم مستهدف لدلو زمني معين — يستخدمها الباحث عن الرقم. */
export async function publicHashForNumber(digits, bucket) {
  if (!Keys || typeof Keys.pubHashFor !== 'function') return '';
  try { return (await Keys.pubHashFor(String(digits), bucket)) || ''; } catch (e) { return ''; }
}

async function refreshMyAdvertisedHash() {
  if (!Native?.updatePubHash || !myNumber) return;
  const h = await myPublicHash();
  try { Native.updatePubHash(h).catch(() => {}); } catch (e) {}
}

/** تسجيل مستمع لبصمات أرقام الغرباء (لمطابقة إضافة-برقم بلا LAN). */
export function setBleStrangerListener(fn) {
  strangerListener = typeof fn === 'function' ? fn : null;
  return () => { if (strangerListener === fn) strangerListener = null; };
}

export async function refreshPinnedHashes() {
  if (!Keys) return;
  try { hashToPeer = (await Keys.listPinnedKeyHashes()) || {}; } catch (e) {}
}

async function hasPerms() {
  if (Platform.OS !== 'android') return false;
  const perms = Platform.Version >= 31
    ? [PermissionsAndroid.PERMISSIONS.BLUETOOTH_SCAN, PermissionsAndroid.PERMISSIONS.BLUETOOTH_ADVERTISE, PermissionsAndroid.PERMISSIONS.BLUETOOTH_CONNECT]
    : [PermissionsAndroid.PERMISSIONS.ACCESS_FINE_LOCATION];
  const r = await Promise.all(perms.map(p => PermissionsAndroid.check(p).catch(() => false)));
  return r.every(Boolean);
}

export async function startBlePresence({ keyHash, musabNumber = '', onPeer, onLost }) {
  if (!Native || !emitter || !keyHash) return false;
  if (!(await hasPerms())) return false;
  myNumber = String(musabNumber || '').replace(/\D/g, '');
  await refreshPinnedHashes();
  // مؤقّت تدوير بصمة الرقم العامة (البصمة الأولى تُمرَّر إلى start نفسه)
  if (!rotator) {
    rotator = setInterval(() => { refreshMyAdvertisedHash(); }, 60000);
    rotator?.unref?.();
  }
  if (!sub) {
    sub = emitter.addListener('BLE_PRESENCE', evt => {
      // بصمة رقم غريبة تُمرَّر دائماً لمستمع التعارف (لا تكشف شيئاً بلا معرفة الرقم)
      if (evt?.pubHash) {
        try { strangerListener?.({ pubHash: evt.pubHash, address: evt.address, rssi: evt.rssi }); } catch (e) {}
      }
      const peerId = hashToPeer[evt.keyHash];
      if (!peerId) {
        // غريب عليه MusabX: سجّل رؤيته بلا هوية (الخصوصية محفوظة — الاسم يصل داخل القناة فقط)
        if (evt?.address) {
          strangerSeen.set(evt.address, {
            address: evt.address,
            at: evt.receivedAt || Date.now(),
            rssi: evt.rssi,
          });
        }
        return;
      }
      const prev = lastSeen.get(peerId);
      const fresh = !prev || (evt.receivedAt - prev.at) > BLE_PRESENCE.onlineWindowMs;
      lastSeen.set(peerId, { at: evt.receivedAt || Date.now(), address: evt.address, rssi: evt.rssi });
      try { onPeer?.({ peerId, address: evt.address, rssi: evt.rssi, fresh }); } catch (e) {}
    });
  }
  if (!reaper) {
    reaper = setInterval(() => {
      const now = Date.now();
      for (const [peerId, rec] of lastSeen.entries()) {
        if (now - rec.at > BLE_PRESENCE.onlineWindowMs) { lastSeen.delete(peerId); try { onLost?.({ peerId }); } catch (e) {} }
      }
      for (const [addr, rec] of strangerSeen.entries()) {
        if (now - rec.at > BLE_PRESENCE.onlineWindowMs) strangerSeen.delete(addr);
      }
    }, BLE_PRESENCE.reapEveryMs);
  }
  const initialPubHash = await myPublicHash();
  return Native.start(keyHash, initialPubHash).catch(() => false);
}

export function blePresenceSnapshot() {
  return Array.from(lastSeen.entries()).map(([peerId, r]) => ({ peerId, ...r }));
}

/** أجهزة MusabX غريبة قريبة عبر BLE (بلا هوية — العنوان فقط للاتصال الاختياري). */
export function bleStrangerSnapshot(now = Date.now()) {
  const out = [];
  for (const [address, rec] of strangerSeen.entries()) {
    if (now - rec.at <= BLE_PRESENCE.onlineWindowMs) out.push({ address, rssi: rec.rssi, at: rec.at });
  }
  return out;
}

export function stopBlePresence() {
  if (sub) { sub.remove(); sub = null; }
  if (reaper) { clearInterval(reaper); reaper = null; }
  lastSeen.clear();
  strangerSeen.clear();
  return Native ? Native.stop().catch(() => false) : Promise.resolve(false);
}
