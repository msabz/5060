/**
 * سياسة الاتصال الذاتي — منطق نقي قابل للاختبار.
 *
 * القواعد:
 * 1. تصادم (glare): إذا كان الجهازان يريان بعضهما، واحد فقط يبادر — صاحب
 *    المعرّف الأصغر لغوياً. الآخر ينتظر مدة أطول ثم يبادر فقط إن لم يصله شيء.
 * 2. LAN فقط تلقائياً بسرعة (مهلته قصيرة ولا يقفل الجهاز). Wi-Fi Direct
 *    تلقائي فقط إذا الجهاز ظاهر فعلاً في اكتشاف P2P الحالي. Bluetooth
 *    تلقائي فقط إذا لم يتوفر أي مسار آخر وله عنوان محفوظ.
 * 3. تراجع أُسّي لكل جهاز بعد كل فشل حتى لا ندور في حلقة تقفل الجهاز.
 */

export const AUTO_CONNECT = Object.freeze({
  initiatorDelayMs: 1500,     // صاحب الأسبقية
  followerDelayMs: 25000,     // الطرف الآخر ينتظر ليستقبل
  baseBackoffMs: 30000,
  maxBackoffMs: 10 * 60 * 1000,
});

export function isInitiator(myDeviceId, peerDeviceId) {
  if (!myDeviceId || !peerDeviceId) return true;
  return String(myDeviceId) < String(peerDeviceId);
}

export function backoffFor(failures, cfg = AUTO_CONNECT) {
  if (!failures) return 0;
  return Math.min(cfg.maxBackoffMs, cfg.baseBackoffMs * Math.pow(2, failures - 1));
}

/**
 * @returns {{ transport: 'LAN'|'P2P'|'BLUETOOTH'|null, delayMs: number }|null}
 */
export function planAutoConnect({
  myDeviceId,
  peer,             // { deviceId, lanReachable, p2pVisible, btAddress }
  attempt,          // { failures, lastAt } | undefined
  now = Date.now(),
  cfg = AUTO_CONNECT,
}) {
  if (!peer?.deviceId) return null;
  const failures = attempt?.failures || 0;
  const lastAt = attempt?.lastAt || 0;
  if (now - lastAt < backoffFor(failures, cfg)) return null;

  let transport = null;
  if (peer.lanReachable) transport = 'LAN';
  else if (peer.p2pVisible) transport = 'P2P';
  else if (peer.btAddress) transport = 'BLUETOOTH';
  if (!transport) return null;

  const delayMs = isInitiator(myDeviceId, peer.deviceId)
    ? cfg.initiatorDelayMs
    : cfg.followerDelayMs;
  return { transport, delayMs };
}
