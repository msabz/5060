/**
 * جسر JS لطبقة الحضور (UDP beacon). يحوّل كل بث مستقبَل إلى تحديث في
 * سجل الأقران، ويعلن "غير متصل" لمن صمت أكثر من نافذة الحضور.
 */
import { NativeModules, NativeEventEmitter } from 'react-native';

const Native = NativeModules.PresenceBeaconModule;
const emitter = Native ? new NativeEventEmitter(Native) : null;

export const PRESENCE = Object.freeze({
  intervalMs: 25000,
  onlineWindowMs: 75000, // 3 × الفترة
  reapEveryMs: 15000,
});

const lastSeen = new Map(); // deviceId -> { at, instanceId, peer, lanHost?, lanAt?, p2pHost?, p2pAt? }

/** 192.168.49.0/24 هي شبكة Wi-Fi Direct القياسية على أندرويد. */
export function isP2pAddress(host) {
  return typeof host === 'string' && host.startsWith('192.168.49.');
}
let sub = null;
let reaper = null;
let started = false;

export function isPresenceAvailable() {
  return !!Native;
}

export async function startPresence({ deviceId, deviceName, tcpPort, onPeer, onLost }) {
  if (!Native || !emitter) return false;
  if (!sub) {
    sub = emitter.addListener('PRESENCE_BEACON', evt => {
      if (!evt?.deviceId) return;
      const prev = lastSeen.get(evt.deviceId);
      const restarted = !!prev && prev.instanceId && evt.instanceId && prev.instanceId !== evt.instanceId;
      const fresh = !prev || restarted || (evt.receivedAt - prev.at) > PRESENCE.onlineWindowMs;
      const atNow = evt.receivedAt || Date.now();
      // عنوان المرسل بحسب الواجهة التي وصل منها البث: نحتفظ بعنوان LAN وعنوان
      // Wi-Fi Direct معاً — عنوان p2p هو ما تحتاجه مستويات البيانات السريعة
      // (نقل الملفات) عندما نكون مالك المجموعة ولا نعرف IP القرين عليها.
      const rec = { at: atNow, instanceId: evt.instanceId, peer: evt };
      if (prev?.lanHost) { rec.lanHost = prev.lanHost; rec.lanAt = prev.lanAt; }
      if (prev?.p2pHost) { rec.p2pHost = prev.p2pHost; rec.p2pAt = prev.p2pAt; }
      if (evt.host) {
        if (isP2pAddress(evt.host)) { rec.p2pHost = evt.host; rec.p2pAt = atNow; }
        else { rec.lanHost = evt.host; rec.lanAt = atNow; }
      }
      lastSeen.set(evt.deviceId, rec);
      try { onPeer?.({ ...evt, fresh, restarted }); } catch (e) {}
      // جهاز جديد/عاد → نعلن عن أنفسنا فوراً حتى يرانا هو أيضاً (نمط Syncthing)
      if (fresh) Native.announceNow().catch(() => {});
    });
  }
  if (!reaper) {
    reaper = setInterval(() => {
      const now = Date.now();
      for (const [id, rec] of lastSeen.entries()) {
        if (now - rec.at > PRESENCE.onlineWindowMs) {
          lastSeen.delete(id);
          try { onLost?.(rec.peer); } catch (e) {}
        }
      }
    }, PRESENCE.reapEveryMs);
  }
  started = await Native.start(deviceId, deviceName || '', tcpPort || 0, PRESENCE.intervalMs).catch(() => false);
  return started;
}

export function setPresenceExtra(fields) {
  if (Native) { try { Native.setExtra(JSON.stringify(fields || {})); } catch (e) {} }
}

export function updatePresence({ deviceName, tcpPort }) {
  if (Native && started) Native.update(deviceName || '', tcpPort || 0);
}

export function announcePresenceNow() {
  if (Native && started) return Native.announceNow().catch(() => false);
  return Promise.resolve(false);
}

export function stopPresence() {
  if (sub) { sub.remove(); sub = null; }
  if (reaper) { clearInterval(reaper); reaper = null; }
  lastSeen.clear();
  started = false;
  if (Native) return Native.stop().catch(() => false);
  return Promise.resolve(false);
}

export function presenceSnapshot() {
  return Array.from(lastSeen.values()).map(r => ({
    ...r.peer,
    lanHost: r.lanHost || null,
    p2pHost: r.p2pHost || null,
  }));
}

/** عنوان Wi-Fi Direct الطازج لجهاز معيّن (أقل من نافذة الحضور) — لمستوى البيانات. */
export function presenceP2pHost(deviceId, now = Date.now()) {
  const rec = lastSeen.get(deviceId);
  if (!rec?.p2pHost || !rec.p2pAt) return null;
  return (now - rec.p2pAt) <= PRESENCE.onlineWindowMs ? rec.p2pHost : null;
}
