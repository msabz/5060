/**
 * جسر JS لطبقة الحضور (UDP beacon). يحوّل كل بث مستقبَل إلى تحديث في
 * سجل الأقران، ويعلن "غير متصل" لمن صمت أكثر من نافذة الحضور.
 */
import { NativeModules, NativeEventEmitter } from 'react-native';

const Native = NativeModules.PresenceBeaconModule;
const emitter = Native ? new NativeEventEmitter(Native) : null;

export const PRESENCE = Object.freeze({
  intervalMs: 25000,
  onlineWindowMs: 75000, // 3 × الفترة
  reapEveryMs: 15000,
});

const lastSeen = new Map(); // deviceId -> { at, instanceId, peer }
let sub = null;
let reaper = null;
let started = false;

export function isPresenceAvailable() {
  return !!Native;
}

export async function startPresence({ deviceId, deviceName, tcpPort, onPeer, onLost }) {
  if (!Native || !emitter) return false;
  if (!sub) {
    sub = emitter.addListener('PRESENCE_BEACON', evt => {
      if (!evt?.deviceId) return;
      const prev = lastSeen.get(evt.deviceId);
      const restarted = !!prev && prev.instanceId && evt.instanceId && prev.instanceId !== evt.instanceId;
      const fresh = !prev || restarted || (evt.receivedAt - prev.at) > PRESENCE.onlineWindowMs;
      lastSeen.set(evt.deviceId, { at: evt.receivedAt || Date.now(), instanceId: evt.instanceId, peer: evt });
      try { onPeer?.({ ...evt, fresh, restarted }); } catch (e) {}
      // جهاز جديد/عاد → نعلن عن أنفسنا فوراً حتى يرانا هو أيضاً (نمط Syncthing)
      if (fresh) Native.announceNow().catch(() => {});
    });
  }
  if (!reaper) {
    reaper = setInterval(() => {
      const now = Date.now();
      for (const [id, rec] of lastSeen.entries()) {
        if (now - rec.at > PRESENCE.onlineWindowMs) {
          lastSeen.delete(id);
          try { onLost?.(rec.peer); } catch (e) {}
        }
      }
    }, PRESENCE.reapEveryMs);
  }
  started = await Native.start(deviceId, deviceName || '', tcpPort || 0, PRESENCE.intervalMs).catch(() => false);
  return started;
}

export function updatePresence({ deviceName, tcpPort }) {
  if (Native && started) Native.update(deviceName || '', tcpPort || 0);
}

export function announcePresenceNow() {
  if (Native && started) return Native.announceNow().catch(() => false);
  return Promise.resolve(false);
}

export function stopPresence() {
  if (sub) { sub.remove(); sub = null; }
  if (reaper) { clearInterval(reaper); reaper = null; }
  lastSeen.clear();
  started = false;
  if (Native) return Native.stop().catch(() => false);
  return Promise.resolve(false);
}

export function presenceSnapshot() {
  return Array.from(lastSeen.values()).map(r => r.peer);
}
