/**
 * محرك الروابط المتعددة — النموذج المعتمد من الدراسة:
 *
 * [KDE Connect `Device.kt`] كل الروابط حية معاً لكل جهة، مرتبة بالأولوية،
 * والإرسال يجرّب الأفضل فالأدنى (`links.any`) — لا يوجد «حدث تبديل»: رابط
 * أعلى يُضاف فينساب الإرسال إليه فوراً، ورابط ميت يُحذف فلا يتوقف شيء.
 *
 * [Briar `ConnectionRegistryImpl`] ازدواج نفس الناقل يُحسم بكسر تعادل nonce:
 * الرابط صاحب nonce الأعلى يبقى، والأدنى يُقاطع — يمنع سباق الاتصالين المتزامنين.
 *
 * الواجهة لا تكذب: isReachable(peer) = يوجد رابط حي واحد على الأقل.
 */

// أولويات الدراسة (KDE موسّعة): LAN أعلى ثم Wi-Fi Direct ثم Bluetooth.
// I2P لاحقاً تنضم هنا بأدنى أولوية دون لمس المحرك (docs/I2P_TRANSPORT_READINESS).
export const LINK_PRIORITY = Object.freeze({
  LAN: 30,
  P2P: 20,
  BLUETOOTH: 10,
});

function priorityOf(transport) {
  return LINK_PRIORITY[transport] || 0;
}

export class LinkManager {
  constructor() {
    this.peers = new Map();       // peerId -> Map<transport, Link>
    this.listeners = new Set();
  }

  /**
   * رابط حي واحد: { transport, send(msg)->boolean|Promise<boolean>, nonce,
   * close?(graceful), label? } — send تعيد false إن فشل الإرسال لحظياً.
   */
  registerLink(peerId, link) {
    if (!peerId || !link || !link.transport || typeof link.send !== 'function') return null;
    let map = this.peers.get(peerId);
    if (!map) {
      map = new Map();
      this.peers.set(peerId, map);
    }
    const existing = map.get(link.transport);
    if (existing) {
      // كسر تعادل Briar لنفس الناقل: nonce الأعلى يبقى؛ التعادل يبقي القائم.
      const existingNonce = Number(existing.nonce) || 0;
      const incomingNonce = Number(link.nonce) || 0;
      if (incomingNonce < existingNonce) {
        return { replaced: false, kept: 'existing', transport: link.transport };
      }
      if (incomingNonce === existingNonce && existingNonce !== 0) {
        return { replaced: false, kept: 'existing', transport: link.transport };
      }
      try { existing.close && existing.close('superseded'); } catch (e) {}
    }
    map.set(link.transport, { ...link, priority: priorityOf(link.transport), upAt: Date.now() });
    this._emit({ type: 'link-up', peerId, transport: link.transport });
    return { replaced: !!existing, kept: 'new', transport: link.transport };
  }

  unregisterLink(peerId, transport, reason = 'down') {
    const map = this.peers.get(peerId);
    if (!map || !map.has(transport)) return false;
    map.delete(transport);
    if (map.size === 0) this.peers.delete(peerId);
    this._emit({ type: 'link-down', peerId, transport, reason });
    return true;
  }

  /** أفضل رابط حي (أعلى أولوية) أو null — نظير links.firstOrNull() في KDE. */
  bestLink(peerId) {
    const map = this.peers.get(peerId);
    if (!map || map.size === 0) return null;
    return [...map.values()].sort((a, b) => b.priority - a.priority)[0];
  }

  /**
   * إرسال عبر الأفضل مع سقوط فوري للأدنى — نظير `links.any {}` في KDE.
   * preferred (اختياري) يقدَّم أولاً دون كسر ترتيب الباقي.
   * يعيد الناقل المستخدم، أو null إن لم ينجح أي رابط.
   */
  async send(peerId, message, { preferred = null } = {}) {
    const map = this.peers.get(peerId);
    if (!map || map.size === 0) return null;
    const links = [...map.values()].sort((a, b) => b.priority - a.priority);
    if (preferred && map.has(preferred)) {
      const idx = links.findIndex(l => l.transport === preferred);
      if (idx > 0) links.unshift(links.splice(idx, 1)[0]);
    }
    for (const link of links) {
      try {
        const ok = await link.send(message);
        if (ok) return link.transport;
      } catch (e) { /* الرابط ميت عملياً — جرّب الأدنى */ }
      // كتابة فاشلة = رابط زومبي: أزلْه فوراً كي يُطلَق حدث link-down وتكف
      // الواجهة عن إظهار «متصل» كاذبة — «متصل» تعني رابطاً يكتب فعلاً (KDE).
      this.unregisterLink(peerId, link.transport, 'send-failed');
    }
    return null;
  }

  getTransports(peerId) {
    const map = this.peers.get(peerId);
    return map ? [...map.keys()] : [];
  }

  /** الواجهة الصادقة: «متصل» يعني رابطاً حياً واحداً على الأقل (KDE). */
  isReachable(peerId) {
    const map = this.peers.get(peerId);
    return !!map && map.size > 0;
  }

  /** الروابط الأدنى من ناقل معيّن — لإحالتها بأدب بعد ترقية ناجحة (Briar). */
  lowerLinks(peerId, transport) {
    const map = this.peers.get(peerId);
    if (!map) return [];
    const threshold = priorityOf(transport);
    return [...map.values()].filter(l => l.priority < threshold);
  }

  clearPeer(peerId) {
    const map = this.peers.get(peerId);
    if (!map) return;
    for (const transport of [...map.keys()]) {
      this.unregisterLink(peerId, transport, 'cleared');
    }
  }

  /** استبدال معرّف مؤقت (p2p:/bt:) بالمستقر عند وصول الهوية — ينقل كل الروابط. */
  rekeyPeer(oldId, newId) {
    if (!oldId || !newId || oldId === newId) return false;
    const map = this.peers.get(oldId);
    if (!map) return false;
    const existing = this.peers.get(newId);
    if (existing) {
      // دمج: الرابط الأحدث يبقى لكل ناقل
      for (const [transport, link] of map) {
        const cur = existing.get(transport);
        if (!cur || (link.upAt || 0) >= (cur.upAt || 0)) existing.set(transport, link);
      }
      this.peers.delete(oldId);
    } else {
      this.peers.delete(oldId);
      this.peers.set(newId, map);
    }
    this._emit({ type: 'link-rekey', from: oldId, to: newId });
    return true;
  }

  /** كل المفاتيح المؤقتة تُدمج في المعرّف المستقر عند اكتمال الهوية. */
  rekeyProvisionalInto(stableId, isProvisional) {
    if (!stableId || typeof isProvisional !== 'function') return;
    for (const key of [...this.peers.keys()]) {
      if (key !== stableId && isProvisional(key)) this.rekeyPeer(key, stableId);
    }
  }

  onChange(listener) {
    this.listeners.add(listener);
    return () => this.listeners.delete(listener);
  }

  _emit(event) {
    for (const listener of this.listeners) {
      try { listener(event); } catch (e) {}
    }
  }
}

export const linkManager = new LinkManager();
