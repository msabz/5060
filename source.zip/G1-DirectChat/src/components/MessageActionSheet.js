import React from 'react';
import { Modal, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import { messagePreview } from '../messaging/messageModel';

function messageTypeDetails(message) {
  switch (message?.type) {
    case 'image':
      return { icon: '▧', label: 'صورة' };
    case 'voice':
      return { icon: '◖', label: 'رسالة صوتية' };
    case 'file':
      return { icon: '▤', label: 'ملف' };
    case 'call':
      return { icon: '◉', label: 'سجل مكالمة' };
    default:
      return { icon: '✦', label: 'رسالة نصية' };
  }
}

/**
 * قائمة إجراءات الرسالة بأسلوب واتساب: خلفية معتمة، فقاعة الرسالة تطفو
 * بالمنتصف، وتحتها بطاقة قائمة مضغوطة بصفوف (رد / نسخ / مشاركة / حذف).
 */
export default function MessageActionSheet({
  visible,
  message,
  theme,
  onClose,
  onReply,
  onCopy,
  onShare,
  onDelete,
}) {
  const details = messageTypeDetails(message);
  const senderLabel = message?.sender === 'me' ? 'مرسلة منك' : 'واردة';
  const actions = [
    {
      key: 'reply',
      icon: '↩',
      label: 'رد',
      description: 'اقتباس الرسالة في ردك',
      accessibilityLabel: 'الرد على الرسالة',
      accessibilityHint: 'يضيف اقتباساً من الرسالة إلى حقل الكتابة',
      onPress: onReply,
    },
    {
      key: 'copy',
      icon: '⧉',
      label: 'نسخ',
      description: 'حفظ المحتوى في الحافظة',
      accessibilityLabel: 'نسخ الرسالة',
      accessibilityHint: 'ينسخ محتوى الرسالة إلى حافظة الجهاز',
      onPress: onCopy,
    },
    {
      key: 'share',
      icon: '↗',
      label: 'مشاركة',
      description: 'إرسالها إلى تطبيق آخر',
      accessibilityLabel: 'مشاركة الرسالة',
      accessibilityHint: 'يفتح قائمة تطبيقات المشاركة في النظام',
      onPress: onShare,
    },
    {
      key: 'delete',
      icon: '⌫',
      label: 'حذف محلي',
      description: 'من هذا الجهاز فقط',
      accessibilityLabel: 'حذف الرسالة محلياً',
      accessibilityHint: 'يحذف الرسالة من هذا الجهاز فقط بعد التأكيد',
      onPress: onDelete,
      destructive: true,
    },
  ];

  return (
    <Modal
      visible={visible}
      transparent
      animationType="fade"
      statusBarTranslucent
      hardwareAccelerated
      onRequestClose={onClose}
    >
      <View style={styles.root}>
        <TouchableOpacity
          testID="message-actions-backdrop"
          style={[styles.backdrop, { backgroundColor: theme.overlay }]}
          activeOpacity={1}
          accessible={false}
          onPress={onClose}
        />

        <View
          testID="message-actions-sheet"
          style={[
            styles.sheet,
            { backgroundColor: theme.surface, borderColor: theme.border },
          ]}
          accessibilityViewIsModal
          importantForAccessibility="yes"
        >
          <View style={styles.header}>
            <View style={styles.headerCopy}>
              <Text
                style={[styles.title, { color: theme.text }]}
                accessibilityRole="header"
              >
                {details.label} · {senderLabel}
              </Text>
            </View>
            <TouchableOpacity
              testID="message-actions-close"
              style={[styles.closeButton, { backgroundColor: theme.surfaceVariant }]}
              onPress={onClose}
              accessibilityRole="button"
              accessibilityLabel="إغلاق خيارات الرسالة"
              accessibilityHint="يغلق القائمة ويعود إلى المحادثة"
              hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
            >
              <Text style={[styles.closeIcon, { color: theme.textSecondary }]}>✕</Text>
            </TouchableOpacity>
          </View>

          <View
            testID="message-actions-preview"
            style={[styles.preview, { backgroundColor: theme.surfaceVariant }]}
            accessible
            accessibilityLabel={`الرسالة المحددة: ${messagePreview(message)}`}
          >
            <View style={[styles.previewIcon, { backgroundColor: theme.surfaceSubtle }]}>
              <Text style={[styles.previewIconText, { color: theme.primary }]}>{details.icon}</Text>
            </View>
            <Text style={[styles.previewText, { color: theme.text }]} numberOfLines={2}>
              {messagePreview(message)}
            </Text>
          </View>

          <View style={styles.actionList}>
            {actions.map((action, index) => {
              const actionColor = action.destructive ? theme.error : theme.text;
              const enabled = typeof action.onPress === 'function';
              return (
                <React.Fragment key={action.key}>
                  {index > 0 ? (
                    <View style={[styles.rowDivider, { backgroundColor: theme.border }]} />
                  ) : null}
                  <TouchableOpacity
                    testID={`message-action-${action.key}`}
                    style={[
                      styles.action,
                      {
                        backgroundColor: theme.surfaceSubtle,
                        borderColor: action.destructive ? theme.error : theme.border,
                        opacity: enabled ? 1 : 0.45,
                      },
                    ]}
                    activeOpacity={0.72}
                    disabled={!enabled}
                    onPress={action.onPress}
                    accessibilityRole="button"
                    accessibilityLabel={action.accessibilityLabel}
                    accessibilityHint={action.accessibilityHint}
                    accessibilityState={{ disabled: !enabled }}
                  >
                    <Text style={[styles.actionLabel, { color: actionColor }]}>{action.label}</Text>
                    <Text style={[styles.actionRowIcon, { color: action.destructive ? theme.error : theme.primary }]}>
                      {action.icon}
                    </Text>
                  </TouchableOpacity>
                </React.Fragment>
              );
            })}
          </View>

          <Text
            testID="message-actions-local-delete-note"
            style={[styles.localDeleteNote, { color: theme.textMuted }]}
          >
            الحذف محلي ولا يزيل الرسالة من جهاز الطرف الآخر
          </Text>
        </View>
      </View>
    </Modal>
  );
}

const styles = StyleSheet.create({
  root: {
    flex: 1,
    justifyContent: 'center',
  },
  backdrop: {
    ...StyleSheet.absoluteFillObject,
  },
  sheet: {
    width: '84%',
    maxWidth: 340,
    alignSelf: 'center',
    direction: 'rtl',
    borderRadius: 16,
    borderWidth: StyleSheet.hairlineWidth,
    paddingHorizontal: 14,
    paddingTop: 10,
    paddingBottom: 14,
    elevation: 18,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.3,
    shadowRadius: 16,
  },
  header: {
    minHeight: 44,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
  },
  headerCopy: {
    flex: 1,
  },
  title: {
    textAlign: 'right',
    fontSize: 13,
    lineHeight: 18,
    fontWeight: '600',
  },
  closeButton: {
    width: 48,
    height: 48,
    borderRadius: 24,
    alignItems: 'center',
    justifyContent: 'center',
    marginVertical: -6,
  },
  closeIcon: {
    fontSize: 16,
    lineHeight: 20,
    fontWeight: '700',
  },
  preview: {
    minHeight: 52,
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 12,
    paddingHorizontal: 10,
    paddingVertical: 8,
    marginTop: 4,
    marginBottom: 10,
    gap: 10,
  },
  previewIcon: {
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: 'center',
    justifyContent: 'center',
  },
  previewIconText: {
    fontSize: 17,
    lineHeight: 21,
    fontWeight: '700',
  },
  previewText: {
    flex: 1,
    textAlign: 'right',
    writingDirection: 'auto',
    fontSize: 14,
    lineHeight: 20,
    fontWeight: '500',
  },
  actionList: {
    borderRadius: 12,
    overflow: 'hidden',
  },
  action: {
    minHeight: 48,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    borderWidth: 0,
    paddingHorizontal: 14,
    gap: 10,
  },
  actionLabel: {
    textAlign: 'right',
    fontSize: 15.5,
    lineHeight: 21,
    fontWeight: '500',
    writingDirection: 'rtl',
  },
  actionRowIcon: {
    fontSize: 17,
    lineHeight: 21,
    fontWeight: '700',
  },
  rowDivider: {
    height: StyleSheet.hairlineWidth,
    marginHorizontal: 14,
  },
  localDeleteNote: {
    textAlign: 'center',
    fontSize: 11,
    lineHeight: 16,
    marginTop: 10,
    writingDirection: 'rtl',
  },
});
