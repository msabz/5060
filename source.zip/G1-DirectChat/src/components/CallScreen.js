import React, { useState, useEffect, useRef } from 'react';
import {
  View, StyleSheet, TouchableOpacity, Text, StatusBar, Animated, Easing,
} from 'react-native';
import { RTCView } from 'react-native-webrtc';
import * as RTCAudio from '../media/WebRTCAudio';
import { WA } from '../theme';
import { avatarPalette } from '../theme/tokens';

function formatDuration(sec) {
  const m = Math.floor(sec / 60).toString().padStart(2, '0');
  const s = (sec % 60).toString().padStart(2, '0');
  return `${m}:${s}`;
}

/** حلقة نبض حول الأفاتار أثناء الانتظار — نبضة "القرب" الخاصة بـ MusabX. */
function PulseAvatar({ name }) {
  const [c1, c2] = avatarPalette(name || 'M');
  const scale = useRef(new Animated.Value(1)).current;
  const fade = useRef(new Animated.Value(0.55)).current;

  useEffect(() => {
    const loop = Animated.loop(
      Animated.parallel([
        Animated.sequence([
          Animated.timing(scale, { toValue: 1.35, duration: 1400, easing: Easing.out(Easing.quad), useNativeDriver: true }),
          Animated.timing(scale, { toValue: 1, duration: 0, useNativeDriver: true }),
        ]),
        Animated.sequence([
          Animated.timing(fade, { toValue: 0, duration: 1400, easing: Easing.out(Easing.quad), useNativeDriver: true }),
          Animated.timing(fade, { toValue: 0.55, duration: 0, useNativeDriver: true }),
        ]),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [scale, fade]);

  return (
    <View style={styles.pulseWrap}>
      <Animated.View
        style={[
          styles.pulseRing,
          { borderColor: c2, opacity: fade, transform: [{ scale }] },
        ]}
      />
      <View style={[styles.bigAvatar, { backgroundColor: c1 }]}>
        <View style={[styles.bigAvatarArc, { backgroundColor: c2 }]} />
        <Text style={styles.bigAvatarText}>{(name || 'M')[0].toUpperCase()}</Text>
      </View>
    </View>
  );
}

export default function CallScreen({
  onToggleCamera, onToggleMute, onEndCall, onToggleSpeaker, onSetVolume,
  peerName, videoEnabled, audioEngine, audioDiag, rtcLog,
  routeUnstable, remoteVideoOn = true, localStreamURL: pushedLocal, remoteStreamURL: pushedRemote,
}) {
  const [cameraOn, setCameraOn] = useState(!!videoEnabled);
  const [muted, setMuted] = useState(false);
  const [speaker, setSpeaker] = useState(!!videoEnabled);
  const [seconds, setSeconds] = useState(0);
  const [controlsVisible, setControlsVisible] = useState(true);
  const [volumeStep, setVolumeStep] = useState(videoEnabled ? 2 : 4);
  const [localStreamURL, setLocalStreamURL] = useState(null);
  const [remoteStreamURL, setRemoteStreamURL] = useState(null);

  // Duration belongs to the established RTC media session, not to the moment
  // each phone happened to mount CallScreen. Physical tests showed a healthy
  // ICE/PC connection while both screens still displayed "جاري الاتصال" and
  // their timers differed substantially because they started at UI mount time.
  useEffect(() => {
    setSeconds(0);
    if (audioEngine !== 'webrtc') return undefined;
    const t = setInterval(() => setSeconds(s => s + 1), 1000);
    return () => clearInterval(t);
  }, [audioEngine]);

  useEffect(() => {
    if (!controlsVisible) return;
    const t = setTimeout(() => setControlsVisible(false), 6000);
    return () => clearTimeout(t);
  }, [controlsVisible]);

  // المسارات تُدفع من WebRTCAudio عند تغيّرها (بدل استعلام كل 150ms كان
  // يعيد رسم RTCView ويحمّل الجسر أثناء الفيديو). نُبقي استعلاماً واحداً
  // عند الدخول كاحتياط لو وصلت الشاشة بعد بدء المسار.
  useEffect(() => {
    if (!videoEnabled) {
      setLocalStreamURL(null);
      setRemoteStreamURL(null);
      return;
    }
    setLocalStreamURL(pushedLocal ?? RTCAudio.getLocalStreamURL());
    setRemoteStreamURL(pushedRemote ?? RTCAudio.getRemoteStreamURL());
  }, [videoEnabled, pushedLocal, pushedRemote, audioEngine]);

  const hasRemoteVideo = !!videoEnabled && !!remoteStreamURL && remoteVideoOn;
  const hasLocalVideo = !!videoEnabled && !!localStreamURL && cameraOn;
  const waitingStatus = routeUnstable
    ? 'الاتصال غير مستقر — جاري إعادة الوصل…'
    : audioEngine === 'webrtc'
      ? (videoEnabled
          ? (remoteVideoOn ? 'متصل — جاري انتظار الفيديو…' : 'الطرف الآخر أطفأ الكاميرا')
          : 'متصل عبر WebRTC')
      : audioEngine === 'failed'
        ? 'تعذّر إنشاء مسار WebRTC'
        : (videoEnabled ? 'جاري تشغيل فيديو WebRTC…' : 'جاري الاتصال…');

  return (
    <TouchableOpacity
      activeOpacity={1}
      onPress={() => setControlsVisible(v => !v)}
      style={styles.container}
    >
      <StatusBar backgroundColor="#000" barStyle="light-content" />

      {hasRemoteVideo ? (
        <RTCView
          key={`remote-${remoteStreamURL}`}
          streamURL={remoteStreamURL}
          style={StyleSheet.absoluteFill}
          objectFit="cover"
          mirror={false}
          zOrder={0}
        />
      ) : (
        <View style={styles.waitingScreen}>
          <PulseAvatar name={peerName} />
          <Text style={styles.waitingName}>{peerName || 'MusabX'}</Text>
          <Text style={styles.waitingStatus}>{waitingStatus}</Text>
        </View>
      )}

      {routeUnstable && (
        <View style={styles.unstableBanner}>
          <Text style={styles.unstableText}>⚠️ الاتصال غير مستقر — جاري إعادة الوصل…</Text>
        </View>
      )}

      {controlsVisible && (
        <View style={styles.topBar}>
          <Text style={styles.topName}>{peerName || 'MusabX'}</Text>
          <Text style={styles.topTimer}>{formatDuration(seconds)}</Text>
          <Text style={styles.topEncrypted}>
            {audioEngine === 'webrtc'
              ? '🔒 مكالمة مباشرة مشفّرة · بلا خوادم'
              : audioEngine === 'failed'
                ? '⚠️ تعذّر فتح مسار الصوت'
                : '🔒 جاري الاتصال…'}
          </Text>
        </View>
      )}

      {controlsVisible && __DEV__ && rtcLog && rtcLog.length > 0 && (
        <View style={styles.diagBox}>
          {rtcLog.map((line, i) => (
            <Text key={i} style={styles.diagLine} numberOfLines={1}>{line}</Text>
          ))}
        </View>
      )}

      {hasLocalVideo && (
        <View style={styles.pipContainer}>
          <RTCView
            key={`local-${localStreamURL}`}
            streamURL={localStreamURL}
            style={styles.pip}
            objectFit="cover"
            mirror
            zOrder={1}
          />
        </View>
      )}

      {controlsVisible && (
        <View style={styles.controlsWrap}>
          <View style={styles.volRow}>
            <TouchableOpacity
              onPress={() => {
                const next = Math.max(0, volumeStep - 1);
                setVolumeStep(next);
                onSetVolume && onSetVolume(next / 5);
              }}
              style={styles.volBtn}
            >
              <Text style={styles.volBtnText}>−</Text>
            </TouchableOpacity>

            <View style={styles.volBars}>
              {[0, 1, 2, 3, 4].map(i => (
                <View key={i} style={[styles.volBar, i < volumeStep && styles.volBarOn]} />
              ))}
            </View>

            <TouchableOpacity
              onPress={() => {
                const next = Math.min(5, volumeStep + 1);
                setVolumeStep(next);
                onSetVolume && onSetVolume(next / 5);
              }}
              style={styles.volBtn}
            >
              <Text style={styles.volBtnText}>+</Text>
            </TouchableOpacity>
          </View>

          <View style={styles.controlsRow}>
            <TouchableOpacity
              onPress={() => RTCAudio.switchCamera().catch(() => {})}
              style={styles.ctrlBtn}
            >
              <Text style={styles.ctrlIcon}>🔄</Text>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => {
                const on = onToggleCamera();
                setCameraOn(on);
                RTCAudio.setCameraEnabled(on);
              }}
              style={[styles.ctrlBtn, !cameraOn && styles.ctrlBtnOff]}
            >
              <Text style={styles.ctrlIcon}>{cameraOn ? '🎥' : '🚫'}</Text>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => { const on = onToggleMute(); setMuted(on); }}
              style={[styles.ctrlBtn, muted && styles.ctrlBtnOff]}
            >
              <Text style={styles.ctrlIcon}>{muted ? '🔇' : '🎤'}</Text>
            </TouchableOpacity>

            <TouchableOpacity
              onPress={() => {
                const next = !speaker;
                setSpeaker(next);
                onToggleSpeaker && onToggleSpeaker(next);
              }}
              style={[styles.ctrlBtn, !speaker && styles.ctrlBtnOff]}
            >
              <Text style={styles.ctrlIcon}>{speaker ? '🔊' : '👂'}</Text>
            </TouchableOpacity>

            <TouchableOpacity onPress={onEndCall} style={styles.endBtn}>
              <Text style={styles.endIcon}>📞</Text>
            </TouchableOpacity>
          </View>
        </View>
      )}
    </TouchableOpacity>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#070B16' },
  waitingScreen: { ...StyleSheet.absoluteFillObject, justifyContent: 'center', alignItems: 'center', backgroundColor: '#070B16' },

  pulseWrap: { width: 150, height: 150, justifyContent: 'center', alignItems: 'center', marginBottom: 22 },
  pulseRing: {
    position: 'absolute', width: 132, height: 132, borderRadius: 66,
    borderWidth: 2.5,
  },
  bigAvatar: {
    width: 118, height: 118, borderRadius: 59, overflow: 'hidden',
    justifyContent: 'center', alignItems: 'center',
  },
  bigAvatarArc: {
    position: 'absolute', width: 135, height: 135, borderRadius: 70,
    opacity: 0.85, bottom: -72, left: -32, transform: [{ rotate: '24deg' }],
  },
  bigAvatarText: {
    color: '#fff', fontSize: 46, fontWeight: '800',
    textShadowColor: 'rgba(0,0,0,0.3)', textShadowRadius: 3, textShadowOffset: { width: 0, height: 1 },
  },
  waitingName: { color: '#fff', fontSize: 25, fontWeight: '700', letterSpacing: 0.3 },
  waitingStatus: { color: 'rgba(255,255,255,0.55)', fontSize: 14.5, marginTop: 8, fontWeight: '500' },

  topBar: {
    position: 'absolute', top: 0, left: 0, right: 0,
    marginHorizontal: 16, marginTop: 34, borderRadius: 20,
    paddingVertical: 12, alignItems: 'center',
    backgroundColor: 'rgba(7,11,22,0.55)',
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.09)',
  },
  topName: { color: '#fff', fontSize: 18, fontWeight: '700' },
  topTimer: { color: 'rgba(255,255,255,0.85)', fontSize: 13, marginTop: 3, fontVariant: ['tabular-nums'] },
  topEncrypted: { color: 'rgba(255,255,255,0.55)', fontSize: 11, marginTop: 6, fontWeight: '600' },

  unstableBanner: {
    position: 'absolute', top: 120, left: 20, right: 20, zIndex: 5,
    backgroundColor: 'rgba(255,178,36,0.94)', borderRadius: 14, padding: 10, alignItems: 'center',
  },
  unstableText: { color: '#241A02', fontSize: 13, fontWeight: '700' },

  diagBox: {
    position: 'absolute', top: 150, left: 10, right: 130,
    backgroundColor: 'rgba(0,0,0,0.6)', borderRadius: 10, padding: 8,
  },
  diagLine: { color: '#9FE8A0', fontSize: 10, fontFamily: 'monospace' },

  pipContainer: {
    position: 'absolute', top: 128, right: 16,
    width: 104, height: 148, borderRadius: 16, overflow: 'hidden',
    backgroundColor: '#000', elevation: 8,
    borderWidth: 1.5, borderColor: 'rgba(255,255,255,0.22)',
    shadowColor: '#000', shadowOpacity: 0.4, shadowRadius: 10, shadowOffset: { width: 0, height: 4 },
  },
  pip: { width: '100%', height: '100%' },

  controlsWrap: {
    position: 'absolute', bottom: 0, left: 0, right: 0,
    marginHorizontal: 16, marginBottom: 30, borderRadius: 26,
    paddingBottom: 18, paddingTop: 18,
    backgroundColor: 'rgba(7,11,22,0.55)',
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.09)',
  },
  volRow: {
    flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center',
    gap: 14, marginBottom: 18,
  },
  volBtn: {
    width: 38, height: 38, borderRadius: 19,
    backgroundColor: 'rgba(255,255,255,0.14)',
    justifyContent: 'center', alignItems: 'center',
  },
  volBtnText: { color: '#fff', fontSize: 20, fontWeight: '600' },
  volBars: { flexDirection: 'row-reverse', gap: 5, alignItems: 'flex-end' },
  volBar: { width: 7, height: 18, borderRadius: 3.5, backgroundColor: 'rgba(255,255,255,0.22)' },
  volBarOn: { backgroundColor: '#00E5D0' },

  controlsRow: { flexDirection: 'row-reverse', justifyContent: 'center', alignItems: 'center', gap: 16 },
  ctrlBtn: {
    width: 58, height: 58, borderRadius: 29,
    backgroundColor: 'rgba(255,255,255,0.14)',
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.1)',
    justifyContent: 'center', alignItems: 'center',
  },
  ctrlBtnOff: { backgroundColor: 'rgba(255,255,255,0.88)' },
  ctrlIcon: { fontSize: 22 },
  endBtn: {
    width: 66, height: 66, borderRadius: 33, backgroundColor: WA.danger,
    justifyContent: 'center', alignItems: 'center',
    transform: [{ rotate: '135deg' }],
    shadowColor: WA.danger, shadowOpacity: 0.5, shadowRadius: 12,
    shadowOffset: { width: 0, height: 4 }, elevation: 8,
  },
  endIcon: { fontSize: 25 },
});
