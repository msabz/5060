/**
 * الشاشة الرئيسية لـ MusabX — نمط واتساب حرفياً (داكن):
 * شريط علوي (الاسم + مسح QR + بحث + قائمة)، تنقّل سفلي
 * (الدردشات / القريبون / المكالمات)، قائمة بأفاتار ومعاينة وشارة،
 * وزر عائم لبدء محادثة جديدة. لا مصطلحات شبكات للمستخدم.
 */
import React, { useMemo, useState } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity, Modal, TextInput,
  SafeAreaView, StatusBar, Share,
} from 'react-native';
import Avatar from './common/Avatar';
import { encodeQR } from '../utils/qr';
import { W, waListTime } from '../theme/whatsapp';

function QRView({ value, size = 210, dark = '#0B141A', light = '#FFFFFF' }) {
  const matrix = useMemo(() => { try { return encodeQR(value); } catch (e) { return null; } }, [value]);
  if (!matrix) return null;
  const n = matrix.length;
  const cell = size / (n + 8);
  return (
    <View style={{
      width: size + cell * 8, height: size + cell * 8, backgroundColor: light,
      padding: cell * 4, borderRadius: 20, alignItems: 'center', justifyContent: 'center',
    }}>
      <View style={{ width: size, height: size }}>
        {matrix.map((row, r) => (
          <View key={r} style={{ flexDirection: 'row', height: cell }}>
            {row.map((on, c) => (
              <View key={c} style={{ width: cell, height: cell, backgroundColor: on ? dark : light }} />
            ))}
          </View>
        ))}
      </View>
    </View>
  );
}

/** ترويسة فيدباك لصف محادثة: ✓ / ✓✓ زرقاء عند القراءة */
function RowTicks({ status }) {
  if (!status) return null;
  if (status === 'sending') return <Text style={s.tick}>🕐</Text>;
  if (status === 'failed') return <Text style={[s.tick, { color: W.danger }]}>⚠</Text>;
  const color = status === 'read' ? W.tick : W.textMuted;
  return <Text style={[s.tick, { color }]}>{status === 'sent' ? '✓' : '✓✓'}</Text>;
}

const TABS = [
  { key: 'chats', label: 'الدردشات', icon: '💬' },
  { key: 'nearby', label: 'القريبون', icon: '📡' },
  { key: 'calls', label: 'المكالمات', icon: '📞' },
];

export default function HomeScreen({
  myName = 'أنا',
  myMusabNumber = null,
  myMusabId = null,
  contacts = [],
  nearby = [],
  callRecords = [],
  activePeer = null,
  unreadCount = 0,
  onOpenChat,
  onAddNearby,
  onAddByCode,
  onOpenMore,
  onScanQr,
}) {
  const [tab, setTab] = useState('chats');
  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [addVisible, setAddVisible] = useState(false);
  const [addMode, setAddMode] = useState('menu'); // menu | number | myqr
  const [code, setCode] = useState('');
  const [menuOpen, setMenuOpen] = useState(false);

  const myLink = `musabx://add?n=${(myMusabNumber || '').replace(/\s/g, '')}&id=${myMusabId || ''}`;

  const chatList = useMemo(() => {
    const q = query.trim();
    const list = q
      ? contacts.filter(c => (c.customName || c.name || c.deviceName || '').includes(q))
      : [...contacts];
    return list.sort((a, b) => {
      const aActive = activePeer && activePeer.peerId === a.peerId;
      const bActive = activePeer && activePeer.peerId === b.peerId;
      if (!!aActive !== !!bActive) return aActive ? -1 : 1;
      return (b.lastTime || 0) - (a.lastTime || 0);
    });
  }, [contacts, query, activePeer]);

  const nearbyFiltered = useMemo(() => {
    const q = query.trim();
    if (!q) return nearby;
    return nearby.filter(n => (n.deviceName || '').includes(q) || (n.musabNumber || '').includes(q));
  }, [nearby, query]);

  const callsFiltered = useMemo(() => {
    const q = query.trim();
    if (!q) return callRecords;
    return callRecords.filter(r => (r.peerName || r.name || '').includes(q));
  }, [callRecords, query]);

  /* ---------- صف محادثة (واتساب) ---------- */
  const renderChat = ({ item }) => {
    const name = item.customName || item.name || item.deviceName || 'جهة اتصال';
    const isActive = activePeer && activePeer.peerId === item.peerId;
    const preview = item.lastMessage || (item.online ? 'متصل الآن' : 'غير متصل');
    const outgoing = item.lastSender === 'me';
    return (
      <TouchableOpacity style={s.row} onPress={() => onOpenChat?.(item)} activeOpacity={0.7}>
        <Avatar name={name} size={52} isOnline={!!item.online} />
        <View style={s.rowBody}>
          <View style={s.rowTopLine}>
            <Text style={s.rowTitle} numberOfLines={1}>{name}</Text>
            <Text style={[s.rowTime, (isActive && unreadCount > 0) && { color: W.badge }]}>
              {waListTime(item.lastTime)}
            </Text>
          </View>
          <View style={s.rowBottomLine}>
            {outgoing ? <RowTicks status={item.lastStatus} /> : null}
            <Text
              style={[s.rowSub, item.online && !item.lastMessage ? { color: W.online } : null]}
              numberOfLines={1}
            >
              {isActive ? 'متصل الآن · افتح المحادثة' : preview}
            </Text>
            {isActive && unreadCount > 0 ? (
              <View style={s.badge}><Text style={s.badgeText}>{unreadCount}</Text></View>
            ) : null}
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  /* ---------- صف قريب (واتساب) ---------- */
  const renderNearby = ({ item }) => {
    const viaLabel = item.via === 'ble' ? 'عبر Bluetooth' : item.via === 'p2p' ? 'عبر Wi-Fi Direct' : 'قريب منك';
    return (
      <View style={s.row}>
        <Avatar name={item.deviceName || 'M'} size={52} isOnline />
        <View style={s.rowBody}>
          <View style={s.rowTopLine}>
            <Text style={s.rowTitle} numberOfLines={1}>{item.deviceName || 'جهاز MusabX'}</Text>
          </View>
          <View style={s.rowBottomLine}>
            <Text style={s.rowSub} numberOfLines={1}>
              {item.musabNumber ? `${item.musabNumber} · ` : ''}{viaLabel}
            </Text>
            <TouchableOpacity style={s.addBtn} onPress={() => onAddNearby?.(item)} activeOpacity={0.8}>
              <Text style={s.addBtnText}>إضافة</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>
    );
  };

  /* ---------- صف مكالمة (واتساب) ---------- */
  const renderCall = ({ item }) => {
    const incoming = item.direction === 'incoming';
    const missed = item.finalState === 'missed';
    const isVideo = item.mediaType === 'video';
    const arrow = incoming ? '↙' : '↗';
    const arrowColor = missed ? W.danger : W.badge;
    const contact = item.contact || { peerId: item.peerId, name: item.peerName };
    return (
      <TouchableOpacity style={s.row} onPress={() => onOpenChat?.(contact)} activeOpacity={0.7}>
        <Avatar name={item.peerName || 'M'} size={52} />
        <View style={s.rowBody}>
          <View style={s.rowTopLine}>
            <Text style={[s.rowTitle, missed && { color: W.danger }]} numberOfLines={1}>{item.peerName || 'جهة اتصال'}</Text>
            <Text style={s.rowTime}>{waListTime(item.startedAt || item.endedAt)}</Text>
          </View>
          <View style={s.rowBottomLine}>
            <Text style={[s.callArrow, { color: arrowColor }]}>{arrow}</Text>
            <Text style={[s.rowSub, missed && { color: W.danger }]} numberOfLines={1}>
              {incoming ? 'واردة' : 'صادرة'}{item.duration > 0 ? ` · ${Math.max(1, Math.round(item.duration / 60))} د` : ''}
            </Text>
            <Text style={s.callTypeIcon}>{isVideo ? '📹' : '📞'}</Text>
          </View>
        </View>
      </TouchableOpacity>
    );
  };

  const emptyHint = tab === 'chats'
    ? 'لا محادثات بعد.\nاضغط الزر الأخضر لإضافة جهة قريبة.'
    : tab === 'nearby'
      ? 'لا أحد قريب الآن.\nافتح MusabX على الجهاز الآخر وسيظهر هنا.'
      : 'لا مكالمات بعد.';

  /* ---------- ورقة الإضافة (FAB) ---------- */
  const renderAddSheet = () => (
    <Modal visible={addVisible} transparent animationType="slide" onRequestClose={() => setAddVisible(false)}>
      <TouchableOpacity style={s.sheetBack} activeOpacity={1} onPress={() => { setAddVisible(false); setAddMode('menu'); }}>
        <TouchableOpacity activeOpacity={1} style={s.sheet} onPress={() => {}}>
          <View style={s.sheetHandle} />
          {addMode === 'menu' && (
            <>
              <Text style={s.sheetTitle}>محادثة جديدة</Text>
              {onScanQr ? (
                <TouchableOpacity style={s.sheetRow} onPress={() => { setAddVisible(false); onScanQr(); }}>
                  <Text style={s.sheetRowIcon}>📷</Text>
                  <View style={s.sheetRowBody}>
                    <Text style={s.sheetRowTitle}>مسح رمز QR</Text>
                    <Text style={s.sheetRowSub}>وجّه الكاميرا نحو رمز صديقك</Text>
                  </View>
                </TouchableOpacity>
              ) : null}
              <TouchableOpacity style={s.sheetRow} onPress={() => setAddMode('number')}>
                <Text style={s.sheetRowIcon}>🔢</Text>
                <View style={s.sheetRowBody}>
                  <Text style={s.sheetRowTitle}>إضافة برقم MusabX</Text>
                  <Text style={s.sheetRowSub}>أدخل الرقم أو الصق رابط المشاركة</Text>
                </View>
              </TouchableOpacity>
              <TouchableOpacity style={s.sheetRow} onPress={() => setAddMode('myqr')}>
                <Text style={s.sheetRowIcon}>🔗</Text>
                <View style={s.sheetRowBody}>
                  <Text style={s.sheetRowTitle}>رمزي ورقمي</Text>
                  <Text style={s.sheetRowSub}>اعرضها ليضيفك صديقك فوراً</Text>
                </View>
              </TouchableOpacity>
            </>
          )}

          {addMode === 'number' && (
            <>
              <Text style={s.sheetTitle}>إضافة برقم MusabX</Text>
              <TextInput
                style={s.codeInput}
                placeholder="000 000 000 000 أو رابط musabx://"
                placeholderTextColor={W.textMuted}
                value={code}
                onChangeText={setCode}
                keyboardType="default"
                autoFocus
                textAlign="center"
              />
              <TouchableOpacity
                style={[s.primaryBtn, !code.trim() && { opacity: 0.5 }]}
                disabled={!code.trim()}
                onPress={() => {
                  onAddByCode?.(code);
                  setCode('');
                  setAddVisible(false);
                  setAddMode('menu');
                }}
              >
                <Text style={s.primaryBtnText}>بحث وإضافة</Text>
              </TouchableOpacity>
              <TouchableOpacity style={s.sheetBackBtn} onPress={() => setAddMode('menu')}>
                <Text style={s.sheetBackBtnText}>رجوع</Text>
              </TouchableOpacity>
            </>
          )}

          {addMode === 'myqr' && (
            <>
              <Text style={s.sheetTitle}>رمزي ورقمي</Text>
              <View style={{ alignItems: 'center', marginVertical: 14 }}>
                <QRView value={myLink} />
              </View>
              {!!myMusabNumber && <Text style={s.bigNumber}>{myMusabNumber}</Text>}
              <Text style={s.sheetRowSubCenter}>يمسحه صديقك بكاميرا MusabX ليضيفك فوراً</Text>
              <View style={{ flexDirection: 'row', gap: 10, marginTop: 14 }}>
                <TouchableOpacity
                  style={[s.primaryBtn, { flex: 1 }]}
                  onPress={() => Share.share({ message: `أضفني على MusabX: ${myLink}` })}
                >
                  <Text style={s.primaryBtnText}>مشاركة الرابط</Text>
                </TouchableOpacity>
                <TouchableOpacity style={[s.sheetBackBtn, { flex: 1, marginTop: 0 }]} onPress={() => setAddMode('menu')}>
                  <Text style={s.sheetBackBtnText}>رجوع</Text>
                </TouchableOpacity>
              </View>
            </>
          )}
        </TouchableOpacity>
      </TouchableOpacity>
    </Modal>
  );

  /* ---------- قائمة ⋮ ---------- */
  const renderOverflowMenu = () => (
    <Modal visible={menuOpen} transparent animationType="fade" onRequestClose={() => setMenuOpen(false)}>
      <TouchableOpacity style={s.menuBack} activeOpacity={1} onPress={() => setMenuOpen(false)}>
        <View style={s.menuCard}>
          <TouchableOpacity style={s.menuItem} onPress={() => { setMenuOpen(false); setAddMode('myqr'); setAddVisible(true); }}>
            <Text style={s.menuItemText}>رمزي ورقمي</Text>
          </TouchableOpacity>
          <TouchableOpacity style={s.menuItem} onPress={() => { setMenuOpen(false); onOpenMore?.(); }}>
            <Text style={s.menuItemText}>الأجهزة والإعدادات المتقدمة</Text>
          </TouchableOpacity>
        </View>
      </TouchableOpacity>
    </Modal>
  );

  const listData = tab === 'chats' ? chatList : tab === 'nearby' ? nearbyFiltered : callsFiltered;
  const renderRow = tab === 'chats' ? renderChat : tab === 'nearby' ? renderNearby : renderCall;
  const keyOf = item => String(item.peerId || item.deviceAddress || item.callId || item.id || Math.random());

  return (
    <SafeAreaView style={s.root}>
      <StatusBar barStyle="light-content" backgroundColor={W.header} />

      {/* ===== الشريط العلوي ===== */}
      <View style={s.header}>
        {searchOpen ? (
          <View style={s.searchBar}>
            <TouchableOpacity onPress={() => { setSearchOpen(false); setQuery(''); }}>
              <Text style={s.headerIcon}>→</Text>
            </TouchableOpacity>
            <TextInput
              style={s.searchInput}
              placeholder="ابحث…"
              placeholderTextColor={W.textMuted}
              value={query}
              onChangeText={setQuery}
              autoFocus
            />
          </View>
        ) : (
          <>
            <Text style={s.headerTitle}>MusabX</Text>
            <View style={s.headerActions}>
              {onScanQr ? (
                <TouchableOpacity onPress={onScanQr} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
                  <Text style={s.headerIcon}>📷</Text>
                </TouchableOpacity>
              ) : null}
              <TouchableOpacity onPress={() => setSearchOpen(true)} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
                <Text style={s.headerIcon}>🔍</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => setMenuOpen(true)} hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}>
                <Text style={s.headerIcon}>⋮</Text>
              </TouchableOpacity>
            </View>
          </>
        )}
      </View>

      {/* ===== القائمة ===== */}
      <FlatList
        data={listData}
        keyExtractor={keyOf}
        renderItem={renderRow}
        contentContainerStyle={listData.length === 0 ? { flex: 1 } : null}
        ListEmptyComponent={
          <View style={s.emptyWrap}>
            <Text style={s.emptyIcon}>{tab === 'chats' ? '💬' : tab === 'nearby' ? '📡' : '📞'}</Text>
            <Text style={s.emptyText}>{emptyHint}</Text>
          </View>
        }
      />

      {/* ===== الزر العائم ===== */}
      {tab !== 'calls' && (
        <TouchableOpacity style={s.fab} onPress={() => { setAddMode('menu'); setAddVisible(true); }} activeOpacity={0.85}>
          <Text style={s.fabIcon}>{tab === 'chats' ? '💬' : '＋'}</Text>
        </TouchableOpacity>
      )}

      {/* ===== التنقل السفلي ===== */}
      <View style={s.bottomNav}>
        {TABS.map(t => {
          const active = tab === t.key;
          return (
            <TouchableOpacity key={t.key} style={s.navItem} onPress={() => setTab(t.key)} activeOpacity={0.7}>
              <View style={[s.navPill, active && s.navPillActive]}>
                <Text style={[s.navIcon, active && { opacity: 1 }]}>{t.icon}</Text>
              </View>
              <Text style={[s.navLabel, active && { color: W.text }]}>{t.label}</Text>
            </TouchableOpacity>
          );
        })}
      </View>

      {renderAddSheet()}
      {renderOverflowMenu()}
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: W.bg },

  /* ===== الشريط العلوي ===== */
  header: {
    flexDirection: 'row-reverse', alignItems: 'center',
    backgroundColor: W.header, paddingHorizontal: 12, paddingVertical: 10,
    elevation: 3,
  },
  headerTitle: {
    flex: 1, color: W.text, fontSize: 21, fontWeight: '700', textAlign: 'right',
  },
  headerActions: { flexDirection: 'row-reverse', alignItems: 'center' },
  headerIcon: {
    color: W.textMuted, fontSize: 19, paddingHorizontal: 11, paddingVertical: 6,
  },
  searchBar: {
    flex: 1, flexDirection: 'row-reverse', alignItems: 'center',
    backgroundColor: W.inputPill, borderRadius: 22, height: 42,
    paddingHorizontal: 8, marginVertical: 2,
  },
  searchInput: {
    flex: 1, color: W.text, fontSize: 15, textAlign: 'right',
    paddingHorizontal: 8, paddingVertical: 0,
  },

  /* ===== صفوف القوائم ===== */
  row: {
    flexDirection: 'row-reverse', alignItems: 'center',
    paddingHorizontal: 14, paddingVertical: 10,
  },
  rowBody: {
    flex: 1, marginRight: 12, borderBottomWidth: StyleSheet.hairlineWidth,
    borderBottomColor: W.divider, paddingBottom: 10,
  },
  rowTopLine: { flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'space-between' },
  rowBottomLine: { flexDirection: 'row-reverse', alignItems: 'center', marginTop: 3 },
  rowTitle: { color: W.text, fontSize: 16, fontWeight: '600', flex: 1, textAlign: 'right' },
  rowTime: { color: W.textMuted, fontSize: 12, marginRight: 8 },
  rowSub: {
    color: W.textMuted, fontSize: 13.5, flex: 1, textAlign: 'right',
  },
  tick: { fontSize: 13, marginLeft: 4 },
  badge: {
    minWidth: 21, height: 21, borderRadius: 10.5, backgroundColor: W.badge,
    justifyContent: 'center', alignItems: 'center', paddingHorizontal: 6, marginRight: 6,
  },
  badgeText: { color: W.badgeText, fontSize: 12, fontWeight: '800' },
  addBtn: {
    backgroundColor: W.accent, borderRadius: 18, paddingHorizontal: 14,
    paddingVertical: 7, marginRight: 8,
  },
  addBtnText: { color: '#fff', fontSize: 13, fontWeight: '700' },
  callArrow: { fontSize: 14, fontWeight: '700', marginLeft: 4 },
  callTypeIcon: { color: W.textMuted, fontSize: 15, marginRight: 8 },

  /* ===== زر عائم + تنقل سفلي ===== */
  fab: {
    position: 'absolute', left: 18, bottom: 84, width: 56, height: 56,
    borderRadius: 16, backgroundColor: W.fab, justifyContent: 'center',
    alignItems: 'center', elevation: 6,
    shadowColor: '#000', shadowOpacity: 0.3, shadowRadius: 8,
    shadowOffset: { width: 0, height: 3 },
  },
  fabIcon: { color: W.badgeText, fontSize: 24, fontWeight: '700' },
  bottomNav: {
    flexDirection: 'row-reverse', backgroundColor: W.header,
    borderTopWidth: StyleSheet.hairlineWidth, borderTopColor: W.divider,
    paddingTop: 6, paddingBottom: 10, paddingHorizontal: 6,
  },
  navItem: { flex: 1, alignItems: 'center' },
  navPill: {
    width: 64, height: 30, borderRadius: 15, justifyContent: 'center',
    alignItems: 'center',
  },
  navPillActive: { backgroundColor: 'rgba(0,168,132,0.22)' },
  navIcon: { fontSize: 17, opacity: 0.55 },
  navLabel: { color: W.textMuted, fontSize: 11.5, marginTop: 2, fontWeight: '600' },

  /* ===== حالات فارغة ===== */
  emptyWrap: { alignItems: 'center', marginTop: 90, paddingHorizontal: 40 },
  emptyIcon: { fontSize: 46, marginBottom: 14 },
  emptyText: {
    color: W.textMuted, fontSize: 14, textAlign: 'center', lineHeight: 22,
  },

  /* ===== الورقة السفلية (إضافة) ===== */
  sheetBack: {
    flex: 1, backgroundColor: 'rgba(0,0,0,0.5)', justifyContent: 'flex-end',
  },
  sheet: {
    backgroundColor: W.surface, borderTopLeftRadius: 18,
    borderTopRightRadius: 18, paddingBottom: 30, paddingTop: 10,
  },
  sheetHandle: {
    width: 40, height: 4, borderRadius: 2, backgroundColor: W.divider,
    alignSelf: 'center', marginBottom: 14,
  },
  sheetTitle: {
    color: W.text, fontSize: 16, fontWeight: '700', textAlign: 'center',
    marginBottom: 6, paddingHorizontal: 20,
  },
  sheetRow: {
    flexDirection: 'row-reverse', alignItems: 'center',
    paddingHorizontal: 20, paddingVertical: 14,
  },
  sheetRowIcon: {
    width: 44, height: 44, borderRadius: 22, backgroundColor: 'rgba(0,168,132,0.15)',
    justifyContent: 'center', alignItems: 'center',
  },
  sheetRowBody: { flex: 1, marginRight: 14 },
  sheetRowTitle: { color: W.text, fontSize: 15.5, fontWeight: '600', textAlign: 'right' },
  sheetRowSub: { color: W.textMuted, fontSize: 12.5, marginTop: 2, textAlign: 'right' },
  sheetRowSubCenter: {
    color: W.textMuted, fontSize: 13, textAlign: 'center', paddingHorizontal: 24,
    marginBottom: 10,
  },
  codeInput: {
    backgroundColor: W.inputPill, borderRadius: 12, marginHorizontal: 20,
    marginTop: 10, paddingHorizontal: 16, paddingVertical: 12, color: W.text,
    fontSize: 17, textAlign: 'center', letterSpacing: 2,
  },
  primaryBtn: {
    backgroundColor: W.accent, borderRadius: 24, marginHorizontal: 20,
    marginTop: 16, paddingVertical: 13, alignItems: 'center',
  },
  primaryBtnText: { color: '#fff', fontSize: 15, fontWeight: '700' },
  sheetBackBtn: { alignItems: 'center', paddingVertical: 14, marginTop: 4 },
  sheetBackBtnText: { color: W.textMuted, fontSize: 14, fontWeight: '600' },
  bigNumber: {
    color: W.text, fontSize: 30, fontWeight: '800', textAlign: 'center',
    letterSpacing: 3, marginTop: 16,
  },

  /* ===== قائمة النقاط الثلاث ===== */
  menuBack: {
    flex: 1, backgroundColor: 'rgba(0,0,0,0.25)',
  },
  menuCard: {
    position: 'absolute', top: 50, left: 10, width: 240,
    backgroundColor: W.surface, borderRadius: 12, elevation: 10,
    overflow: 'hidden', paddingVertical: 4,
  },
  menuItem: { paddingHorizontal: 18, paddingVertical: 14 },
  menuItemText: { color: W.text, fontSize: 15, textAlign: 'right' },
});
