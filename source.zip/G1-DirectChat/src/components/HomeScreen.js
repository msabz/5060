/**
 * الشاشة الرئيسية لـ MusabX — بنمط تطبيقات المراسلة المألوفة:
 * محادثاتك، من هو متصل الآن، ومن هو قريب منك وعليه التطبيق (إضافة بضغطة).
 * لا مصطلحات شبكات. الاتصال يحدث بالخلفية تلقائياً.
 */
import React, { useMemo, useState } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity, Modal, TextInput,
  SafeAreaView, StatusBar, ScrollView, Share,
} from 'react-native';
import { useAppTheme } from '../theme/themeContext';
import Avatar from './common/Avatar';
import { encodeQR } from '../utils/qr';
import { NativeModules } from 'react-native';
const QrScanner = (NativeModules && NativeModules.QrScannerModule) || null;

function QRView({ value, size = 200, dark = '#0F1222', light = '#FFFFFF' }) {
  const matrix = useMemo(() => { try { return encodeQR(value); } catch (e) { return null; } }, [value]);
  if (!matrix) return null;
  const n = matrix.length;
  const cell = size / (n + 8);
  return (
    <View style={{ width: size, height: size, backgroundColor: light, padding: cell * 4, borderRadius: 16 }}>
      {matrix.map((row, r) => (
        <View key={r} style={{ flexDirection: 'row', height: cell }}>
          {row.map((on, c) => (
            <View key={c} style={{ width: cell, height: cell, backgroundColor: on ? dark : light }} />
          ))}
        </View>
      ))}
    </View>
  );
}

export default function HomeScreen({
  myName = 'أنا',
  myMusabNumber = null,
  myMusabId = null,
  contacts = [],
  nearby = [],
  activePeer = null,
  unreadCount = 0,
  onOpenChat,
  onAddNearby,
  onAddByCode,
  onOpenMore,
}) {
  const { theme, isDark } = useAppTheme();
  const [addVisible, setAddVisible] = useState(false);
  const [code, setCode] = useState('');
  const [tab, setTab] = useState('mine'); // mine | add

  const sorted = useMemo(() => {
    return [...contacts].sort((a, b) => {
      if (!!a.online !== !!b.online) return a.online ? -1 : 1;
      return (b.lastTime || 0) - (a.lastTime || 0);
    });
  }, [contacts]);

  const myLink = `musabx://add?n=${(myMusabNumber || '').replace(/\s/g, '')}&id=${myMusabId || ''}`;

  const renderContact = ({ item }) => {
    const name = item.customName || item.name || item.deviceName || 'جهة اتصال';
    const isActive = activePeer && (activePeer.peerId === item.peerId);
    const sub = isActive
      ? 'متصل الآن · افتح المحادثة'
      : item.online ? 'متصل' : item.lastMessage ? item.lastMessage : 'غير متصل';
    return (
      <TouchableOpacity style={[styles.row, { borderBottomColor: theme.borderSubtle }]} onPress={() => onOpenChat?.(item)} activeOpacity={0.7}>
        <Avatar name={name} size={52} isOnline={!!item.online} />
        <View style={styles.rowBody}>
          <Text style={[styles.rowTitle, { color: theme.text }]} numberOfLines={1}>{name}</Text>
          <Text style={[styles.rowSub, { color: item.online ? theme.success : theme.textMuted }]} numberOfLines={1}>{sub}</Text>
        </View>
        {isActive && unreadCount > 0 && (
          <View style={[styles.badge, { backgroundColor: theme.accent }]}>
            <Text style={[styles.badgeText, { color: theme.badgeText }]}>{unreadCount}</Text>
          </View>
        )}
      </TouchableOpacity>
    );
  };

  return (
    <SafeAreaView style={[styles.root, { backgroundColor: theme.background }]}>
      <StatusBar barStyle={isDark ? 'light-content' : 'dark-content'} backgroundColor={theme.background} />
      <View style={styles.header}>
        <TouchableOpacity onPress={onOpenMore} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
          <Text style={[styles.more, { color: theme.textSecondary }]}>⋯</Text>
        </TouchableOpacity>
        <View style={{ flex: 1, alignItems: 'flex-end' }}>
          <Text style={[styles.brand, { color: theme.text }]}>MusabX</Text>
          <Text style={[styles.myNumber, { color: myMusabNumber ? theme.textMuted : theme.warning }]}>
            {myMusabNumber ? `رقمك: ${myMusabNumber}` : 'جارٍ تجهيز هويتك…'}
          </Text>
        </View>
      </View>

      <FlatList
        data={sorted}
        keyExtractor={(it, i) => it.peerId || String(i)}
        renderItem={renderContact}
        contentContainerStyle={{ paddingBottom: 120 }}
        ListHeaderComponent={nearby.length > 0 ? (
          <View style={[styles.nearbyCard, { backgroundColor: theme.surface, borderColor: theme.border }]}>
            <Text style={[styles.nearbyTitle, { color: theme.primary }]}>قريب منك الآن</Text>
            {nearby.map(n => (
              <View key={n.peerId} style={[styles.row, { borderBottomColor: theme.borderSubtle }]}>
                <Avatar name={n.deviceName || 'جهاز'} size={44} isOnline />
                <View style={styles.rowBody}>
                  <Text style={[styles.rowTitle, { color: theme.text }]} numberOfLines={1}>{n.deviceName || 'جهاز MusabX'}</Text>
                  <Text style={[styles.rowSub, { color: theme.textMuted }]}>{n.musabNumber || 'عليه MusabX'}</Text>
                </View>
                <TouchableOpacity style={[styles.addBtn, { backgroundColor: theme.primary }]} onPress={() => onAddNearby?.(n)}>
                  <Text style={styles.addBtnText}>إضافة</Text>
                </TouchableOpacity>
              </View>
            ))}
          </View>
        ) : null}
        ListEmptyComponent={nearby.length === 0 ? (
          <View style={styles.empty}>
            <Text style={[styles.emptyTitle, { color: theme.text }]}>لا توجد محادثات بعد</Text>
            <Text style={[styles.emptyText, { color: theme.textMuted }]}>
              افتح MusabX على جهاز صديقك وهو قريب منك — سيظهر هنا تلقائياً. أو أضِفه برقمه.
            </Text>
          </View>
        ) : null}
      />

      <TouchableOpacity style={[styles.fab, { backgroundColor: theme.accent }]} onPress={() => setAddVisible(true)} activeOpacity={0.85}>
        <Text style={[styles.fabText, { color: theme.badgeText }]}>＋</Text>
      </TouchableOpacity>

      <Modal visible={addVisible} animationType="slide" transparent onRequestClose={() => setAddVisible(false)}>
        <View style={[styles.sheetBackdrop, { backgroundColor: theme.overlay }]}>
          <View style={[styles.sheet, { backgroundColor: theme.surface }]}>
            <View style={[styles.segment, { backgroundColor: theme.surfaceVariant }]}>
              {[['mine', 'رقمي'], ['add', 'إضافة جهة']].map(([k, label]) => (
                <TouchableOpacity key={k} style={[styles.segBtn, tab === k && { backgroundColor: theme.surface }]} onPress={() => setTab(k)}>
                  <Text style={{ color: tab === k ? theme.text : theme.textMuted, fontWeight: '600' }}>{label}</Text>
                </TouchableOpacity>
              ))}
            </View>

            {tab === 'mine' ? (
              <ScrollView contentContainerStyle={{ alignItems: 'center', paddingVertical: 12 }}>
                <QRView value={myLink} size={220} />
                <Text style={[styles.bigNumber, { color: theme.text }]}>{myMusabNumber || '—'}</Text>
                <Text style={[styles.hint, { color: theme.textMuted }]}>{myName} · {myMusabId || ''}</Text>
                <TouchableOpacity
                  style={[styles.primaryBtn, { backgroundColor: theme.primary }]}
                  onPress={() => Share.share({ message: `أضفني على MusabX — رقمي: ${myMusabNumber}\n${myLink}` }).catch(() => {})}
                >
                  <Text style={styles.primaryBtnText}>مشاركة رقمي</Text>
                </TouchableOpacity>
              </ScrollView>
            ) : (
              <View style={{ paddingVertical: 12 }}>
                <Text style={[styles.hint, { color: theme.textSecondary, textAlign: 'right' }]}>أدخل رقم MusabX أو معرّفه أو الصق رابط QR</Text>
                <TextInput
                  value={code}
                  onChangeText={setCode}
                  placeholder="000 000 000 000"
                  placeholderTextColor={theme.textMuted}
                  style={[styles.input, { color: theme.text, borderColor: theme.border, backgroundColor: theme.surfaceSubtle }]}
                  keyboardType="default"
                  autoCapitalize="characters"
                />
                <TouchableOpacity
                  style={[styles.primaryBtn, { backgroundColor: theme.primary }]}
                  onPress={async () => { const ok = await onAddByCode?.(code); if (ok) { setCode(''); setAddVisible(false); } }}
                >
                  <Text style={styles.primaryBtnText}>إضافة</Text>
                </TouchableOpacity>
                {!!QrScanner && (
                  <TouchableOpacity
                    style={[styles.primaryBtn, { backgroundColor: theme.accent }]}
                    onPress={async () => {
                      try {
                        const text = await QrScanner.scan('وجّه الكاميرا إلى رمز MusabX لصديقك');
                        if (!text) return;
                        const ok = await onAddByCode?.(text);
                        if (ok) setAddVisible(false);
                      } catch (e) {}
                    }}
                  >
                    <Text style={[styles.primaryBtnText, { color: theme.badgeText }]}>📷 مسح رمز QR</Text>
                  </TouchableOpacity>
                )}
                <Text style={[styles.hint, { color: theme.textMuted, textAlign: 'right' }]}>
                  إذا لم يكن الجهاز قريباً الآن، سيُضاف تلقائياً أول ما يظهر.
                </Text>
              </View>
            )}

            <TouchableOpacity onPress={() => setAddVisible(false)} style={{ alignSelf: 'center', padding: 12 }}>
              <Text style={{ color: theme.textMuted }}>إغلاق</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 20, paddingTop: 14, paddingBottom: 10 },
  brand: { fontSize: 28, fontWeight: '800', letterSpacing: 0.5 },
  myNumber: { fontSize: 13, marginTop: 2 },
  more: { fontSize: 28, fontWeight: '700', paddingHorizontal: 6 },
  row: { flexDirection: 'row-reverse', alignItems: 'center', paddingHorizontal: 18, paddingVertical: 12, borderBottomWidth: StyleSheet.hairlineWidth },
  rowBody: { flex: 1, marginHorizontal: 14, alignItems: 'flex-end' },
  rowTitle: { fontSize: 17, fontWeight: '600' },
  rowSub: { fontSize: 13, marginTop: 3 },
  badge: { minWidth: 24, height: 24, borderRadius: 12, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 7 },
  badgeText: { fontSize: 12, fontWeight: '700' },
  nearbyCard: { margin: 14, borderRadius: 18, borderWidth: 1, paddingTop: 12, overflow: 'hidden' },
  nearbyTitle: { fontSize: 14, fontWeight: '700', textAlign: 'right', paddingHorizontal: 18, marginBottom: 4 },
  addBtn: { paddingHorizontal: 16, paddingVertical: 8, borderRadius: 14 },
  addBtnText: { color: '#fff', fontWeight: '700' },
  empty: { alignItems: 'center', paddingHorizontal: 40, paddingTop: 80 },
  emptyTitle: { fontSize: 20, fontWeight: '700', marginBottom: 8 },
  emptyText: { fontSize: 14, textAlign: 'center', lineHeight: 22 },
  fab: { position: 'absolute', bottom: 28, left: 24, width: 60, height: 60, borderRadius: 30, alignItems: 'center', justifyContent: 'center', elevation: 6, shadowColor: '#000', shadowOpacity: 0.25, shadowRadius: 8, shadowOffset: { width: 0, height: 4 } },
  fabText: { fontSize: 30, fontWeight: '800', marginTop: -2 },
  sheetBackdrop: { flex: 1, justifyContent: 'flex-end' },
  sheet: { borderTopLeftRadius: 26, borderTopRightRadius: 26, padding: 18, minHeight: 420 },
  segment: { flexDirection: 'row-reverse', borderRadius: 14, padding: 4 },
  segBtn: { flex: 1, paddingVertical: 10, alignItems: 'center', borderRadius: 11 },
  bigNumber: { fontSize: 26, fontWeight: '800', marginTop: 16, letterSpacing: 1 },
  hint: { fontSize: 13, marginTop: 8, lineHeight: 20 },
  input: { borderWidth: 1, borderRadius: 14, paddingHorizontal: 16, paddingVertical: 14, fontSize: 18, marginTop: 12, textAlign: 'center', letterSpacing: 1 },
  primaryBtn: { marginTop: 16, paddingVertical: 14, borderRadius: 16, alignItems: 'center' },
  primaryBtnText: { color: '#fff', fontWeight: '700', fontSize: 16 },
});
