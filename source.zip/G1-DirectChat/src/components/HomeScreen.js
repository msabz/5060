/**
 * الشاشة الرئيسية لـ MusabX — تصميم "أورورا": رأس داكن عميق بعلامة متدرجة
 * الإحساس، بطاقة "قريب منك الآن" متوهجة، قائمة محادثات بأفاتار ثنائي اللون،
 * وزر عائم. لا مصطلحات شبكات — الاتصال يحدث بالخلفية تلقائياً.
 */
import React, { useMemo, useState } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity, Modal, TextInput,
  SafeAreaView, StatusBar, ScrollView, Share,
} from 'react-native';
import { useAppTheme } from '../theme/themeContext';
import { radius, shadow, spacing, type } from '../theme/tokens';
import Avatar from './common/Avatar';
import { encodeQR } from '../utils/qr';
import { NativeModules } from 'react-native';
const QrScanner = (NativeModules && NativeModules.QrScannerModule) || null;

function QRView({ value, size = 200, dark = '#0D1020', light = '#FFFFFF' }) {
  const matrix = useMemo(() => { try { return encodeQR(value); } catch (e) { return null; } }, [value]);
  if (!matrix) return null;
  const n = matrix.length;
  const cell = size / (n + 8);
  return (
    <View style={{
      width: size + cell * 8, height: size + cell * 8, backgroundColor: light,
      padding: cell * 4, borderRadius: radius.xl, alignItems: 'center', justifyContent: 'center',
    }}>
      <View style={{ width: size, height: size }}>
        {matrix.map((row, r) => (
          <View key={r} style={{ flexDirection: 'row', height: cell }}>
            {row.map((on, c) => (
              <View key={c} style={{ width: cell, height: cell, backgroundColor: on ? dark : light }} />
            ))}
          </View>
        ))}
      </View>
    </View>
  );
}

export default function HomeScreen({
  myName = 'أنا',
  myMusabNumber = null,
  myMusabId = null,
  contacts = [],
  nearby = [],
  activePeer = null,
  unreadCount = 0,
  onOpenChat,
  onAddNearby,
  onAddByCode,
  onOpenMore,
}) {
  const { theme, isDark } = useAppTheme();
  const [addVisible, setAddVisible] = useState(false);
  const [code, setCode] = useState('');
  const [tab, setTab] = useState('mine'); // mine | add
  const [query, setQuery] = useState('');

  const sorted = useMemo(() => {
    const q = query.trim();
    const list = q
      ? contacts.filter(c => (c.customName || c.name || c.deviceName || '').includes(q))
      : [...contacts];
    return list.sort((a, b) => {
      if (!!a.online !== !!b.online) return a.online ? -1 : 1;
      return (b.lastTime || 0) - (a.lastTime || 0);
    });
  }, [contacts, query]);

  const myLink = `musabx://add?n=${(myMusabNumber || '').replace(/\s/g, '')}&id=${myMusabId || ''}`;

  const renderContact = ({ item }) => {
    const name = item.customName || item.name || item.deviceName || 'جهة اتصال';
    const isActive = activePeer && (activePeer.peerId === item.peerId);
    const sub = isActive
      ? 'متصل الآن · افتح المحادثة'
      : item.online ? 'متصل' : item.lastMessage ? item.lastMessage : 'غير متصل';
    return (
      <TouchableOpacity
        style={[styles.row, { backgroundColor: theme.surface }]}
        onPress={() => onOpenChat?.(item)}
        activeOpacity={0.72}
      >
        <Avatar name={name} size={54} isOnline={!!item.online} />
        <View style={styles.rowBody}>
          <Text style={[styles.rowTitle, { color: theme.text }]} numberOfLines={1}>{name}</Text>
          <Text
            style={[styles.rowSub, { color: item.online ? theme.success : theme.textMuted }]}
            numberOfLines={1}
          >
            {sub}
          </Text>
        </View>
        {isActive && unreadCount > 0 ? (
          <View style={[styles.badge, { backgroundColor: theme.accent }]}>
            <Text style={[styles.badgeText, { color: theme.badgeText }]}>{unreadCount}</Text>
          </View>
        ) : (
          <Text style={[styles.chevron, { color: theme.textMuted }]}>‹</Text>
        )}
      </TouchableOpacity>
    );
  };

  return (
    <SafeAreaView style={[styles.root, { backgroundColor: theme.background }]}>
      <StatusBar barStyle={isDark ? 'light-content' : 'dark-content'} backgroundColor={theme.headerBg} />

      {/* ===== الرأس ===== */}
      <View style={[styles.header, { backgroundColor: theme.headerBg }]}>
        <TouchableOpacity
          onPress={onOpenMore}
          hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
          style={[styles.headerIconBtn, { borderColor: 'rgba(255,255,255,0.16)' }]}
          accessibilityLabel="المزيد"
        >
          <Text style={styles.headerIconText}>⋯</Text>
        </TouchableOpacity>
        <View style={{ flex: 1, alignItems: 'flex-end' }}>
          <View style={{ flexDirection: 'row-reverse', alignItems: 'baseline', gap: 8 }}>
            <Text style={styles.brand}>MusabX</Text>
            <View style={[styles.brandDot, { backgroundColor: theme.accent }]} />
          </View>
          {!!myMusabNumber && (
            <Text style={styles.myNumber}>رقمك · {myMusabNumber}</Text>
          )}
        </View>
      </View>

      {/* ===== بحث ===== */}
      {contacts.length > 0 && (
        <View style={[styles.searchWrap, { backgroundColor: theme.background }]}>
          <TextInput
            value={query}
            onChangeText={setQuery}
            placeholder="ابحث عن محادثة…"
            placeholderTextColor={theme.textMuted}
            style={[styles.search, { color: theme.text, backgroundColor: theme.surface, borderColor: theme.borderSubtle }]}
          />
        </View>
      )}

      <FlatList
        data={sorted}
        keyExtractor={(it, i) => it.peerId || String(i)}
        renderItem={renderContact}
        contentContainerStyle={{ paddingBottom: 140, paddingTop: 4 }}
        ItemSeparatorComponent={() => <View style={[styles.sep, { backgroundColor: theme.borderSubtle }]} />}
        ListHeaderComponent={nearby.length > 0 ? (
          <View style={[styles.nearbyCard, { backgroundColor: theme.surface, borderColor: theme.accent }, shadow(theme.accent, 0.25, 8, 14, 3)]}>
            <View style={styles.nearbyHead}>
              <View style={[styles.pulseDot, { backgroundColor: theme.accent }]} />
              <Text style={[styles.nearbyTitle, { color: theme.accent }]}>قريب منك الآن</Text>
            </View>
            {nearby.map(n => (
              <View key={n.peerId} style={styles.nearbyRow}>
                <Avatar name={n.deviceName || 'جهاز'} size={46} isOnline />
                <View style={styles.rowBody}>
                  <Text style={[styles.rowTitle, { color: theme.text }]} numberOfLines={1}>{n.deviceName || 'جهاز MusabX'}</Text>
                  <Text style={[styles.rowSub, { color: theme.textMuted }]}>{n.musabNumber || 'عليه MusabX'}</Text>
                </View>
                <TouchableOpacity
                  style={[styles.addBtn, { backgroundColor: theme.accentSoft, borderColor: theme.accent }]}
                  onPress={() => onAddNearby?.(n)}
                >
                  <Text style={[styles.addBtnText, { color: theme.accent }]}>إضافة</Text>
                </TouchableOpacity>
              </View>
            ))}
          </View>
        ) : null}
        ListEmptyComponent={nearby.length === 0 ? (
          <View style={styles.empty}>
            <View style={[styles.emptyOrb, { backgroundColor: theme.surfaceVariant }]}>
              <Text style={{ fontSize: 34 }}>🛰</Text>
            </View>
            <Text style={[styles.emptyTitle, { color: theme.text }]}>لا توجد محادثات بعد</Text>
            <Text style={[styles.emptyText, { color: theme.textMuted }]}>
              افتح MusabX على جهاز صديقك وهو قريب منك — سيظهر هنا تلقائياً. أو أضِفه برقمه.
            </Text>
          </View>
        ) : null}
      />

      {/* ===== زر الإضافة العائم ===== */}
      <TouchableOpacity
        style={[styles.fab, { backgroundColor: theme.accent }, shadow(theme.accent, 0.4, 10, 16, 6)]}
        onPress={() => setAddVisible(true)}
        activeOpacity={0.85}
        accessibilityLabel="إضافة جهة اتصال"
      >
        <Text style={[styles.fabText, { color: theme.badgeText }]}>＋</Text>
      </TouchableOpacity>

      {/* ===== ورقة الإضافة ===== */}
      <Modal visible={addVisible} animationType="slide" transparent onRequestClose={() => setAddVisible(false)}>
        <View style={[styles.sheetBackdrop, { backgroundColor: theme.overlay }]}>
          <View style={[styles.sheet, { backgroundColor: theme.surface }]}>
            <View style={[styles.sheetGrip, { backgroundColor: theme.border }]} />
            <View style={[styles.segment, { backgroundColor: theme.surfaceVariant }]}>
              {[['mine', 'رقمي'], ['add', 'إضافة جهة']].map(([k, label]) => (
                <TouchableOpacity
                  key={k}
                  style={[styles.segBtn, tab === k && { backgroundColor: theme.surface }, tab === k && shadow('#000', 0.12, 3, 6, 2)]}
                  onPress={() => setTab(k)}
                >
                  <Text style={{ color: tab === k ? theme.text : theme.textMuted, fontWeight: '700' }}>{label}</Text>
                </TouchableOpacity>
              ))}
            </View>

            {tab === 'mine' ? (
              <ScrollView contentContainerStyle={{ alignItems: 'center', paddingVertical: 14 }}>
                <View style={shadow('#000', 0.14, 6, 14, 4)}>
                  <QRView value={myLink} size={210} />
                </View>
                <Text style={[styles.bigNumber, { color: theme.text }]}>{myMusabNumber || '—'}</Text>
                <Text style={[styles.hint, { color: theme.textMuted }]}>{myName} · {myMusabId || ''}</Text>
                <TouchableOpacity
                  style={[styles.primaryBtn, { backgroundColor: theme.primary }, shadow(theme.primary, 0.3, 5, 10, 3)]}
                  onPress={() => Share.share({ message: `أضفني على MusabX — رقمي: ${myMusabNumber}\n${myLink}` }).catch(() => {})}
                >
                  <Text style={styles.primaryBtnText}>مشاركة رقمي</Text>
                </TouchableOpacity>
              </ScrollView>
            ) : (
              <View style={{ paddingVertical: 12 }}>
                <Text style={[styles.hint, { color: theme.textSecondary, textAlign: 'right' }]}>أدخل رقم MusabX أو معرّفه أو الصق رابط QR</Text>
                <TextInput
                  value={code}
                  onChangeText={setCode}
                  placeholder="000 000 000 000"
                  placeholderTextColor={theme.textMuted}
                  style={[styles.input, { color: theme.text, borderColor: theme.border, backgroundColor: theme.surfaceSubtle }]}
                  keyboardType="default"
                  autoCapitalize="characters"
                />
                <TouchableOpacity
                  style={[styles.primaryBtn, { backgroundColor: theme.primary }, shadow(theme.primary, 0.3, 5, 10, 3)]}
                  onPress={async () => { const ok = await onAddByCode?.(code); if (ok) { setCode(''); setAddVisible(false); } }}
                >
                  <Text style={styles.primaryBtnText}>إضافة</Text>
                </TouchableOpacity>
                {!!QrScanner && (
                  <TouchableOpacity
                    style={[styles.primaryBtn, { backgroundColor: theme.accent }]}
                    onPress={async () => {
                      try {
                        const text = await QrScanner.scan('وجّه الكاميرا إلى رمز MusabX لصديقك');
                        if (!text) return;
                        const ok = await onAddByCode?.(text);
                        if (ok) setAddVisible(false);
                      } catch (e) {}
                    }}
                  >
                    <Text style={[styles.primaryBtnText, { color: theme.badgeText }]}>📷 مسح رمز QR</Text>
                  </TouchableOpacity>
                )}
                <Text style={[styles.hint, { color: theme.textMuted, textAlign: 'right' }]}>
                  إذا لم يكن الجهاز قريباً الآن، سيُضاف تلقائياً أول ما يظهر.
                </Text>
              </View>
            )}

            <TouchableOpacity onPress={() => setAddVisible(false)} style={{ alignSelf: 'center', padding: 12 }}>
              <Text style={{ color: theme.textMuted, fontWeight: '600' }}>إغلاق</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },

  header: {
    flexDirection: 'row', alignItems: 'center',
    paddingHorizontal: spacing.xl, paddingTop: spacing.lg, paddingBottom: spacing.lg,
    borderBottomLeftRadius: radius.xxl, borderBottomRightRadius: radius.xxl,
  },
  headerIconBtn: {
    width: 40, height: 40, borderRadius: 20, borderWidth: 1,
    alignItems: 'center', justifyContent: 'center',
  },
  headerIconText: { color: '#FFFFFF', fontSize: 22, fontWeight: '700', marginTop: -4 },
  brand: { fontSize: 30, fontWeight: '800', letterSpacing: 0.4, color: '#FFFFFF' },
  brandDot: { width: 9, height: 9, borderRadius: 5, marginBottom: 6 },
  myNumber: { fontSize: 12.5, marginTop: 3, color: 'rgba(255,255,255,0.6)', fontWeight: '500' },

  searchWrap: { paddingHorizontal: spacing.lg, paddingTop: spacing.md },
  search: {
    borderRadius: radius.pill, borderWidth: 1,
    paddingHorizontal: spacing.lg, paddingVertical: 11,
    fontSize: 14.5, textAlign: 'right',
  },

  row: {
    flexDirection: 'row-reverse', alignItems: 'center',
    paddingHorizontal: spacing.lg, paddingVertical: 13,
  },
  rowBody: { flex: 1, marginHorizontal: 14, alignItems: 'flex-end' },
  rowTitle: { ...type.subtitle, fontSize: 16.5 },
  rowSub: { ...type.caption, marginTop: 3 },
  sep: { height: StyleSheet.hairlineWidth, marginHorizontal: spacing.lg },
  chevron: { fontSize: 26, fontWeight: '300' },
  badge: { minWidth: 24, height: 24, borderRadius: 12, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 7 },
  badgeText: { fontSize: 12, fontWeight: '800' },

  nearbyCard: {
    margin: spacing.lg, marginBottom: spacing.sm,
    borderRadius: radius.xl, borderWidth: 1.2,
    paddingTop: spacing.md, paddingBottom: spacing.xs, overflow: 'hidden',
  },
  nearbyHead: { flexDirection: 'row-reverse', alignItems: 'center', gap: 8, paddingHorizontal: spacing.lg, marginBottom: 6 },
  pulseDot: { width: 9, height: 9, borderRadius: 5 },
  nearbyTitle: { fontSize: 14, fontWeight: '800', letterSpacing: 0.3 },
  nearbyRow: { flexDirection: 'row-reverse', alignItems: 'center', paddingHorizontal: spacing.lg, paddingVertical: 9 },
  addBtn: { paddingHorizontal: 16, paddingVertical: 8, borderRadius: radius.pill, borderWidth: 1 },
  addBtnText: { fontWeight: '800', fontSize: 13 },

  empty: { alignItems: 'center', paddingHorizontal: 40, paddingTop: 72 },
  emptyOrb: { width: 88, height: 88, borderRadius: 44, alignItems: 'center', justifyContent: 'center', marginBottom: 18 },
  emptyTitle: { ...type.title, marginBottom: 8 },
  emptyText: { fontSize: 14, textAlign: 'center', lineHeight: 22 },

  fab: {
    position: 'absolute', bottom: 30, left: 24, width: 62, height: 62,
    borderRadius: 22, alignItems: 'center', justifyContent: 'center',
  },
  fabText: { fontSize: 30, fontWeight: '800', marginTop: -2 },

  sheetBackdrop: { flex: 1, justifyContent: 'flex-end' },
  sheet: { borderTopLeftRadius: radius.xxl, borderTopRightRadius: radius.xxl, padding: spacing.lg, minHeight: 430 },
  sheetGrip: { width: 42, height: 4.5, borderRadius: 3, alignSelf: 'center', marginBottom: 14 },
  segment: { flexDirection: 'row-reverse', borderRadius: radius.md, padding: 4 },
  segBtn: { flex: 1, paddingVertical: 10, alignItems: 'center', borderRadius: radius.sm },
  bigNumber: { fontSize: 27, fontWeight: '800', marginTop: 16, letterSpacing: 1.2 },
  hint: { fontSize: 13, marginTop: 8, lineHeight: 20 },
  input: {
    borderWidth: 1, borderRadius: radius.md, paddingHorizontal: 16, paddingVertical: 14,
    fontSize: 18, marginTop: 12, textAlign: 'center', letterSpacing: 1,
  },
  primaryBtn: { marginTop: 16, paddingVertical: 15, borderRadius: radius.md, alignItems: 'center' },
  primaryBtnText: { color: '#fff', fontWeight: '800', fontSize: 15.5, letterSpacing: 0.2 },
});
