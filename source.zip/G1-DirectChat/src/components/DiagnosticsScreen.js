/**
 * شاشة سجل التشخيص — تعرض كل أحداث النواقل والأخطاء لحظياً، مع نسخ/مشاركة.
 * تُفتح من قائمة ⋮ في الشاشة الرئيسية. الهدف: تحويل أي فشل ميداني إلى
 * سطور دقيقة قابلة للإرسال بدل «مش شغال».
 */
import React, { useEffect, useRef, useState } from 'react';
import {
  View, Text, StyleSheet, FlatList, TouchableOpacity, SafeAreaView, Share,
} from 'react-native';
import { diagEntries, diagSubscribe, diagClear, diagExport } from '../utils/diagLog';
import { W } from '../theme/whatsapp';

const TAG_COLORS = {
  BT: '#53BDEB',
  P2P: '#00A884',
  LAN: '#7F66FF',
  COORD: '#F0B330',
  LINK: '#25D366',
  APP: '#8696A0',
  UI: '#8696A0',
  ERR: '#F15C6D',
};

function rowTime(at) {
  const d = new Date(at);
  return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}:${String(d.getSeconds()).padStart(2, '0')}`;
}

export default function DiagnosticsScreen({ onClose }) {
  const [entries, setEntries] = useState(diagEntries());
  const listRef = useRef(null);

  useEffect(() => {
    const off = diagSubscribe(() => setEntries(diagEntries()));
    return off;
  }, []);

  const shareLog = () => {
    const text = diagExport() || 'السجل فارغ';
    Share.share({ message: `سجل تشخيص MusabX\n${text}` }).catch(() => {});
  };

  return (
    <SafeAreaView style={s.root}>
      <View style={s.header}>
        <TouchableOpacity onPress={onClose} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
          <Text style={s.headerIcon}>→</Text>
        </TouchableOpacity>
        <Text style={s.title}>سجل التشخيص</Text>
        <TouchableOpacity onPress={() => { diagClear(); }} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
          <Text style={s.headerAction}>مسح</Text>
        </TouchableOpacity>
        <TouchableOpacity onPress={shareLog} hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}>
          <Text style={[s.headerAction, { color: W.accent }]}>مشاركة</Text>
        </TouchableOpacity>
      </View>
      <Text style={s.hint}>
        أعد إنتاج المشكلة (حاول الاتصال)، ثم اضغط «مشاركة» وأرسل السجل.
      </Text>
      <FlatList
        ref={listRef}
        data={[...entries].reverse()}
        keyExtractor={(e, i) => `${e.at}-${i}`}
        contentContainerStyle={{ paddingVertical: 8 }}
        ListEmptyComponent={
          <Text style={s.empty}>لا أحداث بعد. جرّب الاتصال بجهاز وسيظهر كل شيء هنا.</Text>
        }
        renderItem={({ item }) => (
          <View style={s.row}>
            <Text style={[s.tag, { color: TAG_COLORS[item.tag] || W.textMuted }]}>{item.tag}</Text>
            <View style={s.rowBody}>
              <Text style={s.msg}>
                <Text style={s.time}>{rowTime(item.at)} </Text>
                {item.message}
              </Text>
              {item.data ? <Text style={s.data}>{item.data}</Text> : null}
            </View>
          </View>
        )}
      />
    </SafeAreaView>
  );
}

const s = StyleSheet.create({
  root: { flex: 1, backgroundColor: W.bg },
  header: {
    flexDirection: 'row-reverse', alignItems: 'center',
    backgroundColor: W.header, paddingHorizontal: 12, paddingVertical: 10,
  },
  headerIcon: { color: W.text, fontSize: 20, paddingHorizontal: 8 },
  title: { flex: 1, color: W.text, fontSize: 17, fontWeight: '700', textAlign: 'right' },
  headerAction: { color: W.textMuted, fontSize: 14, fontWeight: '700', paddingHorizontal: 10 },
  hint: {
    color: W.textMuted, fontSize: 12.5, textAlign: 'center',
    paddingHorizontal: 18, paddingVertical: 8, lineHeight: 18,
  },
  empty: { color: W.textMuted, fontSize: 13.5, textAlign: 'center', marginTop: 60, paddingHorizontal: 30, lineHeight: 20 },
  row: {
    flexDirection: 'row-reverse', paddingHorizontal: 12, paddingVertical: 5,
    borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: W.divider,
  },
  tag: { width: 46, fontSize: 11, fontWeight: '800', textAlign: 'left', marginTop: 1 },
  rowBody: { flex: 1 },
  msg: { color: W.text, fontSize: 12.5, textAlign: 'left', lineHeight: 18 },
  time: { color: W.textMuted, fontSize: 11 },
  data: { color: W.textMuted, fontSize: 11, textAlign: 'left', lineHeight: 15, marginTop: 1 },
});
