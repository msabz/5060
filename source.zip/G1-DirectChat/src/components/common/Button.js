import React from 'react';
import { TouchableOpacity, Text, StyleSheet, ActivityIndicator } from 'react-native';
import { useAppTheme } from '../../theme/themeContext';
import { radius, shadow } from '../../theme/tokens';

export const Button = ({
  title,
  onPress,
  variant = 'primary',
  size = 'medium',
  loading = false,
  disabled = false,
  icon,
  style,
  textStyle,
}) => {
  const { theme } = useAppTheme();

  const getBgColor = () => {
    if (disabled) return theme.surfaceVariant;
    switch (variant) {
      case 'primary': return theme.primary;
      case 'accent': return theme.accent;
      case 'secondary': return theme.surfaceVariant;
      case 'danger': return theme.error;
      case 'ghost': return 'transparent';
      default: return theme.primary;
    }
  };

  const getTextColor = () => {
    if (disabled) return theme.textMuted;
    switch (variant) {
      case 'primary':
      case 'danger': return '#FFFFFF';
      case 'accent': return theme.badgeText || '#04231F';
      case 'secondary':
      case 'ghost': return theme.text;
      default: return '#FFFFFF';
    }
  };

  const getPadding = () => {
    switch (size) {
      case 'small': return { paddingVertical: 8, paddingHorizontal: 14 };
      case 'large': return { paddingVertical: 16, paddingHorizontal: 26 };
      default: return { paddingVertical: 12, paddingHorizontal: 20 };
    }
  };

  const elevated = !disabled && (variant === 'primary' || variant === 'accent' || variant === 'danger');

  return (
    <TouchableOpacity
      activeOpacity={0.82}
      onPress={onPress}
      disabled={disabled || loading}
      style={[
        styles.button,
        { backgroundColor: getBgColor() },
        elevated && shadow(theme.primary, 0.3, 4, 10, 3),
        getPadding(),
        style,
      ]}
    >
      {loading ? (
        <ActivityIndicator size="small" color={getTextColor()} />
      ) : (
        <Text style={[styles.text, { color: getTextColor() }, textStyle]}>
          {icon ? `${icon} ` : ''}
          {title}
        </Text>
      )}
    </TouchableOpacity>
  );
};

const styles = StyleSheet.create({
  button: {
    borderRadius: radius.md,
    justifyContent: 'center',
    alignItems: 'center',
    flexDirection: 'row',
  },
  text: { fontWeight: '700', fontSize: 14.5, letterSpacing: 0.2 },
});
export default Button;
