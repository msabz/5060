import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { useAppTheme } from '../../theme/themeContext';

/**
 * شارة الناقل الحالي — تُظهر قناة الاتصال الفعلية وتومض بلون مختلف
 * أثناء الهجرة بلا انقطاع (migrating=true).
 */
const TRANSPORT_META = {
  LAN: { label: 'شبكة محلية', icon: '🌐', colorKey: 'info' },
  WIFI_DIRECT: { label: 'Wi-Fi Direct', icon: '📶', colorKey: 'primary' },
  P2P: { label: 'Wi-Fi Direct', icon: '📶', colorKey: 'primary' },
  BLUETOOTH: { label: 'بلوتوث', icon: 'ᛒ', colorKey: 'accent' },
};

export const TransportChip = ({ transport, migrating = false, style }) => {
  const { theme } = useAppTheme();
  const meta = TRANSPORT_META[transport];
  if (!meta && !migrating) return null;
  const color = migrating ? theme.accent : theme[meta?.colorKey || 'info'];

  return (
    <View
      style={[
        styles.chip,
        { backgroundColor: theme.chipBg, borderColor: color },
        style,
      ]}
      accessibilityLabel={migrating ? 'جاري التبديل بين القنوات بلا انقطاع' : `متصل عبر ${meta?.label || ''}`}
    >
      <View style={[styles.dot, { backgroundColor: color }]} />
      <Text style={[styles.text, { color }]}>
        {migrating ? 'تبديل سلس…' : `${meta.icon} ${meta.label}`}
      </Text>
    </View>
  );
};

const styles = StyleSheet.create({
  chip: {
    flexDirection: 'row-reverse',
    alignItems: 'center',
    alignSelf: 'flex-start',
    borderRadius: 999,
    borderWidth: 1,
    paddingHorizontal: 10,
    paddingVertical: 3,
    gap: 6,
  },
  dot: { width: 7, height: 7, borderRadius: 4 },
  text: { fontSize: 11, fontWeight: '700', letterSpacing: 0.2 },
});
export default TransportChip;
