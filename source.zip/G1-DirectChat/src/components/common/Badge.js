import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { useAppTheme } from '../../theme/themeContext';

export const Badge = ({ count, label, variant = 'primary', style }) => {
  const { theme } = useAppTheme();

  const getBg = () => {
    switch (variant) {
      case 'accent': return theme.accent;
      case 'primary': return theme.primary;
      case 'danger': return theme.error;
      case 'subtle': return theme.surfaceVariant;
      default: return theme.primary;
    }
  };
  const getFg = () => {
    if (variant === 'subtle') return theme.textSecondary;
    if (variant === 'accent') return theme.badgeText || '#04231F';
    return '#FFFFFF';
  };

  const text = count !== undefined ? (count > 99 ? '99+' : count.toString()) : label;
  if (!text && text !== 0) return null;

  return (
    <View style={[styles.badge, { backgroundColor: getBg() }, style]}>
      <Text style={[styles.text, { color: getFg() }]}>{text}</Text>
    </View>
  );
};

const styles = StyleSheet.create({
  badge: {
    minWidth: 22,
    height: 22,
    borderRadius: 11,
    paddingHorizontal: 7,
    justifyContent: 'center',
    alignItems: 'center',
  },
  text: { fontSize: 11.5, fontWeight: '800' },
});
export default Badge;
