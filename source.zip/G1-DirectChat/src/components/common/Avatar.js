import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { useAppTheme } from '../../theme/themeContext';
import { avatarPalette } from '../../theme/tokens';

/**
 * أفاتار "أورورا": ثنائية لونية حتمية مشتقة من الاسم (طبقتان بلا مكتبات)،
 * نقطة حضور متوهجة، وشارة ناقل صغيرة.
 */
export const Avatar = ({
  name = '؟',
  size = 48,
  isOnline = false,
  transportType,
}) => {
  const { theme } = useAppTheme();
  const [c1, c2] = avatarPalette(name);

  const getInitials = (n) => {
    if (!n) return '؟';
    const parts = n.trim().split(/\s+/);
    if (parts.length >= 2) return `${parts[0][0]}${parts[1][0]}`.toUpperCase();
    return n.substring(0, 2).toUpperCase();
  };

  const getTransportIcon = (type) => {
    switch (type) {
      case 'lan': return '🌐';
      case 'wifidirect':
      case 'wifi': return '📶';
      case 'bluetooth':
      case 'bt': return 'ᛒ';
      default: return null;
    }
  };

  return (
    <View style={[styles.container, { width: size, height: size }]}>
      {/* قاعدة اللون الأول */}
      <View
        style={{
          width: size, height: size, borderRadius: size / 2,
          backgroundColor: c1, overflow: 'hidden',
          justifyContent: 'center', alignItems: 'center',
        }}
      >
        {/* قوس اللون الثاني — طبقة مائلة تحاكي التدرج */}
        <View
          style={{
            position: 'absolute', width: size * 1.15, height: size * 1.15,
            borderRadius: size, backgroundColor: c2, opacity: 0.85,
            bottom: -size * 0.62, left: -size * 0.28,
            transform: [{ rotate: '24deg' }],
          }}
        />
        {/* لمعة زجاجية علوية */}
        <View
          style={{
            position: 'absolute', top: 0, left: 0, right: 0,
            height: size * 0.5,
            borderTopLeftRadius: size / 2, borderTopRightRadius: size / 2,
            backgroundColor: 'rgba(255,255,255,0.16)',
          }}
        />
        <Text
          style={{
            fontSize: size * 0.36, fontWeight: '800', color: '#FFFFFF',
            textShadowColor: 'rgba(0,0,0,0.25)', textShadowRadius: 2,
            textShadowOffset: { width: 0, height: 1 },
          }}
        >
          {getInitials(name)}
        </Text>
      </View>

      {isOnline && (
        <View
          style={{
            position: 'absolute', bottom: 0, right: 0,
            width: size * 0.3, height: size * 0.3, borderRadius: size * 0.15,
            backgroundColor: theme.online, borderWidth: 2.5,
            borderColor: theme.surface,
            shadowColor: theme.online, shadowOpacity: 0.9, shadowRadius: 4,
            shadowOffset: { width: 0, height: 0 }, elevation: 3,
          }}
        />
      )}

      {transportType && (
        <View
          style={{
            position: 'absolute', top: -2, left: -2,
            paddingHorizontal: 3, paddingVertical: 1, borderRadius: 8,
            backgroundColor: theme.surfaceSubtle,
            borderWidth: 1, borderColor: theme.border,
          }}
        >
          <Text style={{ fontSize: 10 }}>{getTransportIcon(transportType)}</Text>
        </View>
      )}
    </View>
  );
};

const styles = StyleSheet.create({
  container: { position: 'relative', justifyContent: 'center', alignItems: 'center' },
});
export default Avatar;
