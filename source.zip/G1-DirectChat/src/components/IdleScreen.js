import React from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, ActivityIndicator,
  ScrollView, StatusBar,
} from 'react-native';
import { useAppTheme } from '../theme/themeContext';
import { radius, shadow, spacing } from '../theme/tokens';
import Avatar from './common/Avatar';
import TransportChip from './common/TransportChip';

export default function IdleScreen({
  onStart, status, busy, onOpenProbe, wifiDirectEnabled, showCreateGroup, onCreateGroup,
  activeTier, btDevices, onBtScan, onBtConnect, btScanning,
}) {
  const { theme, isDark } = useAppTheme();
  const isOff = wifiDirectEnabled === false;
  // الزر بيختفي فقط أثناء عمليات الاتصال الفعلية، مش لمجرد وجود كلمة
  // "جاري" بالنص. سابقاً أي رسالة حالة كانت تخفي الزر فيبان وكأنه لا يستجيب.
  const loading = !!busy;

  return (
    <View style={[styles.screen, { backgroundColor: theme.background }]}>
      <StatusBar backgroundColor={theme.headerBg} barStyle="light-content" />

      {/* الشريط العلوي */}
      <View style={[styles.header, { backgroundColor: theme.headerBg }]}>
        <View style={{ flexDirection: 'row-reverse', alignItems: 'baseline', gap: 8 }}>
          <Text style={styles.headerTitle}>MusabX</Text>
          <View style={[styles.brandDot, { backgroundColor: theme.accent }]} />
        </View>
      </View>

      <ScrollView contentContainerStyle={styles.container}>
        {activeTier && activeTier !== 'NONE' && (
          <View style={{ alignSelf: 'center', marginBottom: 14 }}>
            <TransportChip transport={activeTier} />
          </View>
        )}

        <View style={[styles.heroCard, { backgroundColor: theme.surface }, shadow('#000', isDark ? 0.3 : 0.08, 4, 14, 3)]}>
          <Avatar name="MusabX" size={78} />
          <Text style={[styles.title, { color: theme.text }]}>اتصال مباشر بدون إنترنت</Text>
          <Text style={[styles.subtitle, { color: theme.textSecondary }]}>
            دردشة ومكالمات فيديو ونقل ملفات بين جهازين، بدون أي خادم وسيط
          </Text>
        </View>

        {isOff && (
          <View style={[styles.warningBox, { backgroundColor: isDark ? 'rgba(255,194,71,0.12)' : '#FFF4E0' }]}>
            <Text style={[styles.warningText, { color: theme.warning }]}>
              ⚠️ واي فاي مباشر غير مفعّل — فعّله من إعدادات الجهاز
            </Text>
          </View>
        )}

        {status ? (
          <View style={[styles.statusBox, { backgroundColor: theme.surface }, shadow('#000', isDark ? 0.25 : 0.06, 2, 8, 2)]}>
            {loading && <ActivityIndicator color={theme.primary} style={{ marginLeft: 10 }} />}
            <Text style={[styles.statusText, { color: theme.textSecondary }]}>{status}</Text>
          </View>
        ) : null}

        {!loading && (
          <>
            <TouchableOpacity
              style={[styles.primaryBtn, { backgroundColor: theme.primary }, shadow(theme.primary, 0.35, 5, 12, 4), isOff && styles.disabled]}
              onPress={onStart}
              disabled={isOff}
              activeOpacity={0.85}
            >
              <Text style={styles.primaryBtnText}>بدء الاتصال</Text>
            </TouchableOpacity>

            {showCreateGroup && !isOff && (
              <TouchableOpacity
                style={[styles.secondaryBtn, { borderColor: theme.primary }]}
                onPress={onCreateGroup}
                activeOpacity={0.85}
              >
                <Text style={[styles.secondaryBtnText, { color: theme.primary }]}>إنشاء مجموعة (أنا المضيف)</Text>
              </TouchableOpacity>
            )}

            <TouchableOpacity onPress={onOpenProbe} style={styles.probeLink}>
              <Text style={[styles.probeLinkText, { color: theme.textMuted }]}>فحص الشبكة و WebRTC</Text>
            </TouchableOpacity>

            <View style={styles.dividerRow}>
              <View style={[styles.dividerLine, { backgroundColor: theme.border }]} />
              <Text style={[styles.dividerText, { color: theme.textMuted }]}>بديل احتياطي</Text>
              <View style={[styles.dividerLine, { backgroundColor: theme.border }]} />
            </View>

            <Text style={[styles.sectionLabel, { color: theme.textSecondary }]}>بلوتوث — دردشة نصية فقط</Text>

            <TouchableOpacity
              style={[styles.outlineBtn, { backgroundColor: theme.surface, borderColor: theme.border }]}
              onPress={onBtScan}
              activeOpacity={0.85}
            >
              {btScanning
                ? <ActivityIndicator color={theme.primary} />
                : <Text style={[styles.outlineBtnText, { color: theme.text }]}>بحث عن أجهزة بلوتوث</Text>}
            </TouchableOpacity>

            {btDevices && btDevices.length > 0 && (
              <View style={[styles.deviceList, { backgroundColor: theme.surface }, shadow('#000', isDark ? 0.25 : 0.06, 2, 8, 2)]}>
                {btDevices.map(d => (
                  <TouchableOpacity
                    key={d.address}
                    style={[styles.deviceItem, { borderBottomColor: theme.borderSubtle }]}
                    onPress={() => onBtConnect(d.address)}
                    activeOpacity={0.7}
                  >
                    <Avatar name={d.name || '؟'} size={44} />
                    <View style={{ flex: 1, marginHorizontal: 12, alignItems: 'flex-end' }}>
                      <Text style={[styles.deviceName, { color: theme.text }]}>{d.name || 'جهاز غير معروف'}</Text>
                      <Text style={[styles.deviceAddr, { color: theme.textMuted }]}>{d.address}</Text>
                    </View>
                    <Text style={[styles.deviceArrow, { color: theme.textMuted }]}>‹</Text>
                  </TouchableOpacity>
                ))}
              </View>
            )}
          </>
        )}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1 },

  header: {
    paddingTop: 16, paddingBottom: 18, paddingHorizontal: spacing.xl,
    borderBottomLeftRadius: radius.xxl, borderBottomRightRadius: radius.xxl,
    alignItems: 'flex-end',
  },
  headerTitle: { color: '#fff', fontSize: 24, fontWeight: '800', letterSpacing: 0.3 },
  brandDot: { width: 8, height: 8, borderRadius: 4, marginBottom: 5 },

  container: { padding: spacing.lg, paddingBottom: 40 },

  heroCard: {
    borderRadius: radius.xl, padding: 26,
    alignItems: 'center', marginBottom: 20,
  },
  title: { fontSize: 19, fontWeight: '800', textAlign: 'center', marginTop: 16, letterSpacing: 0.2 },
  subtitle: { fontSize: 13.5, textAlign: 'center', marginTop: 8, lineHeight: 20 },

  warningBox: { borderRadius: radius.md, padding: 12, marginBottom: 14 },
  warningText: { fontSize: 13, textAlign: 'center', fontWeight: '600' },

  statusBox: {
    flexDirection: 'row-reverse', alignItems: 'center', justifyContent: 'center',
    borderRadius: radius.md, padding: 14, marginBottom: 14,
  },
  statusText: { fontSize: 13, textAlign: 'center', flexShrink: 1, fontWeight: '500' },

  primaryBtn: {
    borderRadius: radius.pill, paddingVertical: 16,
    alignItems: 'center',
  },
  primaryBtnText: { color: '#fff', fontSize: 16.5, fontWeight: '800', letterSpacing: 0.2 },
  disabled: { opacity: 0.45 },

  secondaryBtn: {
    borderRadius: radius.pill, paddingVertical: 14,
    alignItems: 'center', marginTop: 12, borderWidth: 1.6,
  },
  secondaryBtnText: { fontSize: 15, fontWeight: '700' },

  probeLink: { alignSelf: 'center', marginTop: 18, padding: 8 },
  probeLinkText: { fontSize: 12, textDecorationLine: 'underline' },

  dividerRow: { flexDirection: 'row', alignItems: 'center', marginVertical: 26, gap: 10 },
  dividerLine: { flex: 1, height: 1 },
  dividerText: { fontSize: 12, fontWeight: '600' },

  sectionLabel: { fontSize: 13, textAlign: 'center', marginBottom: 12, fontWeight: '600' },

  outlineBtn: {
    borderRadius: radius.pill, paddingVertical: 14,
    alignItems: 'center', borderWidth: 1,
  },
  outlineBtnText: { fontSize: 15, fontWeight: '700' },

  deviceList: { marginTop: 14, borderRadius: radius.lg, overflow: 'hidden' },
  deviceItem: {
    flexDirection: 'row-reverse', alignItems: 'center', padding: 13,
    borderBottomWidth: StyleSheet.hairlineWidth,
  },
  deviceName: { fontSize: 15, fontWeight: '700' },
  deviceAddr: { fontSize: 11, marginTop: 2 },
  deviceArrow: { fontSize: 24, fontWeight: '300' },
});
