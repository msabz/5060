import React, { useEffect, useRef } from 'react';
import {
  View, Text, TouchableOpacity, StyleSheet, StatusBar, Animated, Easing,
} from 'react-native';
import { avatarPalette } from '../theme/tokens';

/**
 * شاشة المكالمة الواردة — هوية أورورا: نبض سماوي حول أفاتار ثنائي اللون.
 *
 * نقطة أساسية: هالشاشة ما بتفتح الميكروفون إطلاقاً. الميكروفون
 * ما بينفتح إلا بعد ما يضغط المستخدم "ردّ" — وهاد يمنع أي طرف من
 * فتح ميكروفون الطرف الآخر بدون إذنه.
 */
export default function IncomingCallScreen({ peerName, isVideo, outgoing, onAccept, onReject }) {
  const pulse = useRef(new Animated.Value(0)).current;
  const [c1, c2] = avatarPalette(peerName || 'M');

  useEffect(() => {
    const loop = Animated.loop(
      Animated.sequence([
        Animated.timing(pulse, { toValue: 1, duration: 1200, easing: Easing.out(Easing.ease), useNativeDriver: true }),
        Animated.timing(pulse, { toValue: 0, duration: 1200, easing: Easing.in(Easing.ease), useNativeDriver: true }),
      ])
    );
    loop.start();
    return () => loop.stop();
  }, [pulse]);

  const scale = pulse.interpolate({ inputRange: [0, 1], outputRange: [1, 1.16] });
  const glow = pulse.interpolate({ inputRange: [0, 1], outputRange: [0.32, 0] });
  const scale2 = pulse.interpolate({ inputRange: [0, 1], outputRange: [1, 1.34] });
  const glow2 = pulse.interpolate({ inputRange: [0, 1], outputRange: [0.18, 0] });

  const letter = (peerName || 'M')[0].toUpperCase();

  return (
    <View style={styles.container}>
      <StatusBar backgroundColor="#070B16" barStyle="light-content" />

      <View style={styles.top}>
        <View style={styles.typePill}>
          <Text style={styles.callType}>
            {outgoing
              ? (isVideo ? '🎥 مكالمة فيديو…' : '📞 جاري الاتصال…')
              : (isVideo ? '🎥 مكالمة فيديو واردة' : '📞 مكالمة صوتية واردة')}
          </Text>
        </View>
      </View>

      <View style={styles.middle}>
        <View style={styles.avatarWrap}>
          <Animated.View style={[styles.glowRing, { borderColor: c2, transform: [{ scale: scale2 }], opacity: glow2 }]} />
          <Animated.View style={[styles.glowRingInner, { borderColor: c2, transform: [{ scale }], opacity: glow }]} />
          <View style={[styles.avatar, { backgroundColor: c1 }]}>
            <View style={[styles.avatarArc, { backgroundColor: c2 }]} />
            <Text style={styles.avatarText}>{letter}</Text>
          </View>
        </View>

        <Text style={styles.name} numberOfLines={1}>{peerName || 'الجهاز الآخر'}</Text>
        <Text style={styles.encrypted}>
          {outgoing ? 'يرنّ عند الطرف الآخر…' : '🔒 اتصال مباشر بين الجهازين · بلا خوادم'}
        </Text>
      </View>

      <View style={[styles.actions, outgoing && { justifyContent: 'center' }]}>
        <View style={styles.actionCol}>
          <TouchableOpacity style={[styles.actionBtn, styles.rejectBtn]} onPress={onReject}>
            <Text style={styles.rejectIcon}>📞</Text>
          </TouchableOpacity>
          <Text style={styles.actionLabel}>{outgoing ? 'إلغاء' : 'رفض'}</Text>
        </View>

        {!outgoing && (
          <View style={styles.actionCol}>
            <TouchableOpacity style={[styles.actionBtn, styles.acceptBtn]} onPress={onAccept}>
              <Text style={styles.acceptIcon}>{isVideo ? '🎥' : '📞'}</Text>
            </TouchableOpacity>
            <Text style={styles.actionLabel}>{isVideo ? 'فيديو' : 'ردّ'}</Text>
          </View>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: '#070B16', justifyContent: 'space-between' },

  top: { alignItems: 'center', paddingTop: 64 },
  typePill: {
    backgroundColor: 'rgba(255,255,255,0.07)', borderRadius: 999,
    paddingHorizontal: 18, paddingVertical: 8,
    borderWidth: 1, borderColor: 'rgba(255,255,255,0.08)',
  },
  callType: { color: 'rgba(255,255,255,0.7)', fontSize: 14, fontWeight: '600' },

  middle: { alignItems: 'center', flex: 1, justifyContent: 'center' },
  avatarWrap: { justifyContent: 'center', alignItems: 'center', marginBottom: 28 },
  glowRing: {
    position: 'absolute', width: 150, height: 150, borderRadius: 75,
    borderWidth: 2, backgroundColor: 'transparent',
  },
  glowRingInner: {
    position: 'absolute', width: 150, height: 150, borderRadius: 75,
    borderWidth: 3, backgroundColor: 'transparent',
  },
  avatar: {
    width: 132, height: 132, borderRadius: 66, overflow: 'hidden',
    justifyContent: 'center', alignItems: 'center',
  },
  avatarArc: {
    position: 'absolute', width: 150, height: 150, borderRadius: 75,
    opacity: 0.85, bottom: -80, left: -36, transform: [{ rotate: '24deg' }],
  },
  avatarText: {
    color: '#fff', fontSize: 54, fontWeight: '800',
    textShadowColor: 'rgba(0,0,0,0.3)', textShadowRadius: 3, textShadowOffset: { width: 0, height: 1 },
  },
  name: { color: '#fff', fontSize: 27, fontWeight: '700', letterSpacing: 0.3 },
  encrypted: { color: 'rgba(255,255,255,0.5)', fontSize: 12, marginTop: 10, fontWeight: '500' },

  actions: {
    flexDirection: 'row-reverse', justifyContent: 'space-evenly',
    alignItems: 'center', paddingBottom: 74, paddingHorizontal: 30,
  },
  actionCol: { alignItems: 'center' },
  actionBtn: {
    width: 72, height: 72, borderRadius: 36,
    justifyContent: 'center', alignItems: 'center',
    shadowOffset: { width: 0, height: 5 }, shadowOpacity: 0.4, shadowRadius: 12, elevation: 8,
  },
  acceptBtn: { backgroundColor: '#12C48B', shadowColor: '#12C48B' },
  rejectBtn: { backgroundColor: '#F04452', shadowColor: '#F04452' },
  acceptIcon: { fontSize: 30 },
  rejectIcon: { fontSize: 30, transform: [{ rotate: '135deg' }] },
  actionLabel: { color: 'rgba(255,255,255,0.7)', fontSize: 13, marginTop: 12, fontWeight: '600' },
});
