// نظام ألوان مطابق لواتساب (داكن)
export const WA = {
  green: '#1F2C34',        // الشريط العلوي
  greenLight: '#00A884',   // الأخضر الأساسي — زر الإرسال
  teal: '#00A884',         // الأزرار العائمة
  chatBg: '#0B141A',       // خلفية الدردشة
  outBubble: '#005C4B',    // فقاعة رسائلي
  inBubble: '#1F2C34',     // فقاعة الطرف الآخر
  text: '#E9EDEF',
  subText: '#8696A0',
  tick: '#53BDEB',         // علامة القراءة الزرقاء
  divider: '#222D34',
  inputBg: '#1F2C34',
  screenBg: '#0B141A',
  danger: '#F15C6D',
};
