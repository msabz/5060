// نظام ألوان مطابق لواتساب
export const WA = {
  green: '#141729',        // الشريط العلوي (كحلي عميق)
  greenLight: '#5B4CFF',   // بنفسجي أساسي
  teal: '#00D4C8',         // سماوي — الأزرار العائمة
  chatBg: '#F4F5FB',       // خلفية الدردشة
  outBubble: '#5B4CFF',    // فقاعة رسائلي
  inBubble: '#FFFFFF',     // فقاعة الطرف الآخر
  text: '#0F1222',
  subText: '#5F6480',
  tick: '#00D4C8',         // علامة القراءة
  divider: '#E3E5F0',
  inputBg: '#FFFFFF',
  screenBg: '#FFFFFF',
  danger: '#F04452',
};
