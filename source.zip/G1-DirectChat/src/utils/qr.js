/**
 * مولّد QR نقي (Byte mode, EC level M، إصدارات 1–10) بدون أي اعتمادية.
 * يُرجع مصفوفة ثنائية الأبعاد من true/false للرسم بمربعات.
 * مبني على مواصفة ISO/IEC 18004 — كافٍ لروابط musabx:// القصيرة.
 */
const EC_CODEWORDS_M = [0, 10, 16, 26, 36, 48, 64, 72, 88, 110, 130];
const EC_BLOCKS_M = [0, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5];
const TOTAL_CODEWORDS = [0, 26, 44, 70, 100, 134, 172, 196, 242, 292, 346];
const ALIGN = [[], [], [6, 18], [6, 22], [6, 26], [6, 30], [6, 34], [6, 22, 38], [6, 24, 42], [6, 26, 46], [6, 28, 50]];

const EXP = new Array(256); const LOG = new Array(256);
(() => { let x = 1; for (let i = 0; i < 255; i++) { EXP[i] = x; LOG[x] = i; x <<= 1; if (x & 0x100) x ^= 0x11d; } EXP[255] = EXP[0]; })();
const gmul = (a, b) => (a === 0 || b === 0) ? 0 : EXP[(LOG[a] + LOG[b]) % 255];

function rsGenerator(n) {
  let g = [1];
  for (let i = 0; i < n; i++) {
    const ng = new Array(g.length + 1).fill(0);
    for (let j = 0; j < g.length; j++) { ng[j] ^= g[j]; ng[j + 1] ^= gmul(g[j], EXP[i]); }
    g = ng;
  }
  return g;
}
function rsEncode(data, n) {
  const g = rsGenerator(n);
  const res = new Array(n).fill(0);
  for (const d of data) {
    const f = d ^ res[0];
    res.shift(); res.push(0);
    if (f) for (let j = 0; j < n; j++) res[j] ^= gmul(g[j + 1], f);
  }
  return res;
}

function chooseVersion(len) {
  for (let v = 1; v <= 6; v++) {
    const dataCw = TOTAL_CODEWORDS[v] - EC_CODEWORDS_M[v];
    const headerBits = 4 + (v <= 9 ? 8 : 16);
    if (Math.ceil((headerBits + len * 8) / 8) <= dataCw) return v;
  }
  throw new Error('QR: text too long');
}

export function encodeQR(text) {
  const bytes = Array.from(unescape(encodeURIComponent(text)), c => c.charCodeAt(0));
  const v = chooseVersion(bytes.length);
  const size = 17 + 4 * v;
  const dataCw = TOTAL_CODEWORDS[v] - EC_CODEWORDS_M[v];
  const bits = [];
  const push = (val, n) => { for (let i = n - 1; i >= 0; i--) bits.push((val >> i) & 1); };
  push(0b0100, 4); push(bytes.length, v <= 9 ? 8 : 16);
  bytes.forEach(b => push(b, 8));
  for (let i = 0; i < 4 && bits.length < dataCw * 8; i++) bits.push(0);
  while (bits.length % 8) bits.push(0);
  const data = [];
  for (let i = 0; i < bits.length; i += 8) data.push(parseInt(bits.slice(i, i + 8).join(''), 2));
  for (let p = 0; data.length < dataCw; p++) data.push(p % 2 ? 0x11 : 0xec);

  // blocks
  const nb = EC_BLOCKS_M[v]; const ecPer = EC_CODEWORDS_M[v] / nb;
  const shortLen = Math.floor(dataCw / nb); const longCount = dataCw % nb;
  const blocks = []; let off = 0;
  for (let b = 0; b < nb; b++) {
    const len = shortLen + (b >= nb - longCount ? 1 : 0);
    const d = data.slice(off, off + len); off += len;
    blocks.push({ d, e: rsEncode(d, ecPer) });
  }
  const out = [];
  const maxD = Math.max(...blocks.map(b => b.d.length));
  for (let i = 0; i < maxD; i++) for (const b of blocks) if (i < b.d.length) out.push(b.d[i]);
  for (let i = 0; i < ecPer; i++) for (const b of blocks) out.push(b.e[i]);

  // matrix
  const m = Array.from({ length: size }, () => new Array(size).fill(null));
  const set = (r, c, val) => { m[r][c] = val; };
  const finder = (r, c) => { for (let i = -1; i <= 7; i++) for (let j = -1; j <= 7; j++) {
    const rr = r + i, cc = c + j; if (rr < 0 || cc < 0 || rr >= size || cc >= size) continue;
    const on = (i >= 0 && i <= 6 && j >= 0 && j <= 6) && (i === 0 || i === 6 || j === 0 || j === 6 || (i >= 2 && i <= 4 && j >= 2 && j <= 4));
    set(rr, cc, on); } };
  finder(0, 0); finder(0, size - 7); finder(size - 7, 0);
  for (let i = 8; i < size - 8; i++) { if (m[6][i] === null) set(6, i, i % 2 === 0); if (m[i][6] === null) set(i, 6, i % 2 === 0); }
  const al = ALIGN[v];
  for (const r of al) for (const c of al) {
    if (m[r][c] !== null) continue;
    for (let i = -2; i <= 2; i++) for (let j = -2; j <= 2; j++) set(r + i, c + j, Math.max(Math.abs(i), Math.abs(j)) !== 1);
  }
  // reserve format areas
  for (let i = 0; i < 9; i++) { if (m[8][i] === null) set(8, i, false); if (m[i][8] === null) set(i, 8, false); }
  for (let i = size - 8; i < size; i++) { if (m[8][i] === null) set(8, i, false); if (m[i][8] === null) set(i, 8, false); }
  set(size - 8, 8, true);
  if (v >= 7) for (let i = 0; i < 6; i++) for (let j = 0; j < 3; j++) { set(i, size - 11 + j, false); set(size - 11 + j, i, false); }

  // place data (mask 0 → (r+c)%2===0)
  const reserved = m.map(row => row.map(x => x !== null));
  let bi = 0; const total = out.length * 8;
  const bitAt = k => (out[k >> 3] >> (7 - (k & 7))) & 1;
  for (let col = size - 1; col > 0; col -= 2) {
    if (col === 6) col--;
    for (let k = 0; k < size; k++) {
      const row = ((size - 1 - col) >> 1) % 2 === 0 ? size - 1 - k : k;
      for (const c of [col, col - 1]) {
        if (reserved[row][c]) continue;
        const bit = bi < total ? bitAt(bi) : 0; bi++;
        set(row, c, ((bit ^ ((row + c) % 2 === 0 ? 1 : 0)) === 1));
      }
    }
  }
  // format info for EC M (01) + mask 0 (000): precomputed 0x5412 ^ ... => use table
  const fmt = 0x5412; // (M, mask0) after BCH & mask
  const fbits = []; for (let i = 14; i >= 0; i--) fbits.push((fmt >> i) & 1);
  const fpos1 = [[8, 0], [8, 1], [8, 2], [8, 3], [8, 4], [8, 5], [8, 7], [8, 8], [7, 8], [5, 8], [4, 8], [3, 8], [2, 8], [1, 8], [0, 8]];
  const fpos2 = [[size - 1, 8], [size - 2, 8], [size - 3, 8], [size - 4, 8], [size - 5, 8], [size - 6, 8], [size - 7, 8], [8, size - 8], [8, size - 7], [8, size - 6], [8, size - 5], [8, size - 4], [8, size - 3], [8, size - 2], [8, size - 1]];
  fbits.forEach((b, i) => { set(fpos1[i][0], fpos1[i][1], b === 1); set(fpos2[i][0], fpos2[i][1], b === 1); });
  if (v >= 7) {
    // version info
    let vi = v << 12; let rem = v; for (let i = 0; i < 12; i++) rem = (rem << 1) ^ ((rem >> 11) & 1 ? 0x1f25 : 0);
    vi = (v << 12) | (rem & 0xfff);
    for (let i = 0; i < 18; i++) { const b = ((vi >> i) & 1) === 1; set(Math.floor(i / 3), size - 11 + (i % 3), b); set(size - 11 + (i % 3), Math.floor(i / 3), b); }
  }
  return m.map(row => row.map(x => !!x));
}
