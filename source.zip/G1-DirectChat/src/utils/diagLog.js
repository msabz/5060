/**
 * سجل تشخيص داخل التطبيق — مخزن دائري (ring buffer) يجمع أحداث النواقل
 * والأخطاء كي يستطيع المستخدم إظهارها/مشاركتها بعد أي فشل ميداني.
 *
 * درس LocalSend/KDE Connect: «كن ذكياً — جرّب عدة طرق، وسجّل كل شيء».
 * بلا سجل مرئي داخل التطبيق، كل فشل ميداني يبقى صامتاً وغير قابل للإصلاح.
 */

const MAX_ENTRIES = 500;

const entries = [];
const listeners = new Set();

function formatTime(ts) {
  const d = new Date(ts);
  const hh = String(d.getHours()).padStart(2, '0');
  const mm = String(d.getMinutes()).padStart(2, '0');
  const ss = String(d.getSeconds()).padStart(2, '0');
  return `${hh}:${mm}:${ss}`;
}

/**
 * @param {string} tag  مصدر الحدث: BT / P2P / LAN / COORD / LINK / APP / UI
 * @param {string} message وصف قصير
 * @param {*} data  تفاصيل اختيارية (تُحوَّل JSON بأمان)
 */
export function diag(tag, message, data = undefined) {
  const entry = {
    at: Date.now(),
    tag: String(tag || 'APP'),
    message: String(message || ''),
    data: undefined,
  };
  if (data !== undefined) {
    try {
      entry.data = typeof data === 'string' ? data : JSON.stringify(data);
    } catch (e) {
      entry.data = String(data);
    }
    if (entry.data && entry.data.length > 240) entry.data = `${entry.data.slice(0, 240)}…`;
  }
  entries.push(entry);
  if (entries.length > MAX_ENTRIES) entries.splice(0, entries.length - MAX_ENTRIES);
  listeners.forEach(fn => {
    try { fn(entry); } catch (e) {}
  });
  // لا نوقف console — السجل يبقى متاحاً عبر adb أيضاً
  try { console.log(`[${entry.tag}] ${entry.message}${entry.data ? ` ${entry.data}` : ''}`); } catch (e) {}
  return entry;
}

export function diagEntries() {
  return entries.slice();
}

export function diagSubscribe(listener) {
  if (typeof listener !== 'function') return () => {};
  listeners.add(listener);
  return () => listeners.delete(listener);
}

export function diagClear() {
  entries.splice(0, entries.length);
  listeners.forEach(fn => {
    try { fn(null); } catch (e) {}
  });
}

/** يصدّر السجل كنص قابل للمشاركة/اللصق — سطر لكل حدث. */
export function diagExport() {
  return entries
    .map(e => `${formatTime(e.at)} [${e.tag}] ${e.message}${e.data ? ` — ${e.data}` : ''}`)
    .join('\n');
}
