/**
 * مصافحة الهوية الموقّعة (نمط KDE Connect/Syncthing + درس Bridgefy):
 * لا نثق بأي deviceId إلا بعد إثبات ملكية المفتاح الخاص المرتبط به.
 *
 * التدفق (يعمل والواجهة مفتوحة أو مقفولة لأنه مراقب على قناة الإشارات):
 *   A → B : identity { deviceId, deviceName, pubKey, musabId, nonce }
 *   B → A : identity-proof { deviceId, pubKey, nonce: <nonceA>, sig: Sign_B(nonceA) }
 *   A يتحقق: التوقيع صحيح بمفتاح B + المفتاح مطابق للمثبّت مسبقاً (إن وُجد).
 *   - أول مرة: يثبّت المفتاح (TOFU).
 *   - مطابق: الجهة "موثّقة".
 *   - مختلف: 'identity-mismatch' — يُبلَّغ App ويُقطع الاتصال.
 * الطرفان يقومان بنفس الشيء بالاتجاهين.
 */
import { NativeModules } from 'react-native';
import {
  addSignalingMessageObserver,
  sendSignalingMessage,
  setOutgoingMessageDecorator,
  setMigrationIdentity,
} from '../webrtc/signaling';

// حماية لبيئة الاختبار حيث react-native مُحاكى جزئياً
const Keys = (NativeModules && NativeModules.IdentityKeysModule) || null;

let myIdentity = null;         // { pubKey, musabId, deviceId }
let lastSentNonce = null;      // آخر nonce أرسلناه ضمن identity

function makeNonce() {
  let out = Date.now().toString(16);
  for (let i = 0; i < 4; i++) out += Math.floor(Math.random() * 0xffffffff).toString(16).padStart(8, '0');
  return out;
}
const verified = new Map();    // peerId -> { pubKey, musabId, at }
const listeners = new Set();
let installed = false;

export function isIdentityAvailable() {
  return !!Keys;
}

export async function loadMyIdentity() {
  if (!Keys) return null;
  if (!myIdentity) {
    const { getDeviceIdentity } = require('./Persistence');
    const [keys, dev] = await Promise.all([Keys.getIdentity(), getDeviceIdentity().catch(() => null)]);
    myIdentity = { ...keys, deviceId: dev?.deviceId || null };
    // موقّع هجرة الجلسة: إثبات الهوية على المسار الجديد بدون إعادة اقتران
    try {
      setMigrationIdentity({
        deviceId: myIdentity.deviceId,
        signer: {
          pubKey: myIdentity.pubKey,
          sign: nonce => Keys.sign(nonce),
          verify: async (peerId, pubKey, nonce, sig) => {
            const pinned = await Keys.getPinnedKey(peerId);
            const key = pinned || pubKey;
            if (!key || !sig) return false;
            if (pinned && pubKey && pinned !== pubKey) return false;
            return Keys.verify(key, nonce, sig);
          },
        },
      });
    } catch (e) {}
  }
  return myIdentity;
}

export function getMyMusabId() {
  return myIdentity?.musabId || null;
}

export function getVerifiedPeer(peerId) {
  return verified.get(peerId) || null;
}

export function onIdentityEvent(fn) {
  listeners.add(fn);
  return () => listeners.delete(fn);
}

function emit(evt) {
  listeners.forEach(fn => { try { fn(evt); } catch (e) {} });
}

function decorateOutgoingIdentity(msg) {
  if (!Keys || msg?.type !== 'identity' || !myIdentity) return msg;
  lastSentNonce = makeNonce();
  return { ...msg, pubKey: myIdentity.pubKey, musabId: myIdentity.musabId, nonce: lastSentNonce, idv: 1 };
}

async function handleIncoming(msg) {
  if (!Keys || !msg || !msg.deviceId) return;

  if (msg.type === 'identity') {
    if (!msg.pubKey || !msg.nonce) {
      emit({ type: 'legacy-peer', peerId: msg.deviceId });
      return;
    }
    // نبرهن هويتنا للطرف الآخر بتوقيع الـ nonce الذي أرسله
    try {
      const me = await loadMyIdentity();
      const sig = await Keys.sign(msg.nonce);
      sendSignalingMessage({
        type: 'identity-proof',
        deviceId: me.deviceId || undefined,
        pubKey: me.pubKey,
        musabId: me.musabId,
        nonce: msg.nonce,
        sig,
      });
    } catch (e) {}
    // ونتحقق من مفتاحه المعلن مقابل المثبّت (التحقق النهائي عند وصول proof منه)
    const pinned = await Keys.getPinnedKey(msg.deviceId);
    if (pinned && pinned !== msg.pubKey) {
      emit({ type: 'identity-mismatch', peerId: msg.deviceId, stage: 'announce' });
    }
    return;
  }

  if (msg.type === 'identity-proof') {
    if (!lastSentNonce || msg.nonce !== lastSentNonce) return; // ليس رداً على تحدّينا
    const ok = await Keys.verify(msg.pubKey, msg.nonce, msg.sig);
    if (!ok) {
      emit({ type: 'identity-invalid', peerId: msg.deviceId });
      return;
    }
    const pinned = await Keys.getPinnedKey(msg.deviceId);
    if (pinned && pinned !== msg.pubKey) {
      emit({ type: 'identity-mismatch', peerId: msg.deviceId, stage: 'proof' });
      return;
    }
    if (!pinned) await Keys.pinKey(msg.deviceId, msg.pubKey);
    verified.set(msg.deviceId, { pubKey: msg.pubKey, musabId: msg.musabId, at: Date.now() });
    emit({ type: 'identity-verified', peerId: msg.deviceId, musabId: msg.musabId, firstTime: !pinned });
  }
}

/** يُستدعى مرة واحدة عند إقلاع التطبيق (index.js أو App). */
export function installIdentityVerifier() {
  if (installed || !Keys) return;
  installed = true;
  setOutgoingMessageDecorator(decorateOutgoingIdentity);
  addSignalingMessageObserver(msg => { handleIncoming(msg).catch(() => {}); });
  loadMyIdentity().catch(() => {});
}
