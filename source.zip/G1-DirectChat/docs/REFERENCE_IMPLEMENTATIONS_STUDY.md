# دراسة التطبيقات المرجعية العشرة — قرارات معمارية معتمدة لـ MusabX

> أُجريت على الشيفرات المصدرية المرفوعة (Briar, briar-mailbox, KDE Connect,
> Meshenger, Bada/QuickShare, LocalSend + protocol spec, libp2p specs,
> AOSP Wifi, Signal). كل قرار أدناه موثّق بموضعه في الكود المرجعي، ومقابل
> بموضع المشكلة في كودنا. هذه الوثيقة هي المرجع الملزم لمراحل الإصلاح الجذري.

## 1) Briar — إدارة الناقلات المتعددة والتبديل بلا انقطاع

**الملفات**: `bramble-core/.../connection/ConnectionRegistryImpl.java`,
`bramble-core/.../plugin/PollerImpl.java`, `bramble-core/.../plugin/BackoffImpl.java`,
`bramble-android/.../plugin/bluetooth/AndroidBluetoothPlugin.java`

- **سجل الاتصالات**: قائمة اتصالات متزامنة لكل جهة (`Map<ContactId, List<ConnectionRecord>>`).
  عند تسجيل اتصال جديد: لو كان الأول → حدث `ContactConnectedEvent`؛ وإلا يبقى جنب القديم.
- **المقارنة والمقاطعة** (`compareConnections` + `setPriority`):
  - اتصال جديد عبر ناقل «أفضل» (حسب `transportPrefs`) → `interruptOutgoingSession()`
    لكل اتصال أقدم أدنى — إنهاء رشيق لجلسة المزامنة ثم إغلاق (MBB فعلي).
  - اتصال جديد أدنى من الموجود → يُقاطع هو فوراً (لا ازدواج عبثي).
  - نفس الناقل → **كسر تعادل بمقارنة nonce** (`Bytes.compare(pA.getNonce(), pB.getNonce())`)
    — يمنع الطرفين من قتل اتصال بعضهما عند التزامن.
- **بلوتوث بلا إقران نظام**: `listenUsingInsecureRfcommWithServiceRecord("RFCOMM", uuid)`
  + `createInsecureRfcommSocketToServiceRecord(uuid)` — قناة RFCOMM غير آمنة، والأمان
  (تبادل مفاتيح + إثبات ملكية) في طبقة Bramble. عنوان MAC وUUID الجهة يتبادلان خارج
  النطاق (QR/تبادل جهات).
- **الاستطلاع الدوري**: `PollerImpl` يجدول لكل ناقل، والفاصل من `Backoff.getPollingInterval()`
  — أسّي: `min * base^n` محدود بسقف. بلوتوث: min=60s, max=600s (`AndroidBluetoothPluginFactory`).
  نجاح الاتصال يصفّر الـ backoff (`reset()`).
- **نموذج Plugin**: كل ناقل Plugin بحالة (STARTING_STOPPING/ACTIVE/DISABLED) وأحداث
  `TransportActiveEvent/InactiveEvent` — الناقل يُدار مستقلاً.

## 2) KDE Connect — التوجيه لكل رسالة عبر أفضل رابط حي

**الملفات**: `src/.../Device.kt`, `backends/lan/LanLinkProvider.java`,
`backends/bluetooth/BluetoothLinkProvider.kt`

- `Device.links = CopyOnWriteArrayList<BaseLink>` — كل الروابط حية معاً، مرتبة تنازلياً
  حسب `linkProvider.priority` (**LAN=20، BT=10، loopback=0**).
- الإرسال: `links.any { link -> link.sendPacket(np) }` — أول رابط ينجح يكفي؛ فشل رابط
  يجرّب التالي تلقائياً. **لا يوجد "حدث تبديل" إطلاقاً** — إضافة رابط أفضل تجعل الرسالة
  التالية تسلكه فوراً، وإزالة رابط ميت لا توقف شيئاً.
- **الواجهة لا تكذب**: `isReachable get() = links.isNotEmpty()` — «متصل» يعني قناة حية.
- الهوية أول ما على السلك: المستمع TCP يقرأ `identityPacket` أولاً ويتحقق
  (`DeviceInfo.isValidIdentityPacket`) — نمط connect-first/verify-in-band الذي اعتمدناه.
- اكتشاف LAN: بث UDP للهوية على المنافذ 1716-1764 ← المستقبِل يفتح TCP عائداً.
- بلوتوث: `createRfcommSocketToServiceRecord(SERVICE_UUID)` (آمن) — لكن KDE يملك تدفق
  إقران داخلي خاص به فوق القناة. نحن نختار غير الآمن (أدناه) لأن جمهورنا «غرباء بلا إقران».

## 3) Meshenger — مكالمات WebRTC بلا خوادم وبلا اكتشاف

**الملفات**: `AddressUtils.kt` (`getLinkLocalFromMAC`, `createEUI64Address`),
`Connector.kt` (`mapMACtoPrefixes`), `call/RTCCall.kt`

- الجهة تُحفظ بـ {pubKey, MAC, name}. العنوان يُشتق: MAC → EUI-64 → `fe80::...`
  link-local — يعمل على أي واجهة L3 (LAN/هوتسبوت/VPN) بلا بروتوكول اكتشاف.
  `mapMACtoPrefixes` يجرّب الاشتقاق على كل واجهة محلية.
- إشارة WebRTC عبر TCP مباشر؛ المفتاح العام يتحقق من الهوية داخل القناة.
- تحذير منصة: Android 10+ يولّد MAC عشوائياً لكل شبكة/واجهة — لذا الاشتقاق يعمل فقط
  مع MAC معلَن حديثاً (نتعلمه داخل القناة كما فعلنا بـ `p2p-address`).

## 4) Bada (Quick Share interop) — ترقية السرعة داخل القناة

**الملفات**: `discovery-android/.../medium/WifiDirectMediumProvider.kt`,
`WifiDirectGroupController.kt`, `hotspot/AndroidLocalOnlyHotspotController.kt`

- **«bandwidth upgrade»**: النقل يبدأ على المتاح (LAN)، ثم داخل القناة نفسها:
  المستقبِل ينشئ مجموعة P2P (`createGroup`) ويقرأ SSID+passphrase+GO-IP ويرسلها
  كـ `UpgradePathCredentials.WifiDirect`؛ المرسل ينضم (`connect`) ويفتح TCP لعنوان
  المالك. ترقية كاملة دون قطع النقل الجاري.
- **القيد الجوهري**: «Wi-Fi Direct is device-wide — overlapping upgrade attempts are
  declined and the framework falls back» — مجموعة P2P واحدة فقط على الجهاز كله؛
  أي محاولة ثانية تُرفض بأدب ويسقط الإطار للمتوسط التالي.
- `MediumRegistry` + `MediumProvider.isSupported()` يفحص الأذونات أولاً
  (`NEARBY_WIFI_DEVICES` API 33+ وإلا `ACCESS_FINE_LOCATION`) — الناقل غير المُرخَّص
  «غير موجود» للمنسق بدل أن يفشل أثناء الاستخدام.
- بديل Hotspot: `startLocalOnlyHotspot` (API 26+) — مسار احتياطي قوي حين يتعذر P2P.

## 5) LocalSend + protocol spec
- هوية = fingerprint؛ اكتشاف multicast UDP افتراضياً + سقوط على HTTP legacy.
- مبدأ «كن ذكياً»: لا تفترض توفر أي آلية — جرّب عدة طرق بالتوازي.

## 6) libp2p specs / AOSP Wifi / Signal / briar-mailbox
- libp2p specs: مرجع دورة حياة الاتصال والتعدد — لطبقة النقل المستقبلية.
- AOSP Wifi (`packages/modules/Wifi`): مرجع داخلي لسلوك المنصة (عشوائية MAC في P2P،
  دورة حياة المجموعة) عند الحاجة لحافة أندرويدية دقيقة.
- Signal: معمارية خادمية مركزية — لا يخدم نقلنا المباشر؛ لم يُعتمد.
- briar-mailbox: نمط تخزين-و-تمرير لاحق (تسليم مؤجل) — ملاحظة مستقبلية.

---

## الأسباب الجذرية المؤكدة في كودنا + العلاج المعتمد

### BT-1: البلوتوث ميت بالتصميم
`BluetoothConnectionModule.kt`:
- `createRfcommSocketToServiceRecord` (آمن) + `listenUsingRfcommWithServiceRecord` (آمن)
- `requireBonded(device)` يرمي `IOException("Secure Bluetooth connection requires Android pairing")`
  لأي جهاز غير مقترن نظامياً.
⟹ غريبان لا يتصلان أبداً. **العلاج (Briar)**: التحول إلى insecure RFCOMM؛ الأمان يبقى
كاملاً عبر طبقة الهوية الموقعة الموجودة أصلاً (pubKey + nonce + تثبيت المفتاح TOFU).

### SW-1: لا تبديل تلقائي بين الطبقات
المنسق الحالي يختار ناقلاً واحداً ويلتصق. **العلاج (KDE+Briar)**:
1. نموذج روابط متزامنة: `links[]` لكل جهة بأولويات (LAN 30 > P2P 20 > BT 10).
2. إرسال كل رسالة عبر أفضل رابط حي (`links.any`) — تبديل صامت بطبيعته.
3. ترقية استباقية: عند ظهور ناقل أعلى، يُبنى ويُتحقق ثم يُقاطع الأدنى بأدب
   (`interruptOutgoingSession` المنطق) مع كسر تعادل nonce.

### UI-1: صف «متصل» المجمّد
الحالة من بيانات قديمة لا من قنوات حية. **العلاج (KDE)**: `isReachable = liveLinks > 0`
+ Pinger أسلوب Meshenger لكشف موت القناة الصامت.

### P2P-1: اكتمال استقلال Wi-Fi Direct
تعلّم MAC داخل القناة موجود؛ يُستكمل بتسليم اعتمادات المجموعة (Bada) عند الحاجة
لنقل ملفات ثقيلة، مع قاعدة «مجموعة واحدة device-wide».

### DISC-1: الظهور التلقائي
BLE يعمل؛ يُضاف Poller بـ Backoff أسّي (Briar) يحاول الاتصال بالمعارف دورياً على كل
ناقل متاح — نجاح يصفّر، فشل يرفع الفاصل حتى 10 دقائق.

## حدود صارمة للتنفيذ
- لا اعتماديات npm أصلية جديدة؛ كل العمل على Kotlin الموجود + JS.
- لا `bindProcessToNetwork`؛ التوجيه لكل مقبس (خيار interface) كما هو معتمد.
- I2P لاحقاً ينضم كـ LinkProvider أدنى أولوية دون لمس هذا المحرك (العقد في
  `docs/I2P_TRANSPORT_READINESS.md` متوافق: روابط متعددة + أولوية + إرسال بالأفضل).
