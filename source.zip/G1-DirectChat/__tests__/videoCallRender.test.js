/**
 * حراسة إطار الفيديو «الشفاف»: صورة PiP المحلية كانت تُرسم تحت سطح الفيديو
 * البعيد (zOrder)، ومسار الفيديو البعيد المتأخر لم يكن يُعيد تهيئة RTCView.
 */
import fs from 'fs';
import path from 'path';

const callScreenSource = fs.readFileSync(
  path.join(__dirname, '..', 'src', 'components', 'CallScreen.js'),
  'utf8'
);
const rtcAudioSource = fs.readFileSync(
  path.join(__dirname, '..', 'src', 'media', 'WebRTCAudio.js'),
  'utf8'
);

describe('video call rendering guards', () => {
  test('local PiP renders above the remote surface (zOrder)', () => {
    expect(callScreenSource).toMatch(/zOrder=\{0\}[\s\S]*?remote|remote-\$\{remoteStreamURL\}/);
    expect(callScreenSource).toContain('zOrder={1}');
    expect(callScreenSource).toContain('zOrder={0}');
  });

  test('RTCView remounts when stream identity changes (keyed by URL)', () => {
    expect(callScreenSource).toContain('key={`remote-${remoteStreamURL}`}');
    expect(callScreenSource).toContain('key={`local-${localStreamURL}`}');
  });

  test('remote stream is rebuilt per track so late video triggers a fresh URL', () => {
    expect(rtcAudioSource).toContain('const next = new MediaStream();');
    expect(rtcAudioSource).toContain("t.readyState === 'ended'");
    expect(rtcAudioSource).toContain('remoteStream = next;');
  });
});
