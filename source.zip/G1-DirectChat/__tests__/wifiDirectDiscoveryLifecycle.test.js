import fs from 'fs';
import path from 'path';

describe('Wi-Fi Direct discovery lifecycle regression coverage', () => {
  const nativeSource = fs.readFileSync(
    path.join(
      __dirname,
      '..',
      'android',
      'app',
      'src',
      'main',
      'java',
      'com',
      'm200',
      'directconnection',
      'DirectConnectionModule.kt'
    ),
    'utf8'
  );
  const appSource = fs.readFileSync(
    path.join(__dirname, '..', 'src', 'App.js'),
    'utf8'
  );
  const homeSource = fs.readFileSync(
    path.join(__dirname, '..', 'src', 'components', 'HomeScreen.js'),
    'utf8'
  );

  test('cleanup serializes P2P quiesce before group verification', () => {
    const start = nativeSource.indexOf('fun cleanupConnection(timeoutMs: Double, promise: Promise)');
    const end = nativeSource.indexOf('fun getConnectionInfo(promise: Promise)', start);
    const cleanup = nativeSource.slice(start, end);

    expect(start).toBeGreaterThanOrEqual(0);
    expect(end).toBeGreaterThan(start);
    expect(cleanup).toContain('stopDiscoveryThenClear(0)');
    expect(cleanup).toContain('manager.stopPeerDiscovery(operationChannel');
    expect(cleanup).toContain('clearRequestsThenCancel(0)');
    expect(cleanup).toContain('manager.clearServiceRequests(operationChannel');
    expect(cleanup).toContain('cancelThenPoll()');
    expect(cleanup).toContain('manager.cancelConnect(operationChannel');

    expect(cleanup).toMatch(
      /manager\.stopPeerDiscovery\(operationChannel,[\s\S]*?override fun onSuccess\(\) \{[\s\S]*?clearRequestsThenCancel\(0\)/
    );
    expect(cleanup).toMatch(
      /manager\.clearServiceRequests\(operationChannel,[\s\S]*?override fun onSuccess\(\) \{[\s\S]*?cancelThenPoll\(\)/
    );
  });

  test('generic Wi-Fi Direct availability is not presented as DirectChat identity proof', () => {
    expect(appSource).toContain('unconfirmed: d.isMusab !== true');
    expect(appSource).toContain('isMusab: peer.unconfirmed !== true');
    expect(appSource).toContain('peerId: peer.unconfirmed ? undefined : peer.peerId');
    expect(homeSource).toContain('Wi-Fi Direct · غير مؤكد');
    expect(homeSource).toContain('item.unconfirmed ?');
  });
});
