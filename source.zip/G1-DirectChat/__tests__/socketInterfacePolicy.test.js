/**
 * سياسة ربط الواجهة لكل سوكت (بديل bindProcessToNetwork الممنوع في التقرير):
 * - أهداف LAN تُربط بـ 'wifi' لتفادي توجيه خلوي أثناء الهجرة.
 * - أهداف Wi-Fi Direct (192.168.49.x) تُترك بلا ربط — ربطها بـ wlan0 يمنع
 *   الهبوط إلى P2P ويكسر الاتصال عندما يكون Wi-Fi Direct هو الناقل الوحيد.
 */
jest.mock('react-native-tcp-socket', () => ({
  createServer: jest.fn(),
  createConnection: jest.fn(),
}));

import TcpSocket from 'react-native-tcp-socket';
import { connectOutboundSocket } from '../src/network/SignalingSession';

function fakeSocket() {
  return {
    on: jest.fn(),
    once: jest.fn(),
    removeListener: jest.fn(),
    write: jest.fn(),
    destroy: jest.fn(),
    setKeepAlive: jest.fn(),
    setNoDelay: jest.fn(),
  };
}

describe('سياسة ربط الواجهة لكل سوكت', () => {
  beforeEach(() => jest.clearAllMocks());

  test('iface=null ينشئ اتصالاً بلا خيار interface إطلاقاً', async () => {
    const sock = fakeSocket();
    TcpSocket.createConnection.mockImplementation((opts, cb) => { setImmediate(cb); return sock; });
    await connectOutboundSocket({ host: '192.168.49.1', port: 8089, maxRetries: 1, iface: null });
    const opts = TcpSocket.createConnection.mock.calls[0][0];
    expect(opts).not.toHaveProperty('interface');
    expect(opts.host).toBe('192.168.49.1');
  });

  test("iface='wifi' يمرر interface:'wifi' للمكتبة", async () => {
    const sock = fakeSocket();
    TcpSocket.createConnection.mockImplementation((opts, cb) => { setImmediate(cb); return sock; });
    await connectOutboundSocket({ host: '192.168.1.5', port: 8089, maxRetries: 1, iface: 'wifi' });
    const opts = TcpSocket.createConnection.mock.calls[0][0];
    expect(opts.interface).toBe('wifi');
  });

  test('prepareMigration لا يربط wifi لعناوين Wi-Fi Direct (حارس مصدري)', () => {
    const fs = require('fs');
    const path = require('path');
    const sig = fs.readFileSync(path.join(__dirname, '..', 'src', 'webrtc', 'signaling.js'), 'utf8');
    const fnStart = sig.indexOf('export function prepareMigration');
    expect(fnStart).toBeGreaterThan(-1);
    const body = sig.slice(fnStart, fnStart + 4000);
    // لا ربط أعمى بعد اليوم
    expect(body).not.toContain("iface: 'wifi' })");
    // حتمية الاستثناء لشبكة 192.168.49.0/24
    expect(body).toMatch(/192\\\.168\\\.49/);
  });
});
