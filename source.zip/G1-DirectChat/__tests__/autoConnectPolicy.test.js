const { planAutoConnect, isInitiator, backoffFor, AUTO_CONNECT } = require('../src/network/autoConnectPolicy');

describe('autoConnectPolicy', () => {
  test('smaller id initiates, larger id waits', () => {
    expect(isInitiator('a', 'b')).toBe(true);
    expect(isInitiator('b', 'a')).toBe(false);
    const a = planAutoConnect({ myDeviceId: 'a', peer: { deviceId: 'b', lanReachable: true } });
    const b = planAutoConnect({ myDeviceId: 'b', peer: { deviceId: 'a', lanReachable: true } });
    expect(a.delayMs).toBe(AUTO_CONNECT.initiatorDelayMs);
    expect(b.delayMs).toBe(AUTO_CONNECT.followerDelayMs);
  });

  test('transport preference LAN > P2P > BT, none if nothing reachable', () => {
    const base = { myDeviceId: 'a' };
    expect(planAutoConnect({ ...base, peer: { deviceId: 'b', lanReachable: true, p2pVisible: true } }).transport).toBe('LAN');
    expect(planAutoConnect({ ...base, peer: { deviceId: 'b', p2pVisible: true, btAddress: 'x' } }).transport).toBe('P2P');
    expect(planAutoConnect({ ...base, peer: { deviceId: 'b', btAddress: 'x' } }).transport).toBe('BLUETOOTH');
    expect(planAutoConnect({ ...base, peer: { deviceId: 'b' } })).toBeNull();
  });

  test('exponential backoff after failures', () => {
    expect(backoffFor(0)).toBe(0);
    expect(backoffFor(1)).toBe(AUTO_CONNECT.baseBackoffMs);
    expect(backoffFor(2)).toBe(AUTO_CONNECT.baseBackoffMs * 2);
    expect(backoffFor(20)).toBe(AUTO_CONNECT.maxBackoffMs);
    const now = 1000000;
    const blocked = planAutoConnect({
      myDeviceId: 'a', peer: { deviceId: 'b', lanReachable: true },
      attempt: { failures: 1, lastAt: now - 1000 }, now,
    });
    expect(blocked).toBeNull();
    const allowed = planAutoConnect({
      myDeviceId: 'a', peer: { deviceId: 'b', lanReachable: true },
      attempt: { failures: 1, lastAt: now - AUTO_CONNECT.baseBackoffMs - 1 }, now,
    });
    expect(allowed).not.toBeNull();
  });
});
