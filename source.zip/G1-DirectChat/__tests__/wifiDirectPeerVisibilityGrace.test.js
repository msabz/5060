import fs from 'fs';
import path from 'path';

/**
 * سماحية عرض أجهزة Wi-Fi Direct — بعد توحيد النوافذ انتقلت الآلية من
 * ContactsScreen (المحذوفة) إلى حساب «القريبون» المركزي في App.js،
 * والعرض إلى HomeScreen. العقد ذاته: احتفاظ 6 ثوانٍ، علامة صادقة، بلا وميض.
 */
describe('Wi-Fi Direct transient peer presentation safety (single-window home)', () => {
  const appSource = fs.readFileSync(
    path.join(__dirname, '..', 'src', 'App.js'),
    'utf8'
  );
  const homeSource = fs.readFileSync(
    path.join(__dirname, '..', 'src', 'components', 'HomeScreen.js'),
    'utf8'
  );

  test('retains a missing peer only for a bounded display grace', () => {
    expect(appSource).toContain('const P2P_PEER_DISPLAY_GRACE_MS = 6000;');
    expect(appSource).toContain('p2pDisplayGraceRef');
    // الإبقاء مؤقت: من غاب عن دورة الاكتشاف الحالية يُوسم transientMissing
    expect(appSource).toContain('nowTs - graceCache[a].at >= P2P_PEER_DISPLAY_GRACE_MS');
    expect(appSource).toContain('transientMissing: !liveAddrs.has((x.d.deviceAddress');
    expect(appSource).toContain('transientMissing: d.transientMissing === true');
  });

  test('a retained peer is honestly labelled and never faked as confirmed', () => {
    expect(homeSource).toContain("'شوهد قبل لحظات — جارٍ التحقق'");
    expect(homeSource).toContain('item.transientMissing === true');
    // غير المؤكد يبقى موسوماً — لا يُعرض أبداً كجهاز MusabX مؤكد
    expect(appSource).toContain('unconfirmed: d.isMusab !== true');
    expect(homeSource).toContain("'Wi-Fi Direct · غير مؤكد'");
  });

  test('expiry is single-owner inside the centralized nearby computation', () => {
    // مالك واحد للكاش: المرجع يُمسح مدخلاته المنتهية في نفس الدالة
    expect(appSource).toMatch(
      /Object\.keys\(graceCache\)\.forEach\(a => \{[\s\S]*?delete graceCache\[a\];/
    );
  });
});
