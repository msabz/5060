import { LinkManager, LINK_PRIORITY, linkManager } from '../src/network/LinkManager';

describe('LinkManager (KDE multi-link model)', () => {
  let mgr;
  beforeEach(() => { mgr = new LinkManager(); });

  test('priority order: LAN > P2P > BLUETOOTH', () => {
    expect(LINK_PRIORITY.LAN).toBeGreaterThan(LINK_PRIORITY.P2P);
    expect(LINK_PRIORITY.P2P).toBeGreaterThan(LINK_PRIORITY.BLUETOOTH);
  });

  test('send uses the best live link (KDE links.any)', async () => {
    const sent = [];
    mgr.registerLink('p1', { transport: 'BLUETOOTH', send: async m => { sent.push(['bt', m]); return true; } });
    mgr.registerLink('p1', { transport: 'P2P', send: async m => { sent.push(['p2p', m]); return true; } });
    const used = await mgr.send('p1', { type: 'chat', text: 'مرحبا' });
    expect(used).toBe('P2P');
    expect(sent).toEqual([['p2p', { type: 'chat', text: 'مرحبا' }]]);
  });

  test('falls through to lower link when the best fails (instant fallback)', async () => {
    mgr.registerLink('p1', { transport: 'P2P', send: async () => { throw new Error('dead'); } });
    mgr.registerLink('p1', { transport: 'BLUETOOTH', send: async () => true });
    const used = await mgr.send('p1', { type: 'chat' });
    expect(used).toBe('BLUETOOTH');
  });

  test('silent upgrade: adding a higher link routes the very next message to it', async () => {
    const routes = [];
    mgr.registerLink('p1', { transport: 'BLUETOOTH', send: async () => { routes.push('bt'); return true; } });
    await mgr.send('p1', {});
    mgr.registerLink('p1', { transport: 'LAN', send: async () => { routes.push('lan'); return true; } });
    await mgr.send('p1', {});
    expect(routes).toEqual(['bt', 'lan']);
  });

  test('Briar nonce tie-break: same transport keeps the higher-nonce link', async () => {
    const oldClose = jest.fn();
    mgr.registerLink('p1', { transport: 'P2P', nonce: 5, send: async () => true, close: oldClose });
    const rejected = mgr.registerLink('p1', { transport: 'P2P', nonce: 3, send: async () => true });
    expect(rejected.kept).toBe('existing');
    const accepted = mgr.registerLink('p1', { transport: 'P2P', nonce: 9, send: async () => true });
    expect(accepted.kept).toBe('new');
    expect(oldClose).toHaveBeenCalledWith('superseded');
  });

  test('UI honesty: isReachable mirrors live links exactly', () => {
    expect(mgr.isReachable('p1')).toBe(false);
    mgr.registerLink('p1', { transport: 'BLUETOOTH', send: async () => true });
    expect(mgr.isReachable('p1')).toBe(true);
    mgr.unregisterLink('p1', 'BLUETOOTH');
    expect(mgr.isReachable('p1')).toBe(false);
  });

  test('lowerLinks returns exactly the links an upgrade should retire', () => {
    mgr.registerLink('p1', { transport: 'BLUETOOTH', send: async () => true });
    mgr.registerLink('p1', { transport: 'P2P', send: async () => true });
    mgr.registerLink('p1', { transport: 'LAN', send: async () => true });
    expect(mgr.lowerLinks('p1', 'LAN').map(l => l.transport).sort()).toEqual(['BLUETOOTH', 'P2P']);
    expect(mgr.lowerLinks('p1', 'P2P').map(l => l.transport)).toEqual(['BLUETOOTH']);
    expect(mgr.lowerLinks('p1', 'BLUETOOTH')).toEqual([]);
  });

  test('emits link-up/link-down events', () => {
    const events = [];
    mgr.onChange(e => events.push(e));
    mgr.registerLink('p1', { transport: 'LAN', send: async () => true });
    mgr.unregisterLink('p1', 'LAN', 'socket-closed');
    expect(events).toEqual([
      { type: 'link-up', peerId: 'p1', transport: 'LAN' },
      { type: 'link-down', peerId: 'p1', transport: 'LAN', reason: 'socket-closed' },
    ]);
  });

  test('send returns null with no links; singleton export exists', async () => {
    expect(await mgr.send('ghost', {})).toBeNull();
    expect(linkManager).toBeInstanceOf(LinkManager);
  });
});
