/**
 * حارس سلامة المصدر: لا معرّفات غير معرّفة في أي ملف JSX/JS.
 * صُمم بعد انحدار ميداني: <Avatar> و<TransportChip> استُخدما في ChatScreen
 * دون استيراد — Metro لا يكشف ذلك ولا معظم الاختبارات، والتطبيق انهار
 * بشاشة حمراء عند فتح المحادثة. هذا الاختبار يمسح كل src/ بتحليل نطاق
 * Babel كامل (مثل eslint no-undef) ويفشل عند أي مرجع غير معرّف.
 */
const fs = require('fs');
const path = require('path');
const babel = require('@babel/core');
const traverse = require('@babel/traverse').default;

const GLOBALS = new Set([
  'console', 'setTimeout', 'clearTimeout', 'setInterval', 'clearInterval',
  'setImmediate', 'clearImmediate', 'Promise', 'JSON', 'Math', 'Date', 'Array',
  'Object', 'String', 'Number', 'Boolean', 'Error', 'TypeError', 'RegExp',
  'Map', 'Set', 'WeakMap', 'WeakSet', 'Symbol', 'BigInt', 'Buffer', 'process',
  'global', 'globalThis', '__DEV__', 'fetch', 'XMLHttpRequest', 'WebSocket',
  'FormData', 'Blob', 'FileReader', 'URL', 'URLSearchParams', 'TextEncoder',
  'TextDecoder', 'atob', 'btoa', 'alert', 'navigator', 'requestAnimationFrame',
  'cancelAnimationFrame', 'queueMicrotask', 'AbortController', 'performance',
  'Intl', 'parseInt', 'parseFloat', 'isNaN', 'isFinite', 'encodeURIComponent',
  'decodeURIComponent', 'encodeURI', 'decodeURI', 'require', 'module', 'exports',
  '__dirname', '__filename', 'Uint8Array', 'Uint16Array', 'Uint32Array',
  'Int8Array', 'Int16Array', 'Int32Array', 'Float32Array', 'Float64Array',
  'ArrayBuffer', 'DataView', 'Proxy', 'Reflect', 'structuredClone', 'crypto',
  'Headers', 'Request', 'Response', 'Event', 'EventTarget', 'CustomEvent',
]);

function walk(dir, out = []) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) {
      if (e.name !== '__tests__' && e.name !== 'node_modules') walk(p, out);
    } else if (e.name.endsWith('.js')) out.push(p);
  }
  return out;
}

describe('سلامة المصدر: لا مراجع غير معرّفة', () => {
  const srcRoot = path.join(__dirname, '..', 'src');
  const files = walk(srcRoot);

  test('كل ملفات src تُحلَّل بلا أخطاء بناء', () => {
    for (const file of files) {
      const code = fs.readFileSync(file, 'utf8');
      expect(() =>
        babel.parseSync(code, {
          plugins: ['@babel/plugin-syntax-jsx'],
          filename: file,
          babelrc: false,
          configFile: false,
          sourceType: 'module',
        })
      ).not.toThrow();
    }
  });

  test('لا معرّف غير معرّف في أي ملف (no-undef كامل)', () => {
    const violations = [];
    for (const file of files) {
      const code = fs.readFileSync(file, 'utf8');
      const ast = babel.parseSync(code, {
        plugins: ['@babel/plugin-syntax-jsx'],
        filename: file,
        babelrc: false,
        configFile: false,
        sourceType: 'module',
      });
      traverse(ast, {
        ReferencedIdentifier(p) {
          const name = p.node.name;
          if (GLOBALS.has(name)) return;
          if (p.scope.hasBinding(name) || p.scope.hasGlobal(name)) return;
          if (p.parentPath.isJSXMemberExpression() && p.parentPath.node.property === p.node) return;
          if (p.parentPath.isMemberExpression() && p.parentPath.node.property === p.node && !p.parentPath.node.computed) return;
          violations.push(`${path.relative(srcRoot, file)}:${p.node.loc.start.line} → ${name}`);
        },
      });
    }
    expect(violations).toEqual([]);
  });

  test('كل مكوّنات JSX المستخدمة مستوردة أو معرّفة محلياً', () => {
    const violations = [];
    for (const file of files) {
      const code = fs.readFileSync(file, 'utf8');
      const ast = babel.parseSync(code, {
        plugins: ['@babel/plugin-syntax-jsx'],
        filename: file,
        babelrc: false,
        configFile: false,
        sourceType: 'module',
      });
      traverse(ast, {
        JSXOpeningElement(p) {
          const n = p.node.name;
          let root = null;
          if (n.type === 'JSXIdentifier' && /^[A-Z]/.test(n.name)) root = n;
          else if (n.type === 'JSXMemberExpression' && n.object.type === 'JSXIdentifier') root = n.object;
          if (!root) return;
          if (!p.scope.hasBinding(root.name) && !p.scope.hasGlobal(root.name)) {
            violations.push(`${path.relative(srcRoot, file)}:${root.loc.start.line} → <${root.name}>`);
          }
        },
      });
    }
    expect(violations).toEqual([]);
  });
});
