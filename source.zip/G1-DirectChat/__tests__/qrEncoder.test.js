/**
 * يثبت أن رمز QR المعروض قابل للقراءة فعلاً: نفكّ ترميز مخرجات المشفّر
 * (إزالة القناع، فصل الكتل المتشابكة، قراءة وضع البايت) ونقارن بالنص الأصلي.
 */
const { encodeQR } = require('../src/utils/qr');

const EC_CW_M = [0, 10, 16, 26, 36, 48, 64, 72, 88, 110, 130];
const EC_BL_M = [0, 1, 1, 1, 2, 2, 4, 4, 4, 5, 5];
const TOTAL = [0, 26, 44, 70, 100, 134, 172, 196, 242, 292, 346];
const ALIGN = [[], [], [6, 18], [6, 22], [6, 26], [6, 30], [6, 34]];

function decodeQR(m) {
  const size = m.length;
  const v = (size - 17) / 4;
  const res = Array.from({ length: size }, () => new Array(size).fill(false));
  const mark = (r, c) => { if (r >= 0 && c >= 0 && r < size && c < size) res[r][c] = true; };
  const finder = (r, c) => { for (let i = -1; i <= 7; i++) for (let j = -1; j <= 7; j++) mark(r + i, c + j); };
  finder(0, 0); finder(0, size - 7); finder(size - 7, 0);
  for (let i = 0; i < size; i++) { mark(6, i); mark(i, 6); }
  for (const r of ALIGN[v] || []) for (const c of ALIGN[v] || []) {
    let overlap = false;
    for (const [fr, fc] of [[0, 0], [0, size - 7], [size - 7, 0]]) {
      if (Math.abs(r - (fr + 3)) <= 4 && Math.abs(c - (fc + 3)) <= 4) overlap = true;
    }
    if (overlap) continue;
    for (let i = -2; i <= 2; i++) for (let j = -2; j <= 2; j++) mark(r + i, c + j);
  }
  for (let i = 0; i < 9; i++) { mark(8, i); mark(i, 8); }
  for (let i = size - 8; i < size; i++) { mark(8, i); mark(i, 8); }

  const bits = [];
  for (let col = size - 1; col > 0; col -= 2) {
    if (col === 6) col--;
    for (let k = 0; k < size; k++) {
      const row = (((size - 1 - col) >> 1) % 2 === 0) ? size - 1 - k : k;
      for (const c of [col, col - 1]) {
        if (res[row][c]) continue;
        let bit = m[row][c] ? 1 : 0;
        if ((row + c) % 2 === 0) bit ^= 1; // إزالة القناع 0
        bits.push(bit);
      }
    }
  }
  const stream = [];
  for (let i = 0; i + 8 <= bits.length; i += 8) stream.push(parseInt(bits.slice(i, i + 8).join(''), 2));

  const dataCw = TOTAL[v] - EC_CW_M[v];
  const nb = EC_BL_M[v];
  const shortLen = Math.floor(dataCw / nb);
  const longCount = dataCw % nb;
  const lens = [];
  for (let b = 0; b < nb; b++) lens.push(shortLen + (b >= nb - longCount ? 1 : 0));
  const blocks = lens.map(() => []);
  let idx = 0;
  const maxD = Math.max(...lens);
  for (let i = 0; i < maxD; i++) for (let b = 0; b < nb; b++) if (i < lens[b]) blocks[b].push(stream[idx++]);
  const data = [].concat(...blocks);

  const db = [];
  data.forEach(byte => { for (let i = 7; i >= 0; i--) db.push((byte >> i) & 1); });
  const lenBits = v <= 9 ? 8 : 16;
  const len = parseInt(db.slice(4, 4 + lenBits).join(''), 2);
  const out = [];
  let p = 4 + lenBits;
  for (let i = 0; i < len; i++) { out.push(parseInt(db.slice(p, p + 8).join(''), 2)); p += 8; }
  return Buffer.from(out).toString('utf8');
}

describe('QR encoder produces a readable code', () => {
  const samples = [
    'HELLO',
    'musabx://add?n=123456789012&id=ABCD-EFGH-IJKL',
    'musabx://add?n=000111222333&id=ZZZZ-YYYY-XXXX-WWWW-VVVV-UUUU',
  ];
  test.each(samples)('round-trips %s', text => {
    expect(decodeQR(encodeQR(text))).toBe(text);
  });

  test('matrix is square with quiet-zone-free odd size', () => {
    const m = encodeQR('musabx://add?n=123456789012&id=X');
    expect(m.length).toBe(m[0].length);
    expect((m.length - 17) % 4).toBe(0);
  });
});
