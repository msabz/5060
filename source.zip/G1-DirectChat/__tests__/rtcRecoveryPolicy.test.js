const { decideRecovery, createRecoveryState, RECOVERY_DEFAULTS } = require('../src/media/rtcRecoveryPolicy');

describe('rtcRecoveryPolicy', () => {
  test('ignores transitions before the call is settled', () => {
    const state = createRecoveryState();
    expect(decideRecovery({ iceState: 'failed', settled: false, isCaller: true, state }))
      .toEqual({ action: 'none' });
    expect(state.restarts).toBe(0);
  });

  test('disconnected after settled waits a grace period once', () => {
    const state = createRecoveryState();
    expect(decideRecovery({ iceState: 'disconnected', settled: true, isCaller: true, state }))
      .toEqual({ action: 'wait', delayMs: RECOVERY_DEFAULTS.disconnectedGraceMs });
    expect(decideRecovery({ iceState: 'disconnected', settled: true, isCaller: true, state }))
      .toEqual({ action: 'none' });
  });

  test('caller restarts ICE, callee requests restart', () => {
    const caller = createRecoveryState();
    expect(decideRecovery({ iceState: 'failed', settled: true, isCaller: true, state: caller }).action)
      .toBe('restart');
    const callee = createRecoveryState();
    expect(decideRecovery({ iceState: 'failed', settled: true, isCaller: false, state: callee }).action)
      .toBe('request-restart');
  });

  test('gives up after maxRestarts and reports recovery on reconnect', () => {
    const state = createRecoveryState();
    for (let i = 0; i < RECOVERY_DEFAULTS.maxRestarts; i++) {
      expect(decideRecovery({ iceState: 'grace-expired', settled: true, isCaller: true, state }).action)
        .toBe('restart');
    }
    expect(decideRecovery({ iceState: 'failed', settled: true, isCaller: true, state }).action)
      .toBe('give-up');

    const recovering = createRecoveryState();
    decideRecovery({ iceState: 'failed', settled: true, isCaller: true, state: recovering });
    expect(decideRecovery({ iceState: 'connected', settled: true, isCaller: true, state: recovering }).action)
      .toBe('recovered');
    expect(recovering.phase).toBe('stable');
    expect(recovering.restarts).toBe(0);
  });

  test('closed is terminal', () => {
    const state = createRecoveryState();
    expect(decideRecovery({ iceState: 'closed', settled: true, isCaller: true, state }).action).toBe('give-up');
  });
});
