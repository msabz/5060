import fs from 'fs';
import path from 'path';
import { diag, diagEntries, diagExport, diagClear } from '../src/utils/diagLog';

/**
 * جولة الإصلاح الميداني: لا فشل صامت بعد الآن —
 * سجل تشخيص داخل التطبيق + بانر حالة مرئي + فلترة أجهزة Wi-Fi Direct
 * غير الهاتفية + بحث Bluetooth من النافذة الواحدة + إذن كاميرا عند مسح QR.
 */

const appSource = fs.readFileSync(path.join(__dirname, '..', 'src', 'App.js'), 'utf8');
const homeSource = fs.readFileSync(path.join(__dirname, '..', 'src', 'components', 'HomeScreen.js'), 'utf8');
const nativeP2p = fs.readFileSync(
  path.join(__dirname, '..', 'android', 'app', 'src', 'main', 'java', 'com', 'm200', 'directconnection', 'DirectConnectionModule.kt'),
  'utf8'
);

describe('diagLog ring buffer', () => {
  test('stores timestamped entries, caps at 500, exports shareable text', () => {
    diagClear();
    diag('BT', 'اختبار أول', { a: 1 });
    diag('P2P', 'اختبار ثانٍ');
    const entries = diagEntries();
    expect(entries.length).toBe(2);
    expect(entries[0].tag).toBe('BT');
    expect(entries[0].data).toBe('{"a":1}');
    expect(typeof entries[0].at).toBe('number');

    for (let i = 0; i < 600; i += 1) diag('APP', `رقم ${i}`);
    expect(diagEntries().length).toBe(500);

    const text = diagExport();
    expect(text).toContain('[APP] رقم 599');
    expect(text).not.toContain('اختبار أول');
    diagClear();
    expect(diagEntries().length).toBe(0);
  });
});

describe('field diagnostics wiring', () => {
  test('App logs every critical transport event and failure', () => {
    expect(appSource).toContain("import { diag } from './utils/diagLog'");
    expect(appSource).toContain('bluetoothTransport.subscribe(evt => {');
    expect(appSource).toContain("diag('BT', 'مستمع RFCOMM (insecure) يعمل");
    expect(appSource).toContain("diag('BT', 'أذونات Bluetooth مرفوضة");
    expect(appSource).toContain("diag('ERR', `فشل اتصال Bluetooth:");
    expect(appSource).toContain("diag('ERR', `فشل تفاوض Wi-Fi Direct:");
    expect(appSource).toContain("diag('ERR', `فشل connectToContact(");
    expect(appSource).toContain("diag('ERR', 'فشل إرسال رسالة: لا قناة حية");
  });

  test('diagnostics screen is reachable from the unified home overflow menu', () => {
    expect(appSource).toContain("import DiagnosticsScreen from './components/DiagnosticsScreen'");
    expect(appSource).toContain('onOpenDiag={() => setShowDiag(true)}');
    expect(appSource).toContain('<DiagnosticsScreen onClose={() => setShowDiag(false)} />');
    expect(homeSource).toContain('سجل التشخيص');
  });

  test('status banner is visible on the unified home screen', () => {
    expect(appSource).toContain('banner={statusText}');
    expect(homeSource).toContain('{!!banner && (');
    expect(homeSource).toContain('s.bannerText');
  });

  test('Bluetooth classic scan is exposed inside the single-window add sheet', () => {
    expect(appSource).toContain('onBtScan={btScan}');
    expect(homeSource).toContain("setAddMode('bluetooth'); onBtScan?.();");
    expect(homeSource).toContain("addMode === 'bluetooth'");
    expect(homeSource).toContain('أجهزة Bluetooth القريبة');
    expect(homeSource).toContain('onBtConnect?.(d.address)');
  });

  test('QR scanner requests camera permission at scan time', () => {
    const start = appSource.indexOf('const openQrScanner = async');
    const end = appSource.indexOf('const addContactByCode', start);
    const body = appSource.slice(start, end);
    expect(body).toContain('PermissionsAndroid.PERMISSIONS.CAMERA');
    expect(body.indexOf('PERMISSIONS.CAMERA')).toBeLessThan(body.indexOf('scanner.scan('));
  });

  test('non-phone unconfirmed Wi-Fi Direct devices (TVs) are hidden from nearby', () => {
    expect(nativeP2p).toContain('putString("primaryDeviceType", dev.primaryDeviceType)');
    expect(nativeP2p).toContain('putString("primaryDeviceType", device.primaryDeviceType)');
    expect(appSource).toContain("t.startsWith('10-')");
    expect(appSource).toContain('أُخفي جهاز غير مؤكد غير هاتفي');
    // الحقول تُحمى عبر handlePeers و MUSAB_PEER_FOUND كليهما
    expect(appSource).toContain('primaryDeviceType: p.primaryDeviceType || known.primaryDeviceType || null');
    expect(appSource).toContain('primaryDeviceType: d.primaryDeviceType || existing.primaryDeviceType || null');
  });

  test('IP connect row exists in the single-window add sheet', () => {
    expect(homeSource).toContain("setAddMode('ip')");
    expect(homeSource).toContain("addMode === 'ip'");
    expect(homeSource).toContain('اتصال عبر IP');
    expect(homeSource).toContain('onConnectLan?.(ip.trim())');
  });
});
