/**
 * انحدار حرج: عطل ميداني «Transport fallback engine is not configured».
 *
 * الجذر كان أن singleton المنسّق يُنشأ بلا محرك، وأن المحرك المشترك لم يكن
 * يُستورَد إلا من مكوّن تشخيصي غير مُستخدم — فلم تُنفَّذ وحدته إطلاقاً في
 * حزمة الإنتاج، وبقي fallbackEngine === null وكل connectPeer يرفض فوراً.
 *
 * هذه الاختبارات تمنع عودة العطل من بابين: لحام صريح في App.js + التحام
 * كسول ذاتي داخل connectPeer.
 */
import fs from 'fs';
import path from 'path';

jest.mock('react-native-tcp-socket', () => ({
  createServer: jest.fn(),
  createConnection: jest.fn(),
}));

const appSource = fs.readFileSync(path.join(__dirname, '../src/App.js'), 'utf8');
const coordinatorSource = fs.readFileSync(
  path.join(__dirname, '../src/network/ConnectionCoordinator.js'),
  'utf8',
);

describe('fallback engine wiring (field regression)', () => {
  test('App.js imports the shared engine and attaches it to the coordinator', () => {
    expect(appSource).toContain("from './network/TransportFallbackEngine'");
    expect(appSource).toContain('connectionCoordinator.setFallbackEngine(fallbackEngine)');
  });

  test('connectPeer lazily self-heals the shared engine', () => {
    expect(coordinatorSource).toContain("require('./TransportFallbackEngine')");
  });

  test('coordinator.connectPeer never rejects with "not configured" again', async () => {
    // بيئة معزولة لكل ملف اختبار: نفصل المحرك يدوياً ثم نتحقق أن أول
    // connectPeer يلحم المحرك المشترك تلقائياً ويصل إلى مرحلة الاستنفاد
    // (خطة فارغة) بدل رفض «غير مُهيأ».
    const { connectionCoordinator } = require('../src/network/ConnectionCoordinator');
    const {
      TransportFallbackExhaustedError,
    } = require('../src/network/TransportFallbackEngine');

    connectionCoordinator.setFallbackEngine(null);
    expect(connectionCoordinator.fallbackEngine).toBeNull();

    await expect(
      connectionCoordinator.connectPeer({ deviceId: 'peer-x', transports: {} }),
    ).rejects.toThrow(TransportFallbackExhaustedError);
    expect(connectionCoordinator.fallbackEngine).toBeTruthy();
  });
});
