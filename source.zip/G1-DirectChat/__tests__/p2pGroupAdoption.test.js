/**
 * انحدار «المهلة الزومبي تقتل مجموعة حية» — العطل الميداني الموثّق:
 * الطرف الآخر كوّن المجموعة قبل محاولتنا، فلم يصلنا بثّ PEER_CONNECTED،
 * وعلقت المحاولة 30 ث ثم هدم مؤقّتها المجموعة والجلسة الشغّالة فوقها.
 *
 * الإصلاح على مستويين وكلاهما مختبَر هنا:
 * 1) تبنّي المجموعة القائمة فوراً عبر getConnectionInfo + requestPeers.
 * 2) مؤقّت المهلة لا ينظّف مجموعةً يقول فاحص المسار إنها مستخدمة.
 */
import { WifiDirectTransportAdapter } from '../src/network/WifiDirectTransportAdapter';

jest.mock('react-native', () => ({
  NativeModules: {},
  NativeEventEmitter: jest.fn(),
}));

const PEER = {
  deviceId: 'peer-stable-id',
  deviceName: 'SM-A165F',
  transports: { P2P: { deviceAddress: 'AA:BB:CC:DD:EE:FF', isReachable: true } },
};

function makeNative({ groupFormed = true, peerStatus = 0 } = {}) {
  return {
    connectToPeer: jest.fn(async () => ({ started: true, connectionEpoch: 7 })),
    getConnectionInfo: jest.fn(async () => ({
      groupFormed,
      isGroupOwner: false,
      groupOwnerAddress: '192.168.49.1',
      interfaceName: 'p2p0',
    })),
    requestPeers: jest.fn(async () => ({
      peers: [{ deviceAddress: 'aa:bb:cc:dd:ee:ff', status: peerStatus, deviceName: 'SM-A165F' }],
    })),
    bindToWifiDirectNetwork: jest.fn(async () => true),
    stopServiceDiscovery: jest.fn(async () => true),
    unbindNetwork: jest.fn(async () => true),
    cancelConnect: jest.fn(async () => true),
    disconnect: jest.fn(async () => true),
  };
}

const fakeEmitter = { addListener: jest.fn(() => ({ remove: jest.fn() })) };

describe('P2P pre-existing group adoption (field regression)', () => {
  test('adopts an already-formed group instead of hanging until timeout', async () => {
    const native = makeNative();
    const adapter = new WifiDirectTransportAdapter({
      nativeModule: native, emitter: fakeEmitter, connectTimeoutMs: 60000,
    });
    const route = await adapter.connectPeer(PEER, { timeoutMs: 60000 });
    expect(route?.groupOwnerAddress).toBe('192.168.49.1');
    expect(native.requestPeers).toHaveBeenCalled();
    // لم ننتظر بثّاً ولن يبقى مؤقّت زومبي
    expect(adapter.getStatus().state).toBe('READY');
    expect(adapter.getStatus().pendingPeerId).toBeNull();
  });

  test('does NOT adopt a group formed with a different peer', async () => {
    const native = makeNative({ peerStatus: 3 }); // AVAILABLE فقط — ليس في مجموعتنا
    const adapter = new WifiDirectTransportAdapter({
      nativeModule: native, emitter: fakeEmitter, connectTimeoutMs: 120,
    });
    await expect(adapter.connectPeer(PEER, { timeoutMs: 120 }))
      .rejects.toThrow(/timed out/);
  });

  test('timeout never cleans up a group the route-checker says is in use', async () => {
    const native = makeNative({ groupFormed: false, peerStatus: 3 });
    const adapter = new WifiDirectTransportAdapter({
      nativeModule: native, emitter: fakeEmitter, connectTimeoutMs: 100,
    });
    adapter.setRouteInUseChecker(() => true);
    const cleanupSpy = jest.spyOn(adapter, '_cleanupNativeRoute').mockResolvedValue({ clean: true });
    await expect(adapter.connectPeer(PEER, { timeoutMs: 100 })).rejects.toThrow(/timed out/);
    expect(cleanupSpy).not.toHaveBeenCalled();
  });

  test('timeout still cleans up an unused group (no regression)', async () => {
    const native = makeNative({ groupFormed: false, peerStatus: 3 });
    const adapter = new WifiDirectTransportAdapter({
      nativeModule: native, emitter: fakeEmitter, connectTimeoutMs: 100,
    });
    adapter.setRouteInUseChecker(() => false);
    const cleanupSpy = jest.spyOn(adapter, '_cleanupNativeRoute').mockResolvedValue({ clean: true });
    await expect(adapter.connectPeer(PEER, { timeoutMs: 100 })).rejects.toThrow(/timed out/);
    expect(cleanupSpy).toHaveBeenCalled();
  });
});

describe('session-alive guard in beginWifiNegotiation', () => {
  const fs = require('fs');
  const path = require('path');
  const appSource = fs.readFileSync(path.join(__dirname, '../src/App.js'), 'utf8');
  const indexSource = fs.readFileSync(path.join(__dirname, '../index.js'), 'utf8');

  test('a late failure never tears down a session that is actually alive', () => {
    expect(appSource).toContain('sessionActuallyAlive');
    expect(appSource).toContain('فشل متأخر والجلسة قائمة فعلاً — تجاهل بلا هدم');
  });

  test('index.js wires the route-in-use checker', () => {
    expect(indexSource).toContain('setRouteInUseChecker');
    expect(indexSource).toContain('getTransports(pid).includes(TRANSPORTS.P2P)');
  });
});
