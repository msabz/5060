/**
 * جاهزية طبقة I2P المستقبلية (بدون أي اعتمادية أصلية جديدة):
 * - I2P ناقل درجة أولى في السجل، ووجهته هوية مستقرة (ليست مؤقتة أبداً).
 * - رسائل الهوية تستقبل `i2p` وتُعلنه عند ضبطه — نقطة حقن واحدة للراوتر القادم.
 * - قاعدة البيانات تحفظ الوجهة في عمود مستقل (لا تطمس عناوين P2P/BT).
 * - الواجهة تملك وسماً عربياً جاهزاً للناقل.
 */
import fs from 'fs';
import path from 'path';
import { PeerRegistry, TRANSPORTS, isProvisionalPeerId } from '../src/network/PeerRegistry';

const read = rel => fs.readFileSync(path.join(__dirname, '..', rel), 'utf8');

describe('I2P transport readiness', () => {
  test('TRANSPORTS exposes I2P and the registry tracks its generation', () => {
    expect(TRANSPORTS.I2P).toBe('I2P');
    const registry = new PeerRegistry({ myDeviceId: 'me' });
    expect(registry.getTransportGeneration(TRANSPORTS.I2P)).toBe(0);
  });

  test('an I2P destination is a STABLE identity, never provisional (no rekey)', () => {
    const dest = `i2p:${'a'.repeat(52)}.b32.i2p`;
    expect(isProvisionalPeerId(dest)).toBe(false);
    expect(isProvisionalPeerId('p2p:aa:bb:cc:dd:ee:ff')).toBe(true);
    expect(isProvisionalPeerId('bt:aa:bb:cc:dd:ee:ff')).toBe(true);
  });

  test('upsertI2pPeer stores the destination and rejects blanks', () => {
    const registry = new PeerRegistry({ myDeviceId: 'me' });
    expect(registry.upsertI2pPeer({ deviceId: 'peer-1', destination: '' })).toBeNull();
    const peer = registry.upsertI2pPeer({
      deviceId: 'peer-1', deviceName: 'رفيق', destination: 'DEST~base64', isOnline: true,
    });
    expect(peer.transports[TRANSPORTS.I2P].destination).toBe('DEST~base64');
    expect(peer.transports[TRANSPORTS.I2P].isReachable).toBe(true);
    expect(registry.upsertI2pPeer({ deviceId: 'me', destination: 'x' })).toBeNull();
  });

  test('identity announcements carry i2p only after setOwnI2pDestination (single seam)', () => {
    const src = read('src/services/IdentityVerifier.js');
    expect(src).toContain('export function setOwnI2pDestination');
    expect(src).toContain('...(myI2pDestination ? { i2p: myI2pDestination } : {})');
  });

  test('both identity handlers (signaling + bluetooth) learn the i2p destination', () => {
    const src = read('src/App.js');
    expect(src).toContain('learnPeerI2pDestination(msg.deviceId, msg.i2p)');
    expect(src).toContain('learnPeerI2pDestination(stableDeviceId, message.i2p)');
    // حماية: لا تخزين لوجهة تحت معرّف مؤقت (p2p:/bt:)
    expect(src).toMatch(/learnPeerI2pDestination[\s\S]*?isProvisionalPeerId\(ownerId\)/);
  });

  test('database persists i2p_destination in its own column (v7 migration)', () => {
    const src = read('android/app/src/main/java/com/m200/service/StorageModule.kt');
    expect(src).toMatch(/SQLiteOpenHelper\(context, "musabchat\.db", null, 7\)/);
    expect(src).toMatch(/oldVersion < 7[\s\S]*?addColumnIfMissing\(db, "peers", "i2p_destination", "TEXT"\)/);
    expect(src).toContain('i2p_destination TEXT');
    expect(src).toContain('fun savePeerI2pDestination(');
    expect(src).toContain('putString("i2pDestination"');
  });

  test('nearby UI already has an Arabic I2P label', () => {
    const src = read('src/components/HomeScreen.js');
    expect(src).toContain('عبر I2P (مجهول)');
  });
});
