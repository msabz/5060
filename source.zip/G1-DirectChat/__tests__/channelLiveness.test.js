/**
 * جولة «لا قناة زومبي» — انحدارات للأعطال الميدانية الموثقة بالسجلات:
 * 1) «لا قناة حية» تحت ترويسة «متصل»: روابط ميتة بقيت مسجلة لأن فشل الكتابة
 *    لم يكن يُزيلها. الآن كل كتابة فاشلة تحيل الرابط فوراً (link-down).
 * 2) تعليق «جاري إنهاء اتصال Wi-Fi Direct» بلا نهاية: صمّام أمان 20 ث.
 * 3) الترويسة تُشتق من حياة الروابط لا من حالة الجلسة وحدها.
 * 4) انتظار نبضة 18 ث قبل كشف موت القناة: فشل الإرسال الكلي يفتح مسار
 *    الإنهاء-وإعادة-الاتصال قسراً (force).
 */
import fs from 'fs';
import path from 'path';
import { LinkManager } from '../src/network/LinkManager';

const appSource = fs.readFileSync(path.join(__dirname, '../src/App.js'), 'utf8');
const chatSource = fs.readFileSync(
  path.join(__dirname, '../src/components/ChatScreen.js'),
  'utf8',
);
const coordinatorSource = fs.readFileSync(
  path.join(__dirname, '../src/network/ConnectionCoordinator.js'),
  'utf8',
);
const adapterSource = fs.readFileSync(
  path.join(__dirname, '../src/network/WifiDirectTransportAdapter.js'),
  'utf8',
);

describe('LinkManager zombie-link pruning (field regression)', () => {
  test('a failed write retires the link and emits link-down (send-failed)', async () => {
    const mgr = new LinkManager();
    const events = [];
    mgr.onChange(evt => events.push(evt));
    mgr.registerLink('p1', { transport: 'LAN', send: async () => false });
    mgr.registerLink('p1', { transport: 'BLUETOOTH', send: async () => true });

    const used = await mgr.send('p1', { type: 'chat', text: 'x' });
    expect(used).toBe('BLUETOOTH');
    // الرابط الميت أُزيل: الواجهة الصادقة لم يعد يخدعها
    expect(mgr.getTransports('p1')).toEqual(['BLUETOOTH']);
    expect(events).toContainEqual(
      expect.objectContaining({ type: 'link-down', transport: 'LAN', reason: 'send-failed' }),
    );
  });

  test('when every link dies, isReachable becomes false (no fake متصل)', async () => {
    const mgr = new LinkManager();
    mgr.registerLink('p1', { transport: 'LAN', send: async () => { throw new Error('dead'); } });
    const used = await mgr.send('p1', { type: 'chat' });
    expect(used).toBeNull();
    expect(mgr.isReachable('p1')).toBe(false);
  });
});

describe('honest chat header + forced recovery wiring', () => {
  test('App derives header liveness from the link engine, not state alone', () => {
    expect(appSource).toContain('isActivePeerLive');
    expect(appSource).toContain('peerLive={isActivePeerLive()}');
    expect(chatSource).toContain('peerLive = true');
    expect(chatSource).toContain('انقطع — يعيد الاتصال…');
  });

  test('total channel failure forces terminal recovery without the 18s heartbeat wait', () => {
    expect(appSource).toContain('handleTerminalSignalingDisconnect({ force: true })');
    expect(appSource).toContain('if (!force && signalingIsHealthy()) return;');
  });

  test('disconnect paths carry a 20s hard watchdog (no infinite DISCONNECTING)', () => {
    expect(appSource).toContain('armDisconnectWatchdog');
    expect(appSource).toContain('cleanup-js-timeout');
    expect(appSource.match(/clearTimeout\(watchdog\)/g).length).toBeGreaterThanOrEqual(3);
  });

  test('P2P negotiation stages are diagnosable from the field log', () => {
    expect(coordinatorSource).toContain('بانتظار الطرف الآخر على :');
    expect(coordinatorSource).toContain('اتصال بمقبس المالك');
    expect(adapterSource).toContain('بانتظار تكوين المجموعة');
    expect(adapterSource).toContain('جارٍ تفعيل المسار');
  });
});
