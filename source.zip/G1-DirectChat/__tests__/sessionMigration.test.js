const {
  createSequencer, createAttachClient, createAttachServer, isMigrationInitiator, sessionIdFor, MIGRATION,
} = require('../src/webrtc/sessionMigration');

describe('sessionMigration', () => {
  test('initiator is the lexicographically smaller id; sid is deterministic', () => {
    expect(isMigrationInitiator('a', 'b')).toBe(true);
    expect(isMigrationInitiator('b', 'a')).toBe(false);
    expect(sessionIdFor('b', 'a')).toBe(sessionIdFor('a', 'b'));
  });

  test('sequencer stamps app messages, skips control, dedups and replays', () => {
    const s = createSequencer();
    expect(s.stamp({ type: 'ping' }).seq).toBeUndefined();
    // identity و my-ip تُعاد تلقائياً على كل socket جديد فلا تُرقَّم
    expect(s.stamp({ type: 'identity', deviceId: 'x' }).seq).toBeUndefined();
    expect(s.stamp({ type: 'my-ip', ip: '1.2.3.4' }).seq).toBeUndefined();
    const m1 = s.stamp({ type: 'chat', text: 'a' });
    const m2 = s.stamp({ type: 'chat', text: 'b' });
    expect([m1.seq, m2.seq]).toEqual([1, 2]);
    expect(s.accept({ seq: 1 })).toBe('accept');
    expect(s.accept({ seq: 1 })).toBe('duplicate');
    expect(s.accept({ type: 'chat' })).toBe('accept'); // legacy without seq
    expect(s.pendingAfter(1).map(m => m.seq)).toEqual([2]);
    s.ackedUpTo(2);
    expect(s.pendingAfter(0)).toEqual([]);
  });

  test('replay buffer is bounded', () => {
    const s = createSequencer();
    for (let i = 0; i < MIGRATION.replayBufferSize + 10; i++) s.stamp({ type: 'chat' });
    expect(s.replay.length).toBe(MIGRATION.replayBufferSize);
  });

  test('attach handshake: challenge, proof, ack with echo', async () => {
    const client = createAttachClient({ sid: 'a|b', deviceId: 'a', lastSeq: 5, nonce: 'n1' });
    const server = createAttachServer({
      expectedSid: 'a|b', expectedDeviceId: 'a', myLastSeq: () => 7,
      makeNonce: () => 'srv', verify: async (id, pub, nonce, sig) => sig === `sig(${nonce})`,
    });
    const hello = client.hello();
    const challenge = await server.onMessage(hello);
    expect(challenge.type).toBe('attach-challenge');
    expect(client.onMessage(challenge)).toBe('challenge');
    const ack = await server.onMessage({ type: 'attach-proof', sig: 'sig(srv)', pubKey: 'pk' });
    expect(ack).toEqual({ type: 'attach-ack', lastSeq: 7, echo: 'n1' });
    expect(client.onMessage(ack)).toBe('ack');
    expect(client.state.peerLastSeq).toBe(7);
  });

  test('attach rejected for unknown session or bad proof', async () => {
    const server = createAttachServer({
      expectedSid: 'a|b', expectedDeviceId: 'a', myLastSeq: () => 0,
      makeNonce: () => 'srv', verify: async () => false,
    });
    expect((await server.onMessage({ type: 'session-attach', sid: 'x', deviceId: 'a', nonce: 'n' })).type).toBe('attach-reject');
    const s2 = createAttachServer({ expectedSid: 'a|b', expectedDeviceId: 'a', myLastSeq: () => 0, makeNonce: () => 'srv', verify: async () => false });
    await s2.onMessage({ type: 'session-attach', sid: 'a|b', deviceId: 'a', nonce: 'n' });
    expect((await s2.onMessage({ type: 'attach-proof', sig: 'bad' })).type).toBe('attach-reject');
  });
});
