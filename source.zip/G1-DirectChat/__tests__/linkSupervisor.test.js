/**
 * اختبارات مشرف المسار: قاعدة المُبادِر-فقط، الترقية بعد الاستقرار، الهبوط
 * بعد سماح الغياب، حماية المكالمات والنقل، والتراجع الأسّي بعد الفشل.
 */
const { createLinkSupervisor, LINK_SUPERVISOR_DEFAULTS } = require('../src/network/LinkSupervisor');

const MY_ID = 'device-a';      // أصغر معجمياً → مُبادِر
const PEER_ID = 'device-b';

function makeSupervisor(nowRef, overrides = {}) {
  return createLinkSupervisor({ now: () => nowRef.t, ...overrides });
}

function snap(overrides = {}) {
  return {
    myDeviceId: MY_ID,
    peerId: PEER_ID,
    currentTransport: 'P2P',
    pathHealthy: true,
    lanReachable: false,
    p2pReachable: true,
    p2pHost: '192.168.49.1',
    inCall: false,
    transferActive: false,
    ...overrides,
  };
}

describe('LinkSupervisor policy', () => {
  test('non-initiator never migrates', () => {
    const nowRef = { t: 100000 };
    const sup = makeSupervisor(nowRef);
    const d = sup.evaluate(snap({ myDeviceId: 'zzz-larger', lanReachable: true, lanHost: '10.0.0.5' }));
    expect(d.action).toBe('none');
    expect(d.reason).toBe('not-initiator');
  });

  test('upgrade to LAN only after the stability window', () => {
    const nowRef = { t: 100000 };
    const sup = makeSupervisor(nowRef);
    const s = snap({ lanReachable: true, lanHost: '10.0.0.5', lanPort: 8089 });

    // أول لقطة: LAN ظهر للتو — انتظر الاستقرار
    let d = sup.evaluate(s);
    expect(d.action).toBe('none');
    expect(d.reason).toBe('awaiting-lan-stability');

    // بعد نافذة الاستقرار: ترقية
    nowRef.t += LINK_SUPERVISOR_DEFAULTS.upgradeStableMs + 100;
    d = sup.evaluate(s);
    expect(d).toMatchObject({ action: 'migrate', target: 'LAN', host: '10.0.0.5', reason: 'upgrade-to-lan' });
  });

  test('LAN appearing briefly (flap) does not trigger upgrade', () => {
    const nowRef = { t: 100000 };
    const sup = makeSupervisor(nowRef);
    sup.evaluate(snap({ lanReachable: true, lanHost: '10.0.0.5' }));
    nowRef.t += 1000;
    sup.evaluate(snap({ lanReachable: false })); // اختفى — يُعاد ضبط المؤقت
    nowRef.t += LINK_SUPERVISOR_DEFAULTS.upgradeStableMs + 5000;
    const d = sup.evaluate(snap({ lanReachable: true, lanHost: '10.0.0.5' }));
    expect(d.action).toBe('none');
  });

  test('downgrade to P2P after LAN is lost beyond grace, only when a P2P route exists', () => {
    const nowRef = { t: 100000 };
    const sup = makeSupervisor(nowRef);
    const onLan = snap({ currentTransport: 'LAN', lanReachable: true, lanHost: '10.0.0.5' });
    sup.evaluate(onLan);

    // LAN اختفى لكن ضمن سماح الغياب — لا هبوط بعد
    const lost = snap({ currentTransport: 'LAN', lanReachable: false });
    expect(sup.evaluate(lost).reason).toBe('lan-holding');

    nowRef.t += LINK_SUPERVISOR_DEFAULTS.downgradeGraceMs + 100;
    const d = sup.evaluate(lost);
    expect(d).toMatchObject({ action: 'migrate', target: 'P2P', host: '192.168.49.1', reason: 'lan-lost' });
  });

  test('sick LAN path migrates immediately without waiting the full grace', () => {
    const nowRef = { t: 100000 };
    const sup = makeSupervisor(nowRef);
    const d = sup.evaluate(snap({ currentTransport: 'LAN', lanReachable: true, pathHealthy: false }));
    expect(d).toMatchObject({ action: 'migrate', target: 'P2P', reason: 'lan-path-sick' });
  });

  test('no seamless downgrade when no P2P route is known (fallback engine owns the drop)', () => {
    const nowRef = { t: 100000 };
    const sup = makeSupervisor(nowRef);
    const d = sup.evaluate(snap({ currentTransport: 'LAN', lanReachable: false, p2pReachable: false, p2pHost: null }));
    expect(d.action).toBe('none');
    expect(d.reason).not.toBe('migrate');
  });

  test('active call blocks upgrade while path is healthy but allows escape when sick', () => {
    const nowRef = { t: 100000 };
    const sup = makeSupervisor(nowRef);
    const callSnap = snap({ lanReachable: true, lanHost: '10.0.0.5', inCall: true });
    sup.evaluate(callSnap); // يبدأ عدّاد الاستقرار
    nowRef.t += LINK_SUPERVISOR_DEFAULTS.upgradeStableMs + 100;
    expect(sup.evaluate(callSnap).reason).toBe('busy-protected');

    // المسار مرض أثناء المكالمة: الهروب مسموح رغم المكالمة
    const d = sup.evaluate({ ...callSnap, pathHealthy: false });
    expect(d.action).toBe('migrate');
  });

  test('failure backoff is exponential and success cools down further decisions', () => {
    const nowRef = { t: 100000 };
    const sup = makeSupervisor(nowRef);
    const s = snap({ lanReachable: true, lanHost: '10.0.0.5' });

    sup.evaluate(s); // يبدأ عدّاد الاستقرار
    nowRef.t += LINK_SUPERVISOR_DEFAULTS.upgradeStableMs + 100;
    expect(sup.evaluate(s).action).toBe('migrate');

    sup.markPending();
    expect(sup.evaluate(s).reason).toBe('migration-in-flight');

    sup.recordFailure();
    expect(sup.evaluate(s).reason).toBe('backoff');
    nowRef.t += 1100; // تجاوز أول backoff (1 ث)
    nowRef.t += LINK_SUPERVISOR_DEFAULTS.upgradeStableMs; // LAN ما زال مرئياً
    expect(sup.evaluate(s).action).toBe('migrate');

    sup.markPending();
    sup.recordSuccess();
    expect(sup.evaluate(s).reason).toBe('cooldown');
  });

  test('reset clears pending/backoff state for a fresh session', () => {
    const nowRef = { t: 100000 };
    const sup = makeSupervisor(nowRef);
    const s = snap({ lanReachable: true, lanHost: '10.0.0.5' });
    nowRef.t += LINK_SUPERVISOR_DEFAULTS.upgradeStableMs + 100;
    sup.evaluate(s);
    sup.markPending();
    sup.recordFailure();
    sup.reset();
    nowRef.t += 1;
    // بعد reset: يحتاج استقرار LAN من جديد لكنه غير محجوب بـ backoff
    const d = sup.evaluate(s);
    expect(['awaiting-lan-stability', 'upgrade-to-lan']).toContain(d.reason);
  });
});
