/**
 * اختبارات انحدار لملكية المسار القديم أثناء الهجرة بلا انقطاع.
 *
 * الخطأ القاتل الذي يغطيه هذا الملف: المنسّق كان يستدعي
 * signalingOwner.disconnect() (أي closeSignaling) بعد نجاح الـ commit،
 * فيدمّر الجلسة الجديدة نفسها لأن كل جلسة حقيقية managedExternally —
 * فتموت الهجرة فور نجاحها على الجهازين.
 */
jest.mock("react-native-tcp-socket", () => ({
  createServer: jest.fn(),
  createConnection: jest.fn(),
}));

import {
  ConnectionCoordinator,
  COORDINATOR_STATE,
  HANDOVER_P2P_CLEANUP_DELAY_MS,
} from "../src/network/ConnectionCoordinator";
import { TRANSPORTS } from "../src/network/PeerRegistry";

function makePeer(transports = {}) {
  return {
    deviceId: "peer-device",
    deviceName: "Peer phone",
    transports: { LAN: { host: "192.168.1.50", port: 8089 }, ...transports },
  };
}

function makeSignalingOwner() {
  const session = { id: "lan-session", isConnected: true, destroy: jest.fn() };
  return {
    session,
    connectOutbound: jest.fn().mockResolvedValue(undefined),
    cancelConnect: jest.fn(),
    getActiveSession: jest.fn(() => session),
    sendMessage: jest.fn().mockReturnValue(true),
    disconnect: jest.fn(),
    subscribeDisconnect: jest.fn(() => ({ remove: jest.fn() })),
  };
}

async function connectViaOwner(coordinator, owner, peer) {
  await coordinator.connectLanPeer(peer, 4000, { maxRetries: 1, retryDelayMs: 10 });
  expect(coordinator.state).toBe(COORDINATOR_STATE.CONNECTED);
  expect(coordinator.activeSession).toBe(owner.session);
  expect(coordinator.activeSessionManagedExternally).toBe(true);
}

describe("handover previous-path ownership (make-before-break)", () => {
  afterEach(() => jest.clearAllMocks());

  test("adapter owning the drain: signaling owner is NEVER disconnected and old session survives", async () => {
    const owner = makeSignalingOwner();
    const coordinator = new ConnectionCoordinator({ myDeviceId: "self" });
    coordinator.setSignalingOwner(owner);
    const peer = makePeer();
    await connectViaOwner(coordinator, owner, peer);

    const newSession = { id: "p2p-session", isConnected: true, destroy: jest.fn() };
    const migrationAdapter = {
      ownsPreviousPathDrain: true,
      prepareConnection: jest.fn().mockResolvedValue({ session: newSession, isConnected: true }),
      commitConnection: jest.fn().mockResolvedValue({ session: newSession, isConnected: true }),
      discardConnection: jest.fn().mockResolvedValue(undefined),
      subscribeDisconnect: jest.fn(() => ({ remove: jest.fn() })),
    };

    await coordinator.handoverPeer(peer, TRANSPORTS.P2P, { adapter: migrationAdapter, timeoutMs: 4000 });

    // القلب حدث منطقياً
    expect(coordinator.activeSession).toBe(newSession);
    expect(coordinator.currentTransport).toBe(TRANSPORTS.P2P);
    // الإصلاح الجوهري: لا إغلاق للمالك ولا تدمير للجلسة القديمة — التصريف ملك المهيّئ
    expect(owner.disconnect).not.toHaveBeenCalled();
    expect(owner.session.destroy).not.toHaveBeenCalled();
    expect(coordinator.state).toBe(COORDINATOR_STATE.CONNECTED);
  });

  test("legacy adapter without drain ownership keeps old eager cleanup", async () => {
    const owner = makeSignalingOwner();
    const coordinator = new ConnectionCoordinator({ myDeviceId: "self" });
    coordinator.setSignalingOwner(owner);
    const peer = makePeer();
    await connectViaOwner(coordinator, owner, peer);

    const newSession = { id: "bt-session", isConnected: true };
    const legacyAdapter = {
      prepareConnection: jest.fn().mockResolvedValue({ session: newSession, isConnected: true }),
      commitConnection: jest.fn().mockResolvedValue({ session: newSession, isConnected: true }),
      subscribeDisconnect: jest.fn(() => ({ remove: jest.fn() })),
    };

    await coordinator.handoverPeer(peer, TRANSPORTS.BLUETOOTH, { adapter: legacyAdapter, timeoutMs: 4000 });

    expect(coordinator.activeSession).toBe(newSession);
    // السلوك القديم محفوظ للمهيئات التي لا تدير التصريف
    expect(owner.disconnect).toHaveBeenCalledTimes(1);
  });

  test("leaving P2P defers group teardown beyond the drain window", async () => {
    const owner = makeSignalingOwner();
    const p2pAdapter = {
      setIdentity: jest.fn(),
      connectPeer: jest.fn(),
      disconnect: jest.fn().mockResolvedValue(undefined),
      getStatus: jest.fn(() => ({ state: "IDLE" })),
    };
    const coordinator = new ConnectionCoordinator({ myDeviceId: "self" });
    coordinator.setSignalingOwner(owner);
    coordinator.setP2pAdapter(p2pAdapter);

    const peer = makePeer();
    await connectViaOwner(coordinator, owner, peer);
    // اجعل الجلسة الحالية P2P ظاهرياً
    coordinator.currentTransport = TRANSPORTS.P2P;

    const newSession = { id: "lan-2", isConnected: true, destroy: jest.fn() };
    const migrationAdapter = {
      ownsPreviousPathDrain: true,
      prepareConnection: jest.fn().mockResolvedValue({ session: newSession, isConnected: true }),
      commitConnection: jest.fn().mockResolvedValue({ session: newSession, isConnected: true }),
      discardConnection: jest.fn(),
      subscribeDisconnect: jest.fn(() => ({ remove: jest.fn() })),
    };

    jest.useFakeTimers();
    try {
      const handover = coordinator.handoverPeer(peer, TRANSPORTS.LAN, { adapter: migrationAdapter, timeoutMs: 4000 });
      await jest.advanceTimersByTimeAsync(0);
      await handover;

      // لا تفكيك فوري للمجموعة أثناء نافذة التصريف (قاعدة "ما لا يجب فعله")
      expect(p2pAdapter.disconnect).not.toHaveBeenCalled();
      jest.advanceTimersByTime(HANDOVER_P2P_CLEANUP_DELAY_MS + 100);
      expect(p2pAdapter.disconnect).toHaveBeenCalledTimes(1);
    } finally {
      jest.useRealTimers();
    }
  });

  test("noteExternalTransportChange realigns receiver-side state without touching sockets", async () => {
    const owner = makeSignalingOwner();
    const coordinator = new ConnectionCoordinator({ myDeviceId: "self" });
    coordinator.setSignalingOwner(owner);
    const peer = makePeer();
    await connectViaOwner(coordinator, owner, peer);

    const replacement = { id: "migrated-session", isConnected: true };
    owner.getActiveSession.mockReturnValue(replacement);
    const events = [];
    coordinator.onTransportChanged = e => events.push(e);

    const ok = coordinator.noteExternalTransportChange({
      peerId: "peer-device",
      transport: TRANSPORTS.P2P,
    });

    expect(ok).toBe(true);
    expect(coordinator.activeSession).toBe(replacement);
    expect(coordinator.currentTransport).toBe(TRANSPORTS.P2P);
    expect(events).toHaveLength(1);
    expect(events[0].fromTransport).toBe(TRANSPORTS.LAN);
    expect(events[0].toTransport).toBe(TRANSPORTS.P2P);
    // لا إغلاق ولا فصل — تحديث منطقي فقط
    expect(owner.disconnect).not.toHaveBeenCalled();
  });

  test("noteExternalTransportChange refuses foreign peers and idle state", async () => {
    const coordinator = new ConnectionCoordinator({ myDeviceId: "self" });
    expect(coordinator.noteExternalTransportChange({ transport: TRANSPORTS.LAN })).toBe(false);

    const owner = makeSignalingOwner();
    coordinator.setSignalingOwner(owner);
    const peer = makePeer();
    await connectViaOwner(coordinator, owner, peer);
    expect(
      coordinator.noteExternalTransportChange({ peerId: "someone-else", transport: TRANSPORTS.P2P })
    ).toBe(false);
    expect(coordinator.currentTransport).toBe(TRANSPORTS.LAN);
  });

  test("transition window allows repeated migrations but blocks flapping", async () => {
    const owner = makeSignalingOwner();
    const coordinator = new ConnectionCoordinator({ myDeviceId: "self" });
    coordinator.setSignalingOwner(owner);
    const peer = makePeer();
    await connectViaOwner(coordinator, owner, peer);

    const mkAdapter = id => ({
      ownsPreviousPathDrain: true,
      prepareConnection: jest.fn().mockResolvedValue({
        session: { id, isConnected: true, destroy: jest.fn() }, isConnected: true,
      }),
      commitConnection: jest.fn((candidate) => Promise.resolve(candidate)),
      discardConnection: jest.fn(),
      subscribeDisconnect: jest.fn(() => ({ remove: jest.fn() })),
    });

    // 6 هجرات ضمن النافذة مسموحة (الافتراضي الجديد)
    for (let i = 0; i < 6; i++) {
      const target = i % 2 === 0 ? TRANSPORTS.P2P : TRANSPORTS.LAN;
      await coordinator.handoverPeer(peer, target, { adapter: mkAdapter(`s${i}`), timeoutMs: 4000 });
      expect(coordinator.currentTransport).toBe(target);
    }
    // السابعة داخل نفس النافذة تُرفض (منع رفرفة)
    await expect(
      coordinator.handoverPeer(peer, TRANSPORTS.P2P, { adapter: mkAdapter("s7"), timeoutMs: 4000 })
    ).rejects.toMatchObject({ name: "TransportTransitionLimitError" });
  });
});
