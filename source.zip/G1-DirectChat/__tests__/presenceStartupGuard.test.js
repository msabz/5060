/**
 * حارس إقلاع طبقة الحضور: startPresence (بث UDP) يجب أن يعمل دائماً بعد
 * تحميل الهوية — حتى لو lanDiscovery.isSupported() === false. وجودها داخل
 * ذلك الشرط يعني موت الاكتشاف كاملاً على الأجهزة التي يصمت فيها NsdManager:
 * لا يظهر الأصدقاء، ولا يعمل QR، ولا الإضافة بالرقم، ولا الاتصال التلقائي
 * (addContactByCode يعتمد على presenceSnapshot حصرياً).
 * انحدار ميداني 2026-08-28 — لا تُعيدها داخل الشرط.
 */
const fs = require('fs');
const path = require('path');

const src = fs.readFileSync(path.join(__dirname, '..', 'src', 'App.js'), 'utf8');

/** يستخرج كتلة { ... } التي تلي نقطة البداية مع موازنة الأقواس. */
function extractBraceBlock(text, openBraceIndex) {
  let depth = 0;
  for (let i = openBraceIndex; i < text.length; i++) {
    const ch = text[i];
    if (ch === '{') depth++;
    else if (ch === '}') {
      depth--;
      if (depth === 0) return text.slice(openBraceIndex, i + 1);
    }
  }
  return null;
}

describe('إقلاع طبقة الحضور مستقل عن دعم DNS-SD', () => {
  test('startPresence ليست داخل if (lanDiscovery.isSupported())', () => {
    const guardIdx = src.indexOf('if (lanDiscovery.isSupported())');
    expect(guardIdx).toBeGreaterThan(-1);
    const openBrace = src.indexOf('{', guardIdx);
    const block = extractBraceBlock(src, openBrace);
    expect(block).toBeTruthy();
    // الإعلان والاكتشاف داخل الشرط مقبولان — الحضور ليس كذلك
    expect(block).toContain('startAdvertising');
    expect(block).not.toContain('startPresence');
  });

  test('startPresence تُستدعى فعلاً في مسار تحميل الهوية', () => {
    const identityIdx = src.indexOf('getDeviceIdentity()');
    const presenceIdx = src.indexOf('startPresence({');
    expect(identityIdx).toBeGreaterThan(-1);
    expect(presenceIdx).toBeGreaterThan(identityIdx);
  });
});
