/**
 * محاكاة كاملة للهجرة بلا انقطاع بين طرفين (A مُبادِر، B مستقبِل)
 * باستخدام آلات الحالة النقية — تتحقق من: التحقق من المسار، عدم فقد أي رسالة،
 * منع التكرار، وإعادة إرسال ما لم يصل.
 */
const {
  createSequencer, createAttachClient, createAttachServer, sessionIdFor, isMigrationInitiator,
} = require('../src/webrtc/sessionMigration');

describe('seamless migration end-to-end (simulated)', () => {
  test('no message loss, no duplicates, correct replay across path switch', async () => {
    const A = 'device-a', B = 'device-b';
    const sid = sessionIdFor(A, B);
    expect(isMigrationInitiator(A, B)).toBe(true);   // A فقط يقود الهجرة

    const seqA = createSequencer();
    const seqB = createSequencer();
    const deliveredToB = [];

    // مسار قديم: A يرسل 3 رسائل، B يستقبل 2 فقط (الثالثة "قيد الطيران" وتضيع مع القديم)
    const m1 = seqA.stamp({ type: 'chat', text: '1' });
    const m2 = seqA.stamp({ type: 'chat', text: '2' });
    const m3 = seqA.stamp({ type: 'chat', text: '3' });
    for (const m of [m1, m2]) if (seqB.accept(m) === 'accept') deliveredToB.push(m.text);
    expect(deliveredToB).toEqual(['1', '2']);

    // A يجهّز المسار الجديد ويتحقق منه بينما القديم ما زال حياً
    const client = createAttachClient({ sid, deviceId: A, lastSeq: seqA.lastIn, nonce: 'nA' });
    const server = createAttachServer({
      expectedSid: sid, expectedDeviceId: A, myLastSeq: () => seqB.lastIn,
      makeNonce: () => 'nB', verify: async (id, pub, nonce, sig) => sig === `sig:${nonce}`,
    });
    const challenge = await server.onMessage(client.hello());
    expect(client.onMessage(challenge)).toBe('challenge');
    const ack = await server.onMessage({ type: 'attach-proof', sig: 'sig:nB', pubKey: 'pkA' });
    expect(client.onMessage(ack)).toBe('ack');
    expect(client.state.peerLastSeq).toBe(2); // B استقبل حتى 2

    // commit: A يعيد إرسال ما بعد 2 على المسار الجديد
    const replayed = seqA.pendingAfter(client.state.peerLastSeq);
    expect(replayed.map(m => m.text)).toEqual(['3']);
    for (const m of replayed) if (seqB.accept(m) === 'accept') deliveredToB.push(m.text);

    // نافذة التصريف: نسخة مكررة من m2 تصل متأخرة على المسار القديم
    expect(seqB.accept(m2)).toBe('duplicate');

    // بعد التبديل: رسائل جديدة تُكمل التسلسل بلا إعادة تصفير
    const m4 = seqA.stamp({ type: 'chat', text: '4' });
    expect(m4.seq).toBe(4);
    if (seqB.accept(m4) === 'accept') deliveredToB.push(m4.text);

    expect(deliveredToB).toEqual(['1', '2', '3', '4']);
  });

  test('receiver retransmits what the initiator never got (hello.lastSeq)', async () => {
    const A = 'device-a', B = 'device-b';
    const sid = sessionIdFor(A, B);
    const seqA = createSequencer();
    const seqB = createSequencer();
    const deliveredToA = [];

    // B أرسل 3 رسائل على المسار القديم؛ A استقبل أول رسالة فقط
    const r1 = seqB.stamp({ type: 'chat', text: 'r1' });
    const r2 = seqB.stamp({ type: 'chat', text: 'r2' });
    const r3 = seqB.stamp({ type: 'chat', text: 'r3' });
    if (seqA.accept(r1) === 'accept') deliveredToA.push(r1.text);

    // A يبادر الهجرة: hello يحمل lastSeq = 1 (آخر ما وصله من B)
    const client = createAttachClient({ sid, deviceId: A, lastSeq: seqA.lastIn, nonce: 'nA' });
    const server = createAttachServer({
      expectedSid: sid, expectedDeviceId: A, myLastSeq: () => seqB.lastIn,
      makeNonce: () => 'nB', verify: async () => true,
    });
    await server.onMessage(client.hello());
    await server.onMessage({ type: 'attach-proof', sig: 'x', pubKey: 'pk' });

    // الإصلاح: بعد path-switch يعيد B الإرسال من lastSeq+1 = 2
    const resent = seqB.pendingAfter(Number(server.state.hello.lastSeq) || 0);
    expect(resent.map(m => m.text)).toEqual(['r2', 'r3']);
    for (const m of resent) if (seqA.accept(m) === 'accept') deliveredToA.push(m.text);

    // نسخة متأخرة من r2 على المسار القديم أثناء التصريف → تُمنع كمكررة
    expect(seqA.accept(r2)).toBe('duplicate');
    expect(deliveredToA).toEqual(['r1', 'r2', 'r3']);
  });

  test('attach from a wrong session or unproven peer is rejected', async () => {
    const server = createAttachServer({
      expectedSid: sessionIdFor('a', 'b'), expectedDeviceId: 'a', myLastSeq: () => 3,
      makeNonce: () => 'n', verify: async () => false,
    });
    const wrong = await server.onMessage({ type: 'session-attach', sid: 'other', deviceId: 'a', nonce: 'x' });
    expect(wrong.type).toBe('attach-reject');
  });
});
