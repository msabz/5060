/**
 * عقد الهوية المؤقتة (connect-first, verify in-band):
 * قرين Wi-Fi Direct/Bluetooth غير مؤكد يتصل بمعرّف مؤقت، وفور وصول رسالة
 * identity داخل القناة تُعاد مفاتيح سجل الأقران والمنسّق إلى deviceId الحقيقي
 * دون لمس السوكت أو الجلسة.
 */
jest.mock('react-native-tcp-socket', () => ({
  createServer: jest.fn(),
  createConnection: jest.fn(),
}));

import { PeerRegistry, peerRegistry, TRANSPORTS, isProvisionalPeerId } from '../src/network/PeerRegistry';
import { ConnectionCoordinator, COORDINATOR_STATE } from '../src/network/ConnectionCoordinator';

describe('isProvisionalPeerId', () => {
  test('يتعرف على البادئات المؤقتة فقط', () => {
    expect(isProvisionalPeerId('p2p:aa:bb')).toBe(true);
    expect(isProvisionalPeerId('bt:aa:bb')).toBe(true);
    expect(isProvisionalPeerId('bluetooth:AA:BB')).toBe(true);
    expect(isProvisionalPeerId('real-device-id')).toBe(false);
    expect(isProvisionalPeerId('')).toBe(false);
    expect(isProvisionalPeerId(null)).toBe(false);
  });
});

describe('PeerRegistry.rekeyPeer', () => {
  test('ينقل المسارات والحالة إلى المفتاح الحقيقي ويحذف المؤقت', () => {
    const registry = new PeerRegistry({ myDeviceId: 'self' });
    registry.upsertP2pPeer({
      deviceId: 'p2p:aa:bb:cc:dd:ee:ff',
      deviceName: 'Nearby phone',
      deviceAddress: 'AA:BB:CC:DD:EE:FF',
      isGroupOwner: false,
      groupOwnerAddress: '192.168.49.1',
      isOnline: true,
    });
    registry.setPeerConnected('p2p:aa:bb:cc:dd:ee:ff', TRANSPORTS.P2P);

    const target = registry.rekeyPeer('p2p:aa:bb:cc:dd:ee:ff', 'g1-real-id', { deviceName: 'هاتف أحمد' });

    expect(registry.getPeer('p2p:aa:bb:cc:dd:ee:ff')).toBeNull();
    expect(target.deviceId).toBe('g1-real-id');
    expect(target.deviceName).toBe('هاتف أحمد');
    expect(target.status).toBe('CONNECTED');
    expect(target.connectedTransport).toBe(TRANSPORTS.P2P);
    expect(target.transports.P2P.groupOwnerAddress).toBe('192.168.49.1');
    expect(target.provisional).toBe(false);
  });

  test('لا يمس مفتاحاً حقيقياً ولا يسرق مساراً أحدث', () => {
    const registry = new PeerRegistry({ myDeviceId: 'self' });
    registry.upsertLanPeer({ deviceId: 'g1-real-id', deviceName: 'قديم', host: '192.168.1.9', port: 8089 });
    const older = registry.getPeer('g1-real-id').transports.LAN;
    older.lastSeen = Date.now() + 60000; // أحدث من أي شيء قادم

    registry.upsertP2pPeer({
      deviceId: 'p2p:aa', deviceName: 'مؤقت', deviceAddress: 'AA', isGroupOwner: null, isOnline: true,
    });
    const target = registry.rekeyPeer('p2p:aa', 'g1-real-id');
    expect(target.transports.LAN.host).toBe('192.168.1.9'); // بقي الأحدث
    expect(target.transports.P2P.deviceAddress).toBe('AA');   // واكتسب المسار الجديد
  });
});

describe('ConnectionCoordinator.rekeyCurrentPeer', () => {
  function makeCoordinator() {
    return new ConnectionCoordinator({ myDeviceId: 'self' });
  }

  test('يرقّي القرين المتصل من مؤقت إلى حقيقي', () => {
    const c = makeCoordinator();
    c.state = COORDINATOR_STATE.CONNECTED;
    c.currentPeer = { deviceId: 'p2p:aa:bb', deviceName: 'مؤقت' };
    c.currentTransport = TRANSPORTS.P2P;
    peerRegistry.upsertP2pPeer({
      deviceId: 'p2p:aa:bb', deviceName: 'مؤقت', deviceAddress: 'AA:BB',
      isGroupOwner: false, groupOwnerAddress: '192.168.49.1', isOnline: true,
    });

    const ok = c.rekeyCurrentPeer('g1-real', { deviceName: 'أحمد' });

    expect(ok).toBe(true);
    expect(c.currentPeer.deviceId).toBe('g1-real');
    expect(c.currentPeer.deviceName).toBe('أحمد');
    expect(peerRegistrySafeGet(c, 'g1-real')?.status).toBe('CONNECTED');
  });

  test('يرفض ترقية معرّف حقيقي (حماية من خطف الجلسة)', () => {
    const c = makeCoordinator();
    c.state = COORDINATOR_STATE.CONNECTED;
    c.currentPeer = { deviceId: 'g1-stable', deviceName: 'حقيقي' };
    c.currentTransport = TRANSPORTS.LAN;
    expect(c.rekeyCurrentPeer('attacker-id', {})).toBe(false);
    expect(c.currentPeer.deviceId).toBe('g1-stable');
  });

  test('يرفض عندما لا يوجد اتصال', () => {
    const c = makeCoordinator();
    c.state = COORDINATOR_STATE.IDLE;
    c.currentPeer = { deviceId: 'p2p:xx', deviceName: 'x' };
    expect(c.rekeyCurrentPeer('g1-real', {})).toBe(false);
  });
});

function peerRegistrySafeGet(coordinator, id) {
  return peerRegistry.getPeer(id);
}
