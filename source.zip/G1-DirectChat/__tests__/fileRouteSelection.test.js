/**
 * مستوى البيانات يفضّل Wi-Fi Direct على LAN (المستخدم قيّمه أسرع بكثير —
 * حلقة الراوتر أبطأ من الوصلة المباشرة)، مع احترام القياسات الحقيقية:
 * لو أثبتت EWMA أن LAN أسرع بـ 1.3× فأكثر يفوز LAN.
 */
jest.mock('react-native', () => ({
  NativeModules: {
    FilePickerModule: {},
    FileTransferModule: {
      startServer: jest.fn().mockResolvedValue(true),
      stopServer: jest.fn().mockResolvedValue(true),
      sendFile: jest.fn().mockResolvedValue({ id: 'done' }),
      cancelTransfer: jest.fn().mockResolvedValue(true),
    },
  },
  NativeEventEmitter: jest.fn().mockImplementation(() => ({
    addListener: jest.fn(() => ({ remove: jest.fn() })),
  })),
}));

jest.mock('../src/webrtc/signaling', () => ({ getActivePeerAddress: jest.fn() }));
jest.mock('../src/network/PresenceBeacon', () => ({ presenceP2pHost: jest.fn(() => null) }));

import {
  pickFileRouteFamily,
  recordRouteMeasurement,
  resetRouteStats,
  routeFamilyOf,
  routeStatsSnapshot,
} from '../src/media/FileShare';

describe('تصنيف عائلة المسار', () => {
  test('192.168.49.x = p2p وغيره = lan', () => {
    expect(routeFamilyOf('192.168.49.1')).toBe('p2p');
    expect(routeFamilyOf('192.168.1.20')).toBe('lan');
    expect(routeFamilyOf('')).toBe('lan');
  });
});

describe('pickFileRouteFamily', () => {
  beforeEach(() => resetRouteStats());

  test('بدون مسار P2P متاح → LAN دائماً', () => {
    expect(pickFileRouteFamily({ p2pAvailable: false })).toBe('lan');
  });

  test('بدون قياسات → P2P يفوز (تفضيل المصنع)', () => {
    expect(pickFileRouteFamily({ p2pAvailable: true })).toBe('p2p');
  });

  test('قياسات متقاربة → P2P يفوز', () => {
    expect(pickFileRouteFamily({
      p2pAvailable: true,
      stats: { lan: { mbps: 40, samples: 3 }, p2p: { mbps: 45, samples: 3 } },
    })).toBe('p2p');
  });

  test('LAN أسرع بـ 1.3× فأكثر → LAN يفوز (مانع رفرفة)', () => {
    expect(pickFileRouteFamily({
      p2pAvailable: true,
      stats: { lan: { mbps: 130, samples: 5 }, p2p: { mbps: 100, samples: 5 } },
    })).toBe('lan');
    expect(pickFileRouteFamily({
      p2pAvailable: true,
      stats: { lan: { mbps: 129, samples: 5 }, p2p: { mbps: 100, samples: 5 } },
    })).toBe('p2p');
  });
});

describe('recordRouteMeasurement', () => {
  beforeEach(() => resetRouteStats());

  test('EWMA يتراكم ويتقارب نحو القياسات الجديدة', () => {
    recordRouteMeasurement('p2p', 100);
    expect(routeStatsSnapshot().p2p.mbps).toBe(100);
    recordRouteMeasurement('p2p', 50);
    expect(routeStatsSnapshot().p2p.mbps).toBe(75);
    expect(routeStatsSnapshot().p2p.samples).toBe(2);
  });

  test('يتجاهل القياسات غير الصالحة', () => {
    recordRouteMeasurement('p2p', 0);
    recordRouteMeasurement('p2p', -5);
    recordRouteMeasurement('', 100);
    expect(routeStatsSnapshot().p2p).toBeNull();
  });
});
