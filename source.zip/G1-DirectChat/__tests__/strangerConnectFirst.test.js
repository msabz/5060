/**
 * حراسة «اتصل أولاً» للغرباء — الجذور التي كانت تجعل التطبيق يعمل عبر LAN فقط:
 * 1) قائمة القريبين تُبنى من كل النواقل (P2P/BLE) وليس من حضور LAN فقط.
 * 2) مستمع صيد الأرقام يُسجَّل في المستوى الأعلى، لا داخل onPeer الخاص بالموثّقين.
 * 3) دعوات Wi-Fi Direct الواردة من الغرباء تُقبل (الهوية تُتحقق داخل القناة).
 * 4) عنوان P2P يُتبادل داخل القناة (بديل DNS-SD).
 */
import fs from 'fs';
import path from 'path';

const appSource = fs.readFileSync(path.join(__dirname, '..', 'src', 'App.js'), 'utf8');
const wifiUtilsSource = fs.readFileSync(path.join(__dirname, '..', 'src', 'utils', 'wifiDirect.js'), 'utf8');
const bleSource = fs.readFileSync(path.join(__dirname, '..', 'src', 'network', 'BlePresence.js'), 'utf8');

describe('stranger connect-first guards', () => {
  test('stranger-hunt listener registers before startBlePresence, never inside onPeer', () => {
    const listenerIdx = appSource.indexOf('setBleStrangerListener(async');
    const startIdx = appSource.indexOf('startBlePresence({');
    expect(listenerIdx).toBeGreaterThan(-1);
    expect(startIdx).toBeGreaterThan(-1);
    // المستمع يسبق استدعاء البدء — تسجيله داخل onPeer كان يميت صيد الغرباء
    expect(listenerIdx).toBeLessThan(startIdx);
  });

  test('nearby list merges all three transports, not LAN presence only', () => {
    const nearbyBlock = appSource.slice(
      appSource.indexOf('const nearbyList = presence'),
      appSource.indexOf('setNearby(nearbyList)')
    );
    expect(nearbyBlock).toContain("via: 'lan'");
    expect(nearbyBlock).toContain("via: 'p2p'");
    expect(nearbyBlock).toContain("via: 'ble'");
    expect(nearbyBlock).toContain('bleStrangerSnapshot()');
    expect(nearbyBlock).toContain('Object.values(found)');
    expect(nearbyBlock).toContain('p2p:${addr}');
  });

  test('incoming Wi-Fi Direct invitations from strangers are accepted', () => {
    expect(wifiUtilsSource).toContain('export const findAnyIncomingInvitation');
    expect(appSource).toContain('findAnyIncomingInvitation(peers)');
    // المسار الموثوق القديم ما زال متاحاً
    expect(wifiUtilsSource).toContain('export const findTrustedIncomingInvitation');
  });

  test('BLE strangers are tracked with reaping and never mixed with pinned peers', () => {
    expect(bleSource).toContain('const strangerSeen = new Map()');
    expect(bleSource).toContain('export function bleStrangerSnapshot(');
    expect(bleSource).toContain('strangerSeen.delete(addr)');
    expect(bleSource).toContain('strangerSeen.clear()');
  });

  test('P2P address is exchanged in-band as a DNS-SD-independent route', () => {
    expect(appSource).toContain("type: 'p2p-address'");
    expect(appSource).toContain('getOwnP2pDeviceAddress');
    expect(appSource).toContain('shareOwnP2pAddress');
    // المتلقي يحفظ العنوان فقط لهوية حقيقية (ليس لمؤقت)
    expect(appSource).toMatch(/p2p-address[\s\S]*?isProvisionalPeerId\(ownerId\)/);
  });

  test('onAddNearby routes by transport (p2p negotiate / ble connect / lan save)', () => {
    expect(appSource).toContain('const handleAddNearby = async peer =>');
    const block = appSource.slice(
      appSource.indexOf('const handleAddNearby'),
      appSource.indexOf('const startNumberHunt')
    );
    expect(block).toContain("peer.via === 'p2p'");
    expect(block).toContain("peer.via === 'ble'");
    expect(block).toContain('beginWifiNegotiation(');
    expect(block).toContain('btConnect(peer.address)');
  });
});
