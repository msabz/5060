package com.m200.lan

import android.content.Context
import android.net.wifi.WifiManager
import android.util.Log
import com.facebook.react.bridge.*
import com.facebook.react.modules.core.DeviceEventManagerModule
import org.json.JSONObject
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.NetworkInterface
import java.util.UUID
import java.util.concurrent.atomic.AtomicBoolean

/**
 * طبقة "حضور" على الشبكة المحلية بنمط Syncthing/KDE Connect/LocalSend:
 * بث UDP دوري صغير يقول "أنا هنا، وعليّ التطبيق، هذا معرّفي ومنفذي".
 *
 * لماذا إلى جانب DNS-SD؟ لأن NsdManager على كثير من أجهزة Samsung/Motorola
 * يتأخر أو يصمت، بينما بث UDP بسيط يصل خلال ثوانٍ ولا يعتمد على خدمة النظام.
 *
 * الحمولة (JSON ≤ 300 بايت):
 *   { "app":"musabx","v":1,"id":<deviceId>,"name":<deviceName>,
 *     "port":<tcpPort>,"inst":<instanceId>,"t":<epochMs> }
 * instanceId عشوائي عند كل تشغيل → يكشف إعادة تشغيل الطرف الآخر فوراً.
 */
class PresenceBeaconModule(private val reactContext: ReactApplicationContext) :
    ReactContextBaseJavaModule(reactContext) {

    companion object {
        const val MODULE_NAME = "PresenceBeaconModule"
        const val TAG = "PresenceBeacon"
        const val EVENT_PRESENCE = "PRESENCE_BEACON"
        const val PORT = 53421
        const val MAGIC = "musabx"
        const val VERSION = 1
        const val DEFAULT_INTERVAL_MS = 25_000L
    }

    private val running = AtomicBoolean(false)
    private var senderThread: Thread? = null
    private var receiverThread: Thread? = null
    private var socket: DatagramSocket? = null
    private var multicastLock: WifiManager.MulticastLock? = null

    @Volatile private var myId: String = ""
    @Volatile private var myName: String = ""
    @Volatile private var myPort: Int = 0
    @Volatile private var intervalMs: Long = DEFAULT_INTERVAL_MS
    private val instanceId: String = UUID.randomUUID().toString().substring(0, 8)

    override fun getName(): String = MODULE_NAME

    private fun emit(map: WritableMap) {
        try {
            if (reactContext.hasActiveReactInstance()) {
                reactContext
                    .getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java)
                    .emit(EVENT_PRESENCE, map)
            }
        } catch (e: Exception) {
            Log.w(TAG, "emit failed: ${e.message}")
        }
    }

    @ReactMethod
    fun start(deviceId: String, deviceName: String, tcpPort: Int, intervalMillis: Int, promise: Promise) {
        myId = deviceId
        myName = deviceName
        myPort = tcpPort
        intervalMs = if (intervalMillis > 3000) intervalMillis.toLong() else DEFAULT_INTERVAL_MS
        if (running.getAndSet(true)) {
            promise.resolve(true)
            return
        }
        try {
            val wm = reactContext.applicationContext.getSystemService(Context.WIFI_SERVICE) as? WifiManager
            multicastLock = wm?.createMulticastLock("musabx-presence")?.apply {
                setReferenceCounted(false)
                acquire()
            }
            val s = DatagramSocket(null).apply {
                reuseAddress = true
                broadcast = true
                bind(InetSocketAddress(PORT))
            }
            socket = s
            receiverThread = Thread({ receiveLoop(s) }, "musabx-presence-rx").apply { isDaemon = true; start() }
            senderThread = Thread({ sendLoop(s) }, "musabx-presence-tx").apply { isDaemon = true; start() }
            promise.resolve(true)
        } catch (e: Exception) {
            running.set(false)
            Log.e(TAG, "start failed", e)
            promise.reject("PRESENCE_START_FAILED", e.message, e)
        }
    }

    @ReactMethod
    fun update(deviceName: String, tcpPort: Int) {
        myName = deviceName
        myPort = tcpPort
    }

    /** بث فوري (عند رؤية جهاز جديد أو تغيّر الشبكة) — نمط Syncthing. */
    @ReactMethod
    fun announceNow(promise: Promise) {
        val s = socket
        if (s == null || !running.get()) { promise.resolve(false); return }
        Thread { sendOnce(s); promise.resolve(true) }.start()
    }

    @ReactMethod
    fun stop(promise: Promise) {
        stopInternal()
        promise.resolve(true)
    }

    private fun stopInternal() {
        running.set(false)
        try { socket?.close() } catch (_: Exception) {}
        socket = null
        try { multicastLock?.release() } catch (_: Exception) {}
        multicastLock = null
        senderThread = null
        receiverThread = null
    }

    override fun onCatalystInstanceDestroy() {
        stopInternal()
        super.onCatalystInstanceDestroy()
    }

    private fun payload(): ByteArray {
        val json = JSONObject()
            .put("app", MAGIC)
            .put("v", VERSION)
            .put("id", myId)
            .put("name", myName)
            .put("port", myPort)
            .put("inst", instanceId)
            .put("t", System.currentTimeMillis())
        return json.toString().toByteArray(Charsets.UTF_8)
    }

    /** كل عناوين البث للواجهات الفعّالة (wlan0، p2p-wlan0-0، …). */
    private fun broadcastTargets(): List<InetAddress> {
        val out = ArrayList<InetAddress>()
        try {
            val ifaces = NetworkInterface.getNetworkInterfaces() ?: return out
            for (nif in ifaces) {
                if (!nif.isUp || nif.isLoopback) continue
                for (ia in nif.interfaceAddresses) {
                    val b = ia.broadcast ?: continue
                    out.add(b)
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "iface scan failed: ${e.message}")
        }
        if (out.isEmpty()) {
            try { out.add(InetAddress.getByName("255.255.255.255")) } catch (_: Exception) {}
        }
        return out
    }

    private fun sendOnce(s: DatagramSocket) {
        if (myId.isEmpty()) return
        val data = payload()
        for (target in broadcastTargets()) {
            try {
                s.send(DatagramPacket(data, data.size, target, PORT))
            } catch (e: Exception) {
                Log.d(TAG, "send to $target failed: ${e.message}")
            }
        }
    }

    private fun sendLoop(s: DatagramSocket) {
        // بث سريع في البداية (3 مرات كل ثانيتين) ثم بالفترة العادية
        var burst = 3
        while (running.get() && socket === s) {
            sendOnce(s)
            try {
                Thread.sleep(if (burst > 0) 2_000L else intervalMs)
            } catch (_: InterruptedException) { return }
            if (burst > 0) burst--
        }
    }

    private fun receiveLoop(s: DatagramSocket) {
        val buf = ByteArray(1024)
        while (running.get() && socket === s) {
            try {
                val pkt = DatagramPacket(buf, buf.size)
                s.receive(pkt)
                val text = String(pkt.data, pkt.offset, pkt.length, Charsets.UTF_8)
                val json = JSONObject(text)
                if (json.optString("app") != MAGIC) continue
                val id = json.optString("id")
                if (id.isEmpty() || id == myId) continue
                val map = Arguments.createMap().apply {
                    putString("deviceId", id)
                    putString("deviceName", json.optString("name"))
                    putString("host", pkt.address.hostAddress ?: "")
                    putInt("port", json.optInt("port", 0))
                    putString("instanceId", json.optString("inst"))
                    putInt("version", json.optInt("v", 0))
                    putDouble("receivedAt", System.currentTimeMillis().toDouble())
                }
                emit(map)
            } catch (e: Exception) {
                if (running.get() && socket === s) Log.d(TAG, "rx error: ${e.message}")
            }
        }
    }
}
