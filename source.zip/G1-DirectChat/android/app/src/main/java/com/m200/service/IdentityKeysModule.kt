package com.m200.service

import android.content.Context
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import com.facebook.react.bridge.*
import java.security.KeyPairGenerator
import java.security.KeyStore
import java.security.MessageDigest
import java.security.PrivateKey
import java.security.PublicKey
import java.security.Signature
import java.security.KeyFactory
import java.security.spec.ECGenParameterSpec
import java.security.spec.X509EncodedKeySpec

/**
 * الهوية التشفيرية لـ MusabX (نمط Syncthing/KDE Connect):
 * - زوج مفاتيح EC P-256 يُولَّد مرة واحدة داخل Android Keystore (المفتاح
 *   الخاص لا يغادر الجهاز ولا يلمسه JavaScript أبداً).
 * - MusabX ID = Base32 لأول 15 بايت من SHA-256(المفتاح العام) بصيغة مقروءة.
 * - توقيع/تحقق ECDSA-SHA256 لإثبات ملكية المفتاح عند كل اتصال.
 * - تثبيت (pinning) مفتاح كل جهة اتصال عند أول اقتران (TOFU) والتحقق منه
 *   في كل اتصال لاحق — لا إعادة اقتران، ولا انتحال بمجرد انتحال deviceId.
 */
class IdentityKeysModule(private val reactContext: ReactApplicationContext) :
    ReactContextBaseJavaModule(reactContext) {

    companion object {
        const val MODULE_NAME = "IdentityKeysModule"
        private const val KEYSTORE = "AndroidKeyStore"
        private const val ALIAS = "musabx_identity_v1"
        private const val PREFS = "musabx_pinned_keys"
        private const val B32 = "ABCDEFGHIJKLMNOPQRSTUVWXYZ234567"
    }

    override fun getName(): String = MODULE_NAME

    private fun keyStore(): KeyStore = KeyStore.getInstance(KEYSTORE).apply { load(null) }

    @Synchronized
    private fun ensureKey(): Pair<PrivateKey, PublicKey> {
        val ks = keyStore()
        if (!ks.containsAlias(ALIAS)) {
            val kpg = KeyPairGenerator.getInstance(KeyProperties.KEY_ALGORITHM_EC, KEYSTORE)
            kpg.initialize(
                KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY)
                    .setAlgorithmParameterSpec(ECGenParameterSpec("secp256r1"))
                    .setDigests(KeyProperties.DIGEST_SHA256)
                    .build()
            )
            kpg.generateKeyPair()
        }
        val entry = ks.getEntry(ALIAS, null) as KeyStore.PrivateKeyEntry
        return Pair(entry.privateKey, entry.certificate.publicKey)
    }

    private fun publicKeyB64(pub: PublicKey): String =
        Base64.encodeToString(pub.encoded, Base64.NO_WRAP)

    /** رقم MusabX: 12 رقماً مشتقة من أول 5 بايت من SHA-256(المفتاح العام) — مثل رقم هاتف. */
    private fun musabNumberOf(pubDer: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(pubDer)
        var v = 0L
        for (i in 0 until 5) v = (v shl 8) or (digest[i].toLong() and 0xFF)
        val digits = (v % 1_000_000_000_000L).toString().padStart(12, '0')
        return digits.chunked(3).joinToString(" ")
    }

    private fun keyHashOf(pubDer: ByteArray): String =
        MessageDigest.getInstance("SHA-256").digest(pubDer).copyOfRange(0, 8).joinToString("") { "%02x".format(it) }

    private fun musabIdOf(pubDer: ByteArray): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(pubDer)
        val raw = base32(digest.copyOfRange(0, 15)) // 24 محرفاً
        return raw.chunked(4).joinToString("-")
    }

    private fun base32(bytes: ByteArray): String {
        val sb = StringBuilder()
        var buffer = 0
        var bits = 0
        for (b in bytes) {
            buffer = (buffer shl 8) or (b.toInt() and 0xFF)
            bits += 8
            while (bits >= 5) {
                sb.append(B32[(buffer shr (bits - 5)) and 31])
                bits -= 5
            }
        }
        if (bits > 0) sb.append(B32[(buffer shl (5 - bits)) and 31])
        return sb.toString()
    }

    @ReactMethod
    fun getIdentity(promise: Promise) {
        try {
            val (_, pub) = ensureKey()
            promise.resolve(Arguments.createMap().apply {
                putString("pubKey", publicKeyB64(pub))
                putString("musabId", musabIdOf(pub.encoded))
                putString("musabNumber", musabNumberOf(pub.encoded))
                putString("keyHash", keyHashOf(pub.encoded))
                putString("alg", "EC-P256/ECDSA-SHA256")
            })
        } catch (e: Exception) {
            promise.reject("IDENTITY_KEY_FAILED", e.message, e)
        }
    }

    @ReactMethod
    fun musabIdFor(pubKeyB64: String, promise: Promise) {
        try {
            val der = Base64.decode(pubKeyB64, Base64.NO_WRAP)
            promise.resolve(Arguments.createMap().apply {
                putString("musabId", musabIdOf(der))
                putString("musabNumber", musabNumberOf(der))
            })
        } catch (e: Exception) {
            promise.reject("BAD_KEY", e.message, e)
        }
    }

    /**
     * بصمة رقم عامة مدوّرة لاكتشاف الغرباء عبر BLE (نمط Nearby Connections):
     * SHA-256("musabx-pub-v1:" + الرقم + ":" + دلو_زمني)[0..8].
     * من يعرف الرقم يحسب البصمة الحالية ويجد صاحبها؛ ومن لا يعرفه يرى ضجيجاً
     * متغيراً كل 15 دقيقة لا يمكن تتبعه.
     */
    @ReactMethod
    fun pubHashFor(number: String, bucket: Double, promise: Promise) {
        try {
            val norm = number.filter { it.isDigit() }
            if (norm.length < 12) { promise.resolve(""); return }
            val b = bucket.toLong()
            val digest = MessageDigest.getInstance("SHA-256")
                .digest("musabx-pub-v1:$norm:$b".toByteArray(Charsets.UTF_8))
            promise.resolve(digest.copyOfRange(0, 8).joinToString("") { "%02x".format(it) })
        } catch (e: Exception) {
            promise.reject("PUBHASH_FAILED", e.message, e)
        }
    }

    @ReactMethod
    fun sign(data: String, promise: Promise) {
        try {
            val (priv, _) = ensureKey()
            val sig = Signature.getInstance("SHA256withECDSA").apply {
                initSign(priv)
                update(data.toByteArray(Charsets.UTF_8))
            }.sign()
            promise.resolve(Base64.encodeToString(sig, Base64.NO_WRAP))
        } catch (e: Exception) {
            promise.reject("SIGN_FAILED", e.message, e)
        }
    }

    @ReactMethod
    fun verify(pubKeyB64: String, data: String, sigB64: String, promise: Promise) {
        try {
            val pub = KeyFactory.getInstance("EC")
                .generatePublic(X509EncodedKeySpec(Base64.decode(pubKeyB64, Base64.NO_WRAP)))
            val ok = Signature.getInstance("SHA256withECDSA").apply {
                initVerify(pub)
                update(data.toByteArray(Charsets.UTF_8))
            }.verify(Base64.decode(sigB64, Base64.NO_WRAP))
            promise.resolve(ok)
        } catch (e: Exception) {
            promise.resolve(false)
        }
    }

    // ---------- تثبيت مفاتيح جهات الاتصال ----------
    private fun prefs() = reactContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    /** كل جهات الاتصال المثبّتة مع بصمة مفتاح كل منها — لمطابقة إعلانات BLE. */
    @ReactMethod
    fun listPinnedKeyHashes(promise: Promise) {
        val out = Arguments.createMap()
        for ((peerId, value) in prefs().all) {
            val b64 = value as? String ?: continue
            try { out.putString(keyHashOf(Base64.decode(b64, Base64.NO_WRAP)), peerId) } catch (_: Exception) {}
        }
        promise.resolve(out)
    }

    @ReactMethod
    fun getPinnedKey(peerId: String, promise: Promise) {
        promise.resolve(prefs().getString(peerId, null))
    }

    @ReactMethod
    fun pinKey(peerId: String, pubKeyB64: String, promise: Promise) {
        prefs().edit().putString(peerId, pubKeyB64).apply()
        promise.resolve(true)
    }

    @ReactMethod
    fun unpinKey(peerId: String, promise: Promise) {
        prefs().edit().remove(peerId).apply()
        promise.resolve(true)
    }

    @ReactMethod
    fun randomNonce(promise: Promise) {
        val b = ByteArray(32)
        java.security.SecureRandom().nextBytes(b)
        promise.resolve(Base64.encodeToString(b, Base64.NO_WRAP))
    }
}
