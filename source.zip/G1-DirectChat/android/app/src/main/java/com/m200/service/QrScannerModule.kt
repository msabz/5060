package com.m200.service

import android.app.Activity
import android.content.Intent
import com.facebook.react.bridge.*
import com.journeyapps.barcodescanner.CaptureActivity
import com.journeyapps.barcodescanner.ScanOptions
import com.journeyapps.barcodescanner.ScanIntentResult

/** يفتح شاشة كاميرا لمسح QR ويُرجع النص. الإذن CAMERA موجود بالـManifest. */
class QrScannerModule(private val reactContext: ReactApplicationContext) :
    ReactContextBaseJavaModule(reactContext), ActivityEventListener {

    companion object { const val REQUEST_CODE = 0x5158 }
    private var pending: Promise? = null

    init { reactContext.addActivityEventListener(this) }
    override fun getName(): String = "QrScannerModule"

    @ReactMethod
    fun scan(prompt: String?, promise: Promise) {
        val activity = currentActivity
        if (activity == null) { promise.reject("NO_ACTIVITY", "لا توجد شاشة نشطة"); return }
        if (pending != null) { promise.reject("BUSY", "المسح جارٍ بالفعل"); return }
        pending = promise
        try {
            val opts = ScanOptions().apply {
                setDesiredBarcodeFormats(ScanOptions.QR_CODE)
                setPrompt(prompt ?: "وجّه الكاميرا إلى رمز MusabX")
                setBeepEnabled(false)
                setOrientationLocked(true)
                setCaptureActivity(CaptureActivity::class.java)
            }
            activity.startActivityForResult(opts.createScanIntent(activity), REQUEST_CODE)
        } catch (e: Exception) {
            pending = null
            promise.reject("SCAN_FAILED", e.message, e)
        }
    }

    override fun onActivityResult(activity: Activity?, requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode != REQUEST_CODE) return
        val p = pending ?: return
        pending = null
        val result = ScanIntentResult.parseActivityResult(resultCode, data)
        if (result?.contents != null) p.resolve(result.contents) else p.resolve(null)
    }

    override fun onNewIntent(intent: Intent?) {}
}
