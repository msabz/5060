package com.m200.bluetooth

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.bluetooth.le.*
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.ParcelUuid
import android.util.Log
import com.facebook.react.bridge.*
import com.facebook.react.modules.core.DeviceEventManagerModule
import java.util.UUID

/**
 * حضور عبر BLE (نمط AirDrop/Briar): إعلان دوري يحمل 8 بايت من بصمة المفتاح
 * العام، ومسح بمرشّح على UUID الخدمة. لا اتصال — فقط "صديقك قريب".
 * يعمل بلا Wi-Fi وبلا شبكة، وباستهلاك بطارية منخفض (BALANCED).
 */
class BlePresenceModule(private val reactContext: ReactApplicationContext) :
    ReactContextBaseJavaModule(reactContext) {

    companion object {
        const val MODULE_NAME = "BlePresenceModule"
        const val EVENT = "BLE_PRESENCE"
        const val TAG = "BlePresence"
        val SERVICE_UUID: UUID = UUID.fromString("4d755361-6258-4d58-8000-000000000001") // "MusaBX"
    }

    private val adapter: BluetoothAdapter? by lazy {
        (reactContext.getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
    }
    private var advertiser: BluetoothLeAdvertiser? = null
    private var scanner: BluetoothLeScanner? = null
    private var advertising = false
    private var scanning = false
    private val handler = Handler(Looper.getMainLooper())

    override fun getName(): String = MODULE_NAME

    private fun emit(map: WritableMap) {
        try {
            if (reactContext.hasActiveReactInstance()) {
                reactContext.getJSModule(DeviceEventManagerModule.RCTDeviceEventEmitter::class.java).emit(EVENT, map)
            }
        } catch (_: Exception) {}
    }

    private val advCallback = object : AdvertiseCallback() {
        override fun onStartSuccess(settingsInEffect: AdvertiseSettings?) { advertising = true }
        override fun onStartFailure(errorCode: Int) { advertising = false; Log.w(TAG, "advertise failed $errorCode") }
    }

    private val scanCallback = object : ScanCallback() {
        override fun onScanResult(callbackType: Int, result: ScanResult) {
            val data = result.scanRecord?.getServiceData(ParcelUuid(SERVICE_UUID)) ?: return
            val hex = data.joinToString("") { "%02x".format(it) }
            emit(Arguments.createMap().apply {
                putString("keyHash", hex)
                putInt("rssi", result.rssi)
                putString("address", result.device?.address ?: "")
                putDouble("receivedAt", System.currentTimeMillis().toDouble())
            })
        }
        override fun onScanFailed(errorCode: Int) { scanning = false; Log.w(TAG, "scan failed $errorCode") }
    }

    @ReactMethod
    fun isSupported(promise: Promise) {
        val a = adapter
        promise.resolve(a != null && a.isEnabled && a.bluetoothLeAdvertiser != null)
    }

    /** keyHashHex: 16 محرفاً هكس = 8 بايت من SHA-256(المفتاح العام). */
    @ReactMethod
    fun start(keyHashHex: String, promise: Promise) {
        try {
            val a = adapter
            if (a == null || !a.isEnabled) { promise.resolve(false); return }
            val bytes = keyHashHex.take(16).chunked(2).map { it.toInt(16).toByte() }.toByteArray()
            if (!advertising) {
                advertiser = a.bluetoothLeAdvertiser
                val settings = AdvertiseSettings.Builder()
                    .setAdvertiseMode(AdvertiseSettings.ADVERTISE_MODE_BALANCED)
                    .setTxPowerLevel(AdvertiseSettings.ADVERTISE_TX_POWER_MEDIUM)
                    .setConnectable(false)
                    .build()
                val data = AdvertiseData.Builder()
                    .addServiceUuid(ParcelUuid(SERVICE_UUID))
                    .addServiceData(ParcelUuid(SERVICE_UUID), bytes)
                    .setIncludeDeviceName(false)
                    .build()
                advertiser?.startAdvertising(settings, data, advCallback)
            }
            if (!scanning) {
                scanner = a.bluetoothLeScanner
                val filter = ScanFilter.Builder().setServiceUuid(ParcelUuid(SERVICE_UUID)).build()
                val settings = ScanSettings.Builder().setScanMode(ScanSettings.SCAN_MODE_BALANCED).build()
                scanner?.startScan(listOf(filter), settings, scanCallback)
                scanning = true
            }
            promise.resolve(true)
        } catch (e: SecurityException) {
            promise.resolve(false)
        } catch (e: Exception) {
            promise.reject("BLE_START_FAILED", e.message, e)
        }
    }

    @ReactMethod
    fun stop(promise: Promise) {
        try { advertiser?.stopAdvertising(advCallback) } catch (_: Exception) {}
        try { scanner?.stopScan(scanCallback) } catch (_: Exception) {}
        advertising = false; scanning = false
        promise.resolve(true)
    }

    override fun onCatalystInstanceDestroy() {
        try { advertiser?.stopAdvertising(advCallback) } catch (_: Exception) {}
        try { scanner?.stopScan(scanCallback) } catch (_: Exception) {}
        super.onCatalystInstanceDestroy()
    }
}
